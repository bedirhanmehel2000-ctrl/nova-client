package dev.nova.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public final class NovaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HudElementRegistry.attachElementBefore(
            VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath("nova_client", "nova_hud"),
            (graphics, deltaTracker) -> {
                Minecraft minecraft = Minecraft.getInstance();
                if (minecraft.player == null || minecraft.options.hideGui) {
                    return;
                }

                String fpsText = "FPS: " + minecraft.getFps();
                graphics.drawString(minecraft.font, "NOVA CLIENT", 8, 8, 0xFF72D7FF, true);
                graphics.drawString(minecraft.font, fpsText, 8, 20, 0xFFFFFFFF, true);

                if (minecraft.player != null) {
                    String coords = String.format(
                        "XYZ: %.1f / %.1f / %.1f",
                        minecraft.player.getX(),
                        minecraft.player.getY(),
                        minecraft.player.getZ()
                    );
                    graphics.drawString(minecraft.font, coords, 8, 32, 0xFFFFFFFF, true);
                }
            }
        );
    }
}
