NOVA CLIENT — QUELLPROJEKT (NICHT DIE FERTIGE MOD-JAR)

Minecraft: Java 26.1.2
Modloader: Fabric
Java für den Build: JDK 25

WICHTIG:
- Diese ZIP ist Quellcode, keine direkt in FCL installierbare .jar.
- Sie wurde in dieser Umgebung nicht kompiliert oder im Spiel getestet.
- Der Build benötigt eine Entwicklungsumgebung mit Internetzugang und JDK 25.
- Installiere sie NICHT in FCL, indem du die ZIP in den mods-Ordner legst.

Was der erste Prototyp versucht:
- Nova-Client-Label
- FPS-Anzeige
- Koordinatenanzeige

Noch nicht enthalten:
- CPS-Zähler und Keystrokes
- Einstellungsmenü
- tatsächliche FPS-Optimierungs-Engine

Build-Schritte in einer kompatiblen Gradle-Umgebung:
1. Öffne den Projektordner.
2. Verwende JDK 25.
3. Führe `gradle build` aus (oder `./gradlew build`, wenn ein Gradle Wrapper hinzugefügt wurde).
4. Suche die erzeugte Datei in `build/libs/`.
5. Teste sie zuerst in einem separaten FCL-Profil und sichere deine Welten.

Wenn der Build fehlschlägt, teile die Fehlermeldung mit. Bitte keine unbekannten .jar-Dateien von Drittseiten installieren.
