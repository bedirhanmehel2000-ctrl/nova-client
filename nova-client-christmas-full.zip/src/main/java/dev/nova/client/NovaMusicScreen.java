package dev.nova.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Music player: tap a song to play it, no looping, and a different song always comes next. */
public final class NovaMusicScreen extends Screen {
    private final Screen parent;
    private final List<AbstractWidget> all = new ArrayList<>();
    private final List<Button> tracks = new ArrayList<>();
    private Button shuffleButton;
    private final long openedAt = System.currentTimeMillis();
    private int left;
    private int panelW;

    public NovaMusicScreen(Screen parent) {
        super(Component.literal("Nova Music"));
        this.parent = parent;
    }

    private Button add(Button b) {
        this.addRenderableWidget(b);
        all.add(b);
        return b;
    }

    private static Component trackLabel(int i) {
        String name = NovaMusic.SECONDS[i] > 0
                ? NovaMusic.NAMES[i] + "   " + NovaMusic.time(NovaMusic.SECONDS[i])
                : NovaMusic.NAMES[i];
        return Component.literal(i == NovaMusic.current() ? "\u00a7e\u25B6 " + name : name);
    }

    private Component shuffleLabel() {
        return Component.literal(NovaMusic.shuffle ? "\u00a7aSHUFFLE ON" : "\u00a7cSHUFFLE OFF");
    }

    @Override
    protected void init() {
        all.clear();
        tracks.clear();
        panelW = Math.min(this.width - 16, 420);
        left = (this.width - panelW) / 2;

        add(Button.builder(Component.literal("X"), b -> this.onClose())
                .bounds(left + panelW - 22, 7, 20, 18).build());

        // two columns: the Nova songs (and Christmas songs) first, then Minecraft's End and Nether music
        int rows = (NovaMusic.IDS.length + 1) / 2;
        int colGap = 3;
        int colW = (panelW - colGap) / 2;
        int rowH = Math.max(14, Math.min(22, (this.height - 76 - 34) / rows - 3));
        for (int i = 0; i < NovaMusic.IDS.length; i++) {
            final int index = i;
            int col = i / rows;
            int x = left + col * (colW + colGap);
            int y = 76 + (i % rows) * (rowH + 3);
            tracks.add(add(Button.builder(trackLabel(i), b -> {
                NovaMusic.play(index);
                refresh();
            }).bounds(x, y, colW, rowH).build()));
        }

        int by = this.height - 24;
        int bw = (panelW - 9) / 4;
        shuffleButton = add(Button.builder(shuffleLabel(), b -> {
            NovaMusic.shuffle = !NovaMusic.shuffle;
            refresh();
        }).bounds(left, by, bw, 20).build());
        add(Button.builder(Component.literal("PREV"), b -> {
            NovaMusic.previous();
            refresh();
        }).bounds(left + bw + 3, by, bw, 20).build());
        add(Button.builder(Component.literal("NEXT"), b -> {
            NovaMusic.next();
            refresh();
        }).bounds(left + 2 * (bw + 3), by, bw, 20).build());
        add(Button.builder(Component.literal("\u00a7cSTOP"), b -> {
            NovaMusic.stop();
            refresh();
        }).bounds(left + 3 * (bw + 3), by, bw, 20).build());
    }

    private void refresh() {
        for (int i = 0; i < tracks.size(); i++) {
            tracks.get(i).setMessage(trackLabel(i));
        }
        shuffleButton.setMessage(shuffleLabel());
    }

    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        SpaceUi.background(g, this.width, this.height, System.currentTimeMillis());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        Font font = this.font;
        SpaceUi.background(g, this.width, this.height, now);
        g.fill(left, 4, left + panelW, 28, 0xB0101A3A);
        SpaceUi.sun(g, left + 16, 16, 7, now);
        g.text(font, "N O V A   M U S I C", left + 36, 12, 0xFFFFFFFF, true);

        // now playing panel
        g.fill(left, 34, left + panelW, 70, 0xB00A1230);
        SpaceUi.outline(g, left, 34, panelW, 36, 0xFF2A3B7A);
        int current = NovaMusic.current();
        if (current >= 0) {
            g.text(font, NovaMusic.NAMES[current], left + 8, 40, 0xFFFFC857, true);
            int total = NovaMusic.SECONDS[current];
            int done = NovaMusic.elapsed();
            String time = total > 0 ? NovaMusic.time(done) + " / " + NovaMusic.time(total) : NovaMusic.time(done);
            g.text(font, time, left + panelW - font.width(time) - 8, 40, 0xFF8FA0D0, false);
            int barW = panelW - 16;
            g.fill(left + 8, 56, left + 8 + barW, 60, 0xFF1A2656);
            if (total > 0) {
                g.fill(left + 8, 56, left + 8 + (int) (barW * (done / (double) total)), 60, 0xFFFFC857);
            } else {
                // Minecraft tracks: length unknown, so a light sweeps along the bar
                int sweep = (int) ((now / 12) % barW);
                g.fill(left + 8 + sweep, 56, left + 8 + Math.min(barW, sweep + 24), 60, 0xFFFFC857);
            }
            for (int i = 0; i < 14; i++) {
                double h = 3 + 7 * Math.abs(Math.sin(now / 170.0 + i * 0.9) * Math.cos(now / 410.0 + i));
                int x = left + panelW / 2 - 52 + i * 8;
                g.fill(x, 52 - (int) h, x + 5, 52, 0xFF4D8DFF);
            }
            // Christmas songs show their lyrics under the progress bar
            if (current >= NovaMusic.XMAS_FIRST && current < NovaMusic.XMAS_FIRST + NovaMusic.XMAS_COUNT) {
                String line = Lyrics.current(current, NovaMusic.elapsed());
                if (line != null) {
                    g.text(font, line, left + (panelW - font.width(line)) / 2, 62, 0xFFFFF3C4, true);
                }
            }
        } else {
            g.text(font, "Nothing playing. Tap a song.", left + 8, 40, 0xFF8FA0D0, false);
            g.text(font, "Nova songs, Xmas songs with lyrics, then Minecraft music.", left + 8, 54, 0xFF6A7BB0, false);
        }

        SpaceUi.drawButtons(all, g, font, mouseX, mouseY);

        double fade = Math.max(0, Math.min(1, (now - openedAt) / 300.0));
        int alpha = (int) ((1 - fade) * 255);
        if (alpha > 0) {
            g.fill(0, 0, this.width, this.height, alpha << 24);
        }
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
