package dev.nova.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Live night skies drawn in code (no picture files): black sky, twinkling stars, two layers of waving
 * aurora curtains and a dark mountain ridge. Used for the title screen, the menus and the shop previews.
 * Everything stays inside the rectangle it is given, so it also works for small previews.
 */
final class LiveSky {
    /** Colour pairs: {bottom edge of the curtain, top of the curtain}. */
    private static final int[][] PALETTES = {
            {0x3CFF9A, 0x6A4BFF},   // northern lights: green fading to violet
            {0xC468FF, 0x3050FF},   // violet aurora
            {0xFF5F9E, 0x5B6CFF},   // rose aurora
    };
    static final String[] NAMES = {"Northern Lights", "Violet Aurora", "Rose Aurora"};

    private LiveSky() {
    }

    private static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    static void draw(GuiGraphicsExtractor g, int x0, int y0, int w, int h, long now, int style) {
        if (w < 4 || h < 4) {
            return;
        }
        int[] pal = PALETTES[Math.max(0, Math.min(PALETTES.length - 1, style))];
        double t = now / 1000.0;
        g.fill(x0, y0, x0 + w, y0 + h, 0xFF02030A);
        stars(g, x0, y0, w, h, now);
        // far curtain first (dimmer, slower), then the near one
        curtain(g, x0, y0, w, h, t * 0.7, pal, 0.55, 0.40, 1.7);
        curtain(g, x0, y0, w, h, t, pal, 0.90, 0.50, 0.0);
        // soft glow that gets stronger towards the horizon (the mountains are drawn over its lower edge)
        int glowBands = 14;
        for (int i = 0; i < glowBands; i++) {
            int a = 1 + i * 11 / glowBands;
            int ya = y0 + (int) (h * (0.62 + 0.26 * i / glowBands));
            int yb = y0 + (int) (h * (0.62 + 0.26 * (i + 1) / glowBands));
            g.fill(x0, ya, x0 + w, yb, (a << 24) | pal[0]);
        }
        mountains(g, x0, y0, w, h);
    }

    private static void stars(GuiGraphicsExtractor g, int x0, int y0, int w, int h, long now) {
        long seed = 13579L;
        int count = Math.max(20, Math.min(140, w * h / 3500));
        for (int i = 0; i < count; i++) {
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int x = (int) ((seed >>> 33) % w);
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int y = (int) ((seed >>> 33) % Math.max(1, (long) (h * 0.80)));
            int lum = 80 + (int) (170 * Math.abs(Math.sin(now / 700.0 + i * 1.7)));
            int size = (i % 11 == 0 && w > 200) ? 2 : 1;
            g.fill(x0 + x, y0 + y, x0 + x + size, y0 + y + size,
                    0xFF000000 | (lum << 16) | (lum << 8) | Math.min(255, lum + 25));
        }
    }

    /** One wavy curtain made of thin vertical strips that fade out towards the top. */
    private static void curtain(GuiGraphicsExtractor g, int x0, int y0, int w, int h, double t, int[] pal,
                                double strength, double baseLine, double offset) {
        int step = w > 300 ? 3 : 2;
        int segments = h > 120 ? 14 : 8;
        for (int x = 0; x < w; x += step) {
            double u = x / (double) w;
            double wave = Math.sin(u * 6.0 + t * 0.35 + offset) * 0.5
                    + Math.sin(u * 13.0 - t * 0.55 + offset * 2) * 0.3
                    + Math.sin(u * 3.1 + t * 0.15) * 0.2;
            double bottom = h * (baseLine + 0.12 * wave);
            double height = h * (0.26 + 0.14 * (Math.sin(u * 9.0 + t * 0.8 + offset) * 0.5 + 0.5));
            // vertical rays: brightness changes quickly from strip to strip and drifts sideways
            double rays = 0.5 + 0.5 * Math.sin(u * 55.0 + t * 1.3 + Math.sin(u * 5.0 + t * 0.4) * 2.0);
            rays = rays * rays;
            double edge = Math.min(1.0, Math.min(u, 1 - u) * 6.0 + 0.25);
            double intensity = Math.max(0.0, Math.min(1.0, (0.25 + 0.75 * rays) * edge * 1.25)) * strength;
            double top = bottom - height;
            for (int k = 0; k < segments; k++) {
                double f0 = k / (double) segments;
                double f1 = (k + 1) / (double) segments;
                double fm = (f0 + f1) / 2;
                int a = (int) (200 * intensity * Math.pow(fm, 1.8));
                if (a < 3) {
                    continue;
                }
                int ya = y0 + (int) (top + height * f0);
                int yb = y0 + (int) (top + height * f1);
                g.fill(x0 + x, ya, x0 + x + step, yb, (Math.min(255, a) << 24) | mix(pal[1], pal[0], fm));
            }
        }
    }

    private static void mountains(GuiGraphicsExtractor g, int x0, int y0, int w, int h) {
        int step = 3;
        for (int x = 0; x < w; x += step) {
            double u = x / (double) w;
            double ridge = h * (0.84 + 0.045 * Math.sin(u * 7.0 + 1.0) + 0.025 * Math.sin(u * 17.0)
                    + 0.015 * Math.sin(u * 41.0));
            int top = y0 + (int) ridge;
            g.fill(x0 + x, top, x0 + x + step, y0 + h, 0xFF010204);
        }
    }
}
