package dev.nova.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Christmas mode: a snowy night scene with lit trees, a light garland, falling snow and a sleigh that
 * flies across the moon. Everything is drawn in code. Used for the title screen, all Nova menus,
 * the welcome animation, the title logo and the lyrics under the Christmas songs.
 * Switch it off with the "Christmas mode" module.
 */
final class Xmas {
    private static final int[] BULBS = {0xFFFF4D5A, 0xFFFFC857, 0xFF4DE08A, 0xFF5AA8FF, 0xFFFF7AD0};
    private static final int[] LETTERS = {0xFFE23A47, 0xFFF4F8FF, 0xFF2FBF71};

    private Xmas() {
    }

    static boolean on() {
        try {
            return NovaTag.moduleOn("christmas");
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------------------------------------------------------------- scene

    static void scene(GuiGraphicsExtractor g, int x0, int y0, int w, int h, long now) {
        if (w < 8 || h < 8) {
            return;
        }
        // night sky: deep blue at the top, a cold teal glow at the horizon
        int bands = 32;
        for (int i = 0; i < bands; i++) {
            double t = i / (double) (bands - 1);
            int r = (int) (4 + 20 * t * t);
            int gr = (int) (8 + 52 * t * t);
            int b = (int) (30 + 70 * t);
            g.fill(x0, y0 + h * i / bands, x0 + w, y0 + h * (i + 1) / bands + 1,
                    0xFF000000 | (r << 16) | (gr << 8) | b);
        }
        stars(g, x0, y0, w, h, now);
        int moonR = Math.max(7, Math.min(24, h / 11));
        int mx = x0 + (int) (w * 0.80);
        int my = y0 + (int) (h * 0.17);
        for (int i = 8; i >= 1; i--) {
            SpaceUi.disk(g, mx, my, moonR + i * 3, ((2 + (8 - i)) << 24) | 0xBFD8FF);
        }
        SpaceUi.disk(g, mx, my, moonR, 0xFFF3F6FF);
        SpaceUi.disk(g, mx - moonR / 3, my - moonR / 4, Math.max(1, moonR / 5), 0xFFD8DFF2);
        SpaceUi.disk(g, mx + moonR / 3, my + moonR / 3, Math.max(1, moonR / 6), 0xFFDDE3F5);

        sleigh(g, x0, y0, w, h, now);

        // far hills, trees, near hills
        hills(g, x0, y0, w, h, 0.76, 0xFF7C9CCB, 0xFFA9C3E6, 3.0, 0.7);
        double[] treeX = {0.45, 0.58, 0.69, 0.80, 0.90, 0.97, 0.05};
        double[] treeH = {0.22, 0.32, 0.20, 0.36, 0.24, 0.30, 0.18};
        for (int i = 0; i < treeX.length; i++) {
            int base = y0 + (int) (h * (0.80 + 0.03 * Math.sin(i * 2.3)));
            tree(g, x0 + (int) (w * treeX[i]), base, (int) (h * treeH[i]), now, i);
        }
        hills(g, x0, y0, w, h, 0.90, 0xFFDDE9FB, 0xFFF4F8FF, 5.0, 1.9);

        garland(g, x0, y0, w, now);
        snow(g, x0, y0, w, h, now, Math.max(0.5, Math.min(2.5, w * h / (480.0 * 270.0))));
    }

    private static void stars(GuiGraphicsExtractor g, int x0, int y0, int w, int h, long now) {
        long seed = 24680L;
        int count = Math.max(20, Math.min(110, w * h / 4000));
        for (int i = 0; i < count; i++) {
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int x = (int) ((seed >>> 33) % w);
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int y = (int) ((seed >>> 33) % Math.max(1, (long) (h * 0.65)));
            int lum = 90 + (int) (160 * Math.abs(Math.sin(now / 800.0 + i * 1.9)));
            g.fill(x0 + x, y0 + y, x0 + x + 1, y0 + y + 1, 0xFF000000 | (lum << 16) | (lum << 8) | Math.min(255, lum + 20));
        }
    }

    /** A snowy hill line: a coloured body with a brighter edge on top. */
    private static void hills(GuiGraphicsExtractor g, int x0, int y0, int w, int h, double line, int body, int edge,
                              double freq, double phase) {
        int step = 3;
        for (int x = 0; x < w; x += step) {
            double u = x / (double) w;
            double ridge = h * (line + 0.035 * Math.sin(u * freq * 2.0 + phase) + 0.02 * Math.sin(u * freq * 5.0 + phase * 2));
            int top = y0 + (int) ridge;
            g.fill(x0 + x, top, x0 + x + step, y0 + h, body);
            g.fill(x0 + x, top, x0 + x + step, top + 2, edge);
        }
    }

    private static void tree(GuiGraphicsExtractor g, int cx, int baseY, int th, long now, int seed) {
        if (th < 12) {
            return;
        }
        int tiers = 4;
        double maxHalf = th * 0.30;
        g.fill(cx - 2, baseY - 1, cx + 3, baseY + 4, 0xFF4A2E1C);
        for (int row = 0; row < th; row++) {
            double p = row / (double) th;
            double tf = p * tiers;
            int tier = (int) tf;
            double frac = tf - tier;
            int half = (int) Math.max(1, maxHalf * (0.16 + 0.84 * ((tier + 0.3 + 0.7 * frac) / tiers)));
            int y = baseY - th + row;
            int color = frac > 0.88 ? 0xFF062A1E : (frac > 0.5 ? 0xFF0D4634 : 0xFF135A41);
            g.fill(cx - half, y, cx + half + 1, y + 1, color);
            if (frac < 0.16) {
                g.fill(cx - (int) (half * 0.75), y, cx + (int) (half * 0.75) + 1, y + 1, 0xFFE6F0FF);
            }
        }
        int lights = Math.max(8, th / 5);
        for (int k = 0; k < lights; k++) {
            double p = (k + 0.7) / (lights + 0.5);
            int row = (int) (p * th * 0.95);
            double tf = row / (double) th * tiers;
            int tier = (int) tf;
            double frac = tf - tier;
            double half = maxHalf * (0.16 + 0.84 * ((tier + 0.3 + 0.7 * frac) / tiers));
            int bx = cx + (int) (Math.sin(k * 2.17 + seed) * half * 0.8);
            int by = baseY - th + row;
            if (Math.sin(now / 350.0 + k * 1.9 + seed) > -0.35) {
                int c = BULBS[(k + seed) % BULBS.length];
                g.fill(bx - 1, by - 1, bx + 3, by + 3, 0x40000000 | (c & 0xFFFFFF));
                g.fill(bx, by, bx + 2, by + 2, c);
            }
        }
        // star on top
        int sy = baseY - th - 3;
        int tw = (int) (Math.abs(Math.sin(now / 420.0 + seed)) * 2);
        g.fill(cx - 1, sy - 4 - tw, cx + 2, sy + 5 + tw, 0xFFFFE066);
        g.fill(cx - 4 - tw, sy - 1, cx + 5 + tw, sy + 2, 0xFFFFE066);
        g.fill(cx - 1, sy - 1, cx + 2, sy + 2, 0xFFFFFFFF);
    }

    /** A string of coloured bulbs hanging in swags along the top of the screen. */
    private static void garland(GuiGraphicsExtractor g, int x0, int y0, int w, long now) {
        int segW = Math.max(60, w / 7);
        int sag = 10;
        for (int x = 0; x < w; x += 2) {
            double frac = (x % segW) / (double) segW;
            int y = y0 + 3 + (int) (sag * Math.sin(frac * Math.PI));
            g.fill(x0 + x, y, x0 + x + 2, y + 1, 0xFF0A2A1D);
        }
        for (int x = 7, k = 0; x < w; x += 14, k++) {
            double frac = (x % segW) / (double) segW;
            int y = y0 + 4 + (int) (sag * Math.sin(frac * Math.PI));
            int c = BULBS[k % BULBS.length];
            boolean lit = Math.sin(now / 300.0 + k * 1.3) > -0.4;
            if (lit) {
                g.fill(x0 + x - 3, y - 1, x0 + x + 5, y + 8, 0x30000000 | (c & 0xFFFFFF));
                g.fill(x0 + x - 1, y + 1, x0 + x + 3, y + 6, c);
            } else {
                g.fill(x0 + x - 1, y + 1, x0 + x + 3, y + 6, 0xFF2A2E3C);
            }
            g.fill(x0 + x, y, x0 + x + 2, y + 2, 0xFF0A2A1D);
        }
    }

    /** Santa's sleigh crosses the sky every 26 seconds. */
    private static void sleigh(GuiGraphicsExtractor g, int x0, int y0, int w, int h, long now) {
        double phase = (now % 26000L) / 9000.0;
        if (phase >= 1.0) {
            return;
        }
        int x = x0 - 50 + (int) ((w + 100) * phase);
        int y = y0 + (int) (h * 0.14 + Math.sin(phase * 7.0) * 5 + (1 - phase) * h * 0.05);
        // sparkles behind the sleigh
        for (int i = 1; i <= 16; i++) {
            int a = Math.max(0, 200 - i * 12);
            int sx = x - 10 - i * 5;
            int sy = y + 4 + (int) (Math.sin(now / 90.0 + i) * 3);
            g.fill(sx, sy, sx + 2, sy + 2, (a << 24) | 0xFFE9A8);
        }
        g.fill(x - 8, y + 5, x + 10, y + 6, 0xFFE0C060);
        g.fill(x - 7, y, x + 9, y + 5, 0xFF9A1C28);
        g.fill(x - 7, y, x + 9, y + 1, 0xFFC8283A);
        g.fill(x - 3, y - 5, x + 2, y - 2, 0xFFD8283A);
        g.fill(x - 3, y - 2, x + 2, y, 0xFFFFD2B0);
        g.fill(x - 3, y - 6, x - 2, y - 5, 0xFFFFFFFF);
        for (int d = 0; d < 2; d++) {
            int dx = x + 18 + d * 14;
            int bob = (int) (Math.sin(now / 160.0 + d) * 1.5);
            g.fill(x + 9, y + 3, dx, y + 4, 0xFFE0C060);
            g.fill(dx, y + 1 + bob, dx + 7, y + 4 + bob, 0xFF5A3A24);
            g.fill(dx + 6, y - 1 + bob, dx + 9, y + 2 + bob, 0xFF5A3A24);
            g.fill(dx + 6, y - 3 + bob, dx + 7, y - 1 + bob, 0xFF8A6A44);
            g.fill(dx + 8, y - 3 + bob, dx + 9, y - 1 + bob, 0xFF8A6A44);
            g.fill(dx, y + 4 + bob, dx + 1, y + 7, 0xFF3E2716);
            g.fill(dx + 5, y + 4 + bob, dx + 6, y + 7, 0xFF3E2716);
            if (d == 1) {
                g.fill(dx + 9, y + bob, dx + 11, y + 2 + bob, 0xFFFF3040);
            }
        }
    }

    // ---------------------------------------------------------------- snow

    static void snow(GuiGraphicsExtractor g, int x0, int y0, int w, int h, long now, double density) {
        double t = now / 1000.0;
        int[] base = {60, 38, 20};
        for (int layer = 0; layer < 3; layer++) {
            int count = (int) (base[layer] * density);
            long seed = 1000L + layer * 77L;
            int size = layer + 1;
            int alpha = layer == 0 ? 0x90 : layer == 1 ? 0xC8 : 0xF0;
            for (int i = 0; i < count; i++) {
                seed = seed * 6364136223846793005L + 1442695040888963407L;
                double fx = ((seed >>> 33) % 10000) / 10000.0;
                seed = seed * 6364136223846793005L + 1442695040888963407L;
                double fy = ((seed >>> 33) % 10000) / 10000.0;
                double speed = (10 + 14 * layer) * (0.8 + 0.4 * ((i * 37) % 10) / 10.0);
                double sway = Math.sin(t * (0.5 + 0.2 * layer) + i * 1.3) * (6 + 5 * layer);
                double x = ((fx * w + sway + t * (4 + 3 * layer)) % w + w) % w;
                double y = ((fy * h + t * speed) % h + h) % h;
                int px = x0 + (int) x;
                int py = y0 + (int) y;
                g.fill(px, py, px + size, py + size, (alpha << 24) | 0xFFFFFF);
                if (layer == 2 && i % 3 == 0) {
                    g.fill(px - 1, py + 1, px + 4, py + 2, 0x60FFFFFF);
                    g.fill(px + 1, py - 1, px + 2, py + 4, 0x60FFFFFF);
                }
            }
        }
    }

    /** Intro: a blizzard of flakes rushing out of the middle of the screen. */
    static void snowRush(GuiGraphicsExtractor g, int w, int h, long t) {
        double fade = Math.max(0, Math.min(1, t / 400.0)) * (1 - Math.max(0, Math.min(1, (t - 2000) / 800.0)));
        if (fade <= 0) {
            return;
        }
        int cx = w / 2;
        int cy = h / 2;
        double maxR = Math.hypot(w, h) / 2;
        for (int i = 0; i < 140; i++) {
            double angle = (i * 2.399963) % (Math.PI * 2);
            double base = 0.4 + ((i * 0.6180339) % 1.0);
            double head = Math.pow(((t / 1000.0) * base + (i % 7) / 7.0) % 1.0, 2) * maxR;
            if (head < 3) {
                continue;
            }
            int x = cx + (int) Math.round(Math.cos(angle) * head);
            int y = cy + (int) Math.round(Math.sin(angle) * head);
            int size = 1 + (int) (head / maxR * 3);
            g.fill(x, y, x + size, y + size, ((int) (fade * 255) << 24) | 0xEAF4FF);
        }
    }

    /** Gold and white sparkles around the title while it is shown. */
    static void sparkles(GuiGraphicsExtractor g, int cx, int cy, int rx, int ry, long now) {
        long seed = 777L;
        for (int i = 0; i < 34; i++) {
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            double a = ((seed >>> 33) % 10000) / 10000.0 * Math.PI * 2;
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            double r = 0.55 + ((seed >>> 33) % 1000) / 1000.0 * 0.6;
            double tw = Math.sin(now / 230.0 + i * 1.7);
            if (tw < 0.2) {
                continue;
            }
            int x = cx + (int) (Math.cos(a) * rx * r);
            int y = cy + (int) (Math.sin(a) * ry * r);
            int c = i % 2 == 0 ? 0xFFFFE066 : 0xFFFFFFFF;
            int len = 1 + (int) (tw * 3);
            g.fill(x - len, y, x + len + 1, y + 1, c);
            g.fill(x, y - len, x + 1, y + len + 1, c);
        }
    }

    // ---------------------------------------------------------------- logo, letters, text

    /** Colour of one pixel of a title letter: red, white and green letters with a bright wave. */
    static int letterColor(int row, int letter, int pixel, long now) {
        int base = LETTERS[letter % LETTERS.length];
        double shade = 1.12 - row * 0.07;
        int r = (int) Math.min(255, ((base >> 16) & 255) * shade);
        int gr = (int) Math.min(255, ((base >> 8) & 255) * shade);
        int b = (int) Math.min(255, (base & 255) * shade);
        if (Math.sin(now / 200.0 - (letter * 5 + pixel) * 0.5) > 0.93) {
            r = 255;
            gr = 245;
            b = 190;
        }
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    /** A red bauble with a gold cap, used instead of the sun in the logo. */
    static void ornament(GuiGraphicsExtractor g, int cx, int cy, int r, long now) {
        int pulse = 4 + (int) (3 * Math.abs(Math.sin(now / 600.0)));
        SpaceUi.disk(g, cx, cy, r + pulse, 0x20FF4050);
        SpaceUi.disk(g, cx, cy, r, 0xFFC8283A);
        SpaceUi.disk(g, cx - r / 4, cy - r / 4, Math.max(1, r / 3), 0xFFFF7A86);
        SpaceUi.disk(g, cx - r / 3, cy - r / 3, Math.max(1, r / 6), 0xFFFFFFFF);
        g.fill(cx - r, cy + r / 4, cx + r + 1, cy + r / 4 + Math.max(1, r / 5), 0x80FFE066);
        g.fill(cx - r / 3, cy - r - 3, cx + r / 3 + 1, cy - r + 1, 0xFFFFC857);
        g.fill(cx, cy - r - 6, cx + 1, cy - r - 3, 0xFFFFC857);
    }

    /** Text such as "36 days to Christmas", with colour codes. */
    static String countdown() {
        LocalDate today = LocalDate.now();
        LocalDate day = LocalDate.of(today.getYear(), 12, 25);
        long days = ChronoUnit.DAYS.between(today, day);
        if (days > 1) {
            return "§c" + days + " days §fto §aChristmas";
        }
        if (days == 1) {
            return "§cChristmas is tomorrow!";
        }
        if (days == 0) {
            return "§cM§fe§ar§cr§fy §aC§ch§fr§ai§cs§ft§am§ca§fs§a!";
        }
        return "§aMerry Christmas and happy new year!";
    }

    /** The line being sung (and the next one, dimmer) while a Christmas song plays. */
    static void lyrics(GuiGraphicsExtractor g, Font font, int centerX, int y) {
        int cur = NovaMusic.current();
        if (cur < NovaMusic.XMAS_FIRST || cur >= NovaMusic.XMAS_FIRST + NovaMusic.XMAS_COUNT) {
            return;
        }
        double t = NovaMusic.elapsed();
        String line = Lyrics.current(cur, t);
        if (line == null) {
            return;
        }
        g.text(font, line, centerX - font.width(line) / 2, y, 0xFFFFF3C4, true);
        String next = Lyrics.next(cur, t);
        if (next != null) {
            g.text(font, next, centerX - font.width(next) / 2, y + 11, 0xFF8090B8, false);
        }
    }
}
