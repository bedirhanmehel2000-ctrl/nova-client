package dev.nova.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Cosmetic shop: a card grid with a preview panel. Everything is free and only you can see it. */
public final class NovaShopScreen extends Screen {
    private static final String[] TABS = {"CAPES", "WINGS", "BADGE", "COLOR", "TRAIL", "LOOK", "BG"};
    private static final String[] KEYS = {"cape", "wings", "badge", "color", "trail", "look", "bg"};
    private static final int GAP = 4;

    private static int tab = 0;

    private record Rect(int x, int y, int w, int h, int index) {
    }

    private final Screen parent;
    private final List<AbstractWidget> all = new ArrayList<>();
    private final List<Rect> rects = new ArrayList<>();
    private final long openedAt = System.currentTimeMillis();
    private int left;
    private int panelW;
    private int gridW;
    private int top;
    private int availH;

    public NovaShopScreen(Screen parent) {
        super(Component.literal("Nova Shop"));
        this.parent = parent;
    }

    private Button add(Button b) {
        this.addRenderableWidget(b);
        all.add(b);
        return b;
    }

    private String[] names() {
        return switch (tab) {
            case 0 -> Cosmetics.CAPE_NAMES;
            case 1 -> Cosmetics.WING_NAMES;
            case 2 -> Cosmetics.BADGE_NAMES;
            case 3 -> Cosmetics.COLOR_NAMES;
            case 4 -> Cosmetics.TRAIL_NAMES;
            case 5 -> Cosmetics.LOOK_NAMES;
            default -> Cosmetics.BG_NAMES;
        };
    }

    private static Identifier capeTexture(int index) {
        return Identifier.fromNamespaceAndPath(NovaClient.MOD_ID, "textures/cape/" + Cosmetics.CAPE_IDS[index] + ".png");
    }

    @Override
    protected void init() {
        all.clear();
        rects.clear();
        panelW = Math.min(this.width - 16, 480);
        left = (this.width - panelW) / 2;
        gridW = panelW - 120;
        top = 58;
        availH = this.height - 30 - top;

        add(Button.builder(Component.literal("X"), b -> this.onClose())
                .bounds(left + panelW - 22, 7, 20, 18).build());

        int chipW = (panelW - 3 * (TABS.length - 1)) / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            final int index = i;
            String label = (i == tab ? "§e" : "") + TABS[i];
            add(Button.builder(Component.literal(label), b -> {
                tab = index;
                this.rebuildWidgets();
            }).bounds(left + i * (chipW + 3), 34, chipW, 16).build());
        }

        String[] names = names();
        int cols = tab == 0 ? 5 : tab == 6 ? 3 : 4;
        int rows = (names.length + cols - 1) / cols;
        int cw = (gridW - GAP * (cols - 1)) / cols;
        int ch = Math.max(40, Math.min(78, (availH - GAP * (rows - 1)) / rows));
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            int x = left + (i % cols) * (cw + GAP);
            int y = top + (i / cols) * (ch + GAP);
            rects.add(new Rect(x, y, cw, ch, i));
            // invisible click area (not drawn by us, only used for taps)
            this.addRenderableWidget(Button.builder(Component.literal(""), b -> Cosmetics.set(KEYS[tab], index))
                    .bounds(x, y, cw, ch).build());
        }

        add(Button.builder(Component.literal("Back"), b -> this.onClose())
                .bounds(left, this.height - 24, 80, 20).build());
    }

    private String fit(String text, int maxWidth) {
        String shown = text;
        while (this.font.width(shown) > maxWidth && shown.length() > 1) {
            shown = shown.substring(0, shown.length() - 1);
        }
        return shown;
    }

    private int coloredText(GuiGraphicsExtractor g, Font font, String text, int colorIndex, int x, int y) {
        if (colorIndex != Cosmetics.RAINBOW) {
            g.text(font, text, x, y, 0xFF000000 | Cosmetics.COLORS[colorIndex], true);
            return x + font.width(text);
        }
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            g.text(font, ch, x, y, 0xFF000000 | Cosmetics.hue((i * 0.09f) % 1f), true);
            x += font.width(ch);
        }
        return x;
    }

    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        SpaceUi.background(g, this.width, this.height, System.currentTimeMillis());
    }

    private void drawCard(GuiGraphicsExtractor g, Font font, Rect r, boolean selected, boolean hover, long now) {
        g.fill(r.x(), r.y(), r.x() + r.w(), r.y() + r.h(), hover ? 0xD0202C70 : 0xC00E1636);
        SpaceUi.outline(g, r.x(), r.y(), r.w(), r.h(),
                selected ? 0xFFFFC857 : hover ? 0xFF8FB4FF : 0xFF2A3B7A);
        int i = r.index();
        int cx = r.x() + r.w() / 2;
        int imgH = r.h() - 16;
        switch (tab) {
            case 0 -> {
                if (i == 0) {
                    g.text(font, "X", cx - font.width("X") / 2, r.y() + imgH / 2, 0xFF8FA0D0, false);
                } else {
                    int ih = imgH - 4;
                    int iw = ih * 10 / 16;
                    SpaceUi.image(g, capeTexture(i), cx - iw / 2, r.y() + 4, iw, ih, 1, 1, 10, 16, 64, 32);
                }
            }
            case 1 -> {
                if (i == 0) {
                    g.text(font, "X", cx - font.width("X") / 2, r.y() + imgH / 2, 0xFF8FA0D0, false);
                } else {
                    double px = Math.max(6, Math.min((r.w() - 6) / 3.6, imgH / 2.7));
                    drawWings(g, cx, r.y() + 3 + (int) (0.85 * px), i, px, now);
                }
            }
            case 2 -> {
                String b = Cosmetics.BADGES[i];
                g.text(font, b, cx - font.width(b) / 2, r.y() + imgH / 2 - 2, 0xFFFFB84D, true);
            }
            case 3 -> {
                int sw = Math.min(r.w() - 12, 36);
                if (i == Cosmetics.RAINBOW) {
                    for (int k = 0; k < sw; k++) {
                        g.fill(cx - sw / 2 + k, r.y() + 6, cx - sw / 2 + k + 1, r.y() + imgH - 2,
                                0xFF000000 | Cosmetics.hue(k / (float) sw));
                    }
                } else {
                    g.fill(cx - sw / 2, r.y() + 6, cx + sw / 2, r.y() + imgH - 2, 0xFF000000 | Cosmetics.COLORS[i]);
                }
            }
            case 4 -> {
                if (i == 0) {
                    g.text(font, "X", cx - font.width("X") / 2, r.y() + imgH / 2, 0xFF8FA0D0, false);
                } else {
                    for (int k = 0; k < 7; k++) {
                        double t = ((now / 25.0 + k * 13) % 40) / 40.0;
                        int px = cx - 14 + (k * 9) % 28;
                        int py = r.y() + imgH - 2 - (int) (t * (imgH - 8));
                        g.fill(px, py, px + 3, py + 3, Cosmetics.TRAIL_COLORS[i]);
                    }
                }
            }
            case 6 -> bgThumb(g, i, r.x() + 4, r.y() + 4, r.w() - 8, imgH - 4);
            default -> {
                int sw = Math.min(r.w() - 12, 36);
                g.fill(cx - sw / 2, r.y() + 6, cx + sw / 2, r.y() + imgH - 2, 0xFF6EA8E8);
                if (Cosmetics.LOOK_TINTS[i] != 0) {
                    g.fill(cx - sw / 2, r.y() + 6, cx + sw / 2, r.y() + imgH - 2, Cosmetics.LOOK_TINTS[i] | 0x40000000);
                }
            }
        }
        if (selected) {
            int pulse = 60 + (int) (50 * Math.sin(now / 250.0));
            SpaceUi.outline(g, r.x() - 1, r.y() - 1, r.w() + 2, r.h() + 2, (pulse << 24) | 0xFFC857);
            g.text(font, "\u2714", r.x() + r.w() - 10, r.y() + 3, 0xFF55FF55, true);
        }
        String name = names()[i];
        String label = fit(name, r.w() - 4);
        g.text(font, label, cx - font.width(label) / 2, r.y() + r.h() - 11, selected ? 0xFFFFC857 : 0xFFFFFFFF, false);
    }

    /**
     * Draws the wings from behind using the same shape as the particles. pixels = pixels per block.
     * shoulderY is the screen y of the shoulder.
     */
    private void drawWings(GuiGraphicsExtractor g, int cx, int shoulderY, int style, double pixels, long now) {
        if (style == Cosmetics.DEMON) {
            demon(g, cx, shoulderY, pixels * 0.8, now);
            return;
        }
        int feathers = style == Cosmetics.INFERNO ? 9 : Cosmetics.FEATHERS;
        double flap = Math.sin(now / 330.0) * 0.28;
        int base = Cosmetics.WING_COLORS[style];
        int tip = Cosmetics.WING_TIP_COLORS[style];
        int dot = Math.max(1, (int) Math.round(pixels * 0.16));
        for (int side = -1; side <= 1; side += 2) {
            for (int step = 0; step <= 14; step++) {
                double[] p = Cosmetics.wingPoint(-1, step / 14.0, flap, feathers);
                put(g, cx, shoulderY, side, p, pixels, dot + 1, base);
            }
            for (int k = 0; k < feathers; k++) {
                for (int step = 0; step <= 10; step++) {
                    double s = step / 10.0;
                    double[] p = Cosmetics.wingPoint(k, s, flap, feathers);
                    int color = mixColor(base, tip, s);
                    if (style == Cosmetics.INFERNO && s < 0.25) {
                        color = mixColor(0xFFFFE066, base, s / 0.25);
                    }
                    put(g, cx, shoulderY, side, p, pixels, dot, color);
                }
            }
        }
    }

    private static void bgThumb(GuiGraphicsExtractor g, int index, int x, int y, int w, int h) {
        if (index >= Cosmetics.BG_LIVE_FIRST) {
            LiveSky.draw(g, x, y, w, h, System.currentTimeMillis(), index - Cosmetics.BG_LIVE_FIRST);
            return;
        }
        String file = Cosmetics.BG_FILES[index];
        if (index == 0) {
            file = "space";
        }
        Identifier id = Identifier.fromNamespaceAndPath(NovaClient.MOD_ID, "textures/gui/" + file + ".png");
        SpaceUi.image(g, id, x, y, w, h, 0, 0, 2560, 1440, 2560, 1440);
    }

    private static void demon(GuiGraphicsExtractor g, int cx, int shoulderY, double pixels, long now) {
        double flap = Math.sin(now / 330.0) * 0.28;
        for (int side = -1; side <= 1; side += 2) {
            java.util.Random rnd = new java.util.Random(77);
            int[] counts = {24, 40, 120, 40, 36};
            int[] colors = {0xFF2A0A10, 0xFF3A0C12, 0xFFB01826, 0xFF8A0F18, 0xFFE03030};
            for (int kind = 0; kind < counts.length; kind++) {
                int size = kind == 2 || kind == 3 ? 2 : Math.max(2, (int) Math.round(pixels * 0.14));
                for (int n = 0; n < counts[kind]; n++) {
                    double[] p = Cosmetics.demonPoint(kind, rnd, flap);
                    put(g, cx, shoulderY, side, p, pixels, size, colors[kind]);
                }
            }
        }
    }

    private static void put(GuiGraphicsExtractor g, int cx, int shoulderY, int side, double[] p, double pixels,
                            int size, int color) {
        int x = cx + (int) Math.round(side * p[0] * pixels);
        int y = shoulderY - (int) Math.round((p[1] - 1.35) * pixels);
        g.fill(x, y, x + size, y + size, color);
    }

    private static int mixColor(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int gr = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }

    private void drawPreview(GuiGraphicsExtractor g, Font font, int px, int py, int pw, int ph, int item, long now) {
        g.fill(px, py, px + pw, py + ph, 0xB00A1230);
        SpaceUi.outline(g, px, py, pw, ph, 0xFF2A3B7A);
        int cx = px + pw / 2;
        int selected = Cosmetics.get(KEYS[tab], names().length);
        boolean equipped = item == selected;
        int colorIdx = tab == 3 ? item : Cosmetics.colorIndex();
        int badgeIdx = tab == 2 ? item : Cosmetics.get("badge", Cosmetics.BADGES.length);
        int capeIdx = tab == 0 ? item : Cosmetics.cape();

        if (tab == 0) {
            int s = Math.max(2, Math.min(4, (ph - 52) / 16));
            int dh = 16 * s;
            int dw = 10 * s;
            int headY = py + 6;
            g.fill(cx - 7, headY, cx + 7, headY + 14, 0xFFC9A27E);
            g.fill(cx - 7, headY, cx + 7, headY + 4, 0xFF3B2A1E);
            int bodyY = headY + 16;
            g.fill(cx - dw / 2 - 3, bodyY, cx + dw / 2 + 3, bodyY + dh, 0xFF2B4F9E);
            if (capeIdx != 0) {
                SpaceUi.image(g, capeTexture(capeIdx), cx - dw / 2, bodyY, dw, dh, 1, 1, 10, 16, 64, 32);
            }
        } else if (tab == 5) {
            int bx = px + 6;
            int bw = pw - 12;
            int by = py + 8;
            int bh = 54;
            g.fill(bx, by, bx + bw, by + bh, 0xFF6EA8E8);
            g.fill(bx, by + bh - 14, bx + bw, by + bh, 0xFF4C8C3A);
            g.fill(bx + 8, by + bh - 26, bx + 18, by + bh - 14, 0xFF7A5230);
            g.fill(bx + 4, by + bh - 36, bx + 22, by + bh - 24, 0xFF2F7A2F);
            if (Cosmetics.LOOK_TINTS[item] != 0) {
                g.fill(bx, by, bx + bw, by + bh, Cosmetics.LOOK_TINTS[item]);
            }
            if (item != 0) {
                for (int k = 1; k <= 5; k++) {
                    int t = k * 2;
                    g.fill(bx, by, bx + bw, by + t, 0x30000010);
                    g.fill(bx, by + bh - t, bx + bw, by + bh, 0x30000010);
                    g.fill(bx, by, bx + t, by + bh, 0x30000010);
                    g.fill(bx + bw - t, by, bx + bw, by + bh, 0x30000010);
                }
            }
        } else if (tab == 1) {
            g.fill(cx - 6, py + 8, cx + 6, py + 20, 0xFFC9A27E);
            g.fill(cx - 6, py + 8, cx + 6, py + 11, 0xFF3B2A1E);
            g.fill(cx - 6, py + 20, cx + 6, py + 52, 0xFF2B4F9E);
            if (item != 0) {
                double px2 = Math.max(10, Math.min((pw - 8) / 3.6, (ph - 70) / 2.6));
                drawWings(g, cx, py + 24, item, px2, now);
            }
        } else if (tab == 6) {
            bgThumb(g, item, px + 6, py + 8, pw - 12, Math.min(ph - 40, (pw - 12) * 9 / 16));
        } else if (tab == 4) {
            g.fill(cx - 7, py + 24, cx + 7, py + 38, 0xFFC9A27E);
            g.fill(cx - 7, py + 38, cx + 7, py + 64, 0xFF2B4F9E);
            if (item != 0) {
                for (int k = 0; k < 14; k++) {
                    double t = ((now / 22.0 + k * 11) % 56) / 56.0;
                    int ox = ((k * 17) % 26) - 13;
                    int y = py + 66 - (int) (t * 50);
                    g.fill(cx + ox, y, cx + ox + 3, y + 3, Cosmetics.TRAIL_COLORS[item]);
                }
            }
        } else {
            String badge = Cosmetics.BADGES[badgeIdx];
            int x = px + 6;
            g.text(font, "Nametag", x, py + 8, 0xFF8FA0D0, false);
            g.text(font, badge + " ", x, py + 20, 0xFFFFB84D, true);
            int nx = x + font.width(badge + " ");
            nx = coloredText(g, font, "[" + NovaClient.config.rank + "] ", colorIdx, nx, py + 20);
            g.text(font, "You", nx, py + 20, 0xFFFFFFFF, true);
            g.text(font, "Chat", x, py + 38, 0xFF8FA0D0, false);
            g.text(font, badge + " ", x, py + 50, 0xFFFFB84D, true);
            nx = x + font.width(badge + " ");
            nx = coloredText(g, font, "Nova ", colorIdx, nx, py + 50);
            g.text(font, "You: hi", nx, py + 50, 0xFFFFFFFF, true);
        }

        String name = fit(names()[item], pw - 8);
        g.text(font, name, cx - font.width(name) / 2, py + ph - 24, 0xFFFFFFFF, true);
        String status = equipped ? "EQUIPPED" : "Tap to equip";
        g.text(font, status, cx - font.width(status) / 2, py + ph - 12, equipped ? 0xFF55FF55 : 0xFF8FA0D0, false);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        Font font = this.font;
        SpaceUi.background(g, this.width, this.height, now);
        g.fill(left, 4, left + panelW, 28, 0xB0101A3A);

        int selected = Cosmetics.get(KEYS[tab], names().length);
        int hover = -1;
        for (Rect r : rects) {
            boolean over = mouseX >= r.x() && mouseX < r.x() + r.w() && mouseY >= r.y() && mouseY < r.y() + r.h();
            if (over) {
                hover = r.index();
            }
            drawCard(g, font, r, r.index() == selected, over, now);
        }
        drawPreview(g, font, left + gridW + 8, top, panelW - gridW - 8, availH, hover >= 0 ? hover : selected, now);

        SpaceUi.drawButtons(all, g, font, mouseX, mouseY);

        SpaceUi.sun(g, left + 16, 16, 7, now);
        g.text(font, "N O V A   S H O P", left + 36, 12, 0xFFFFFFFF, true);
        String free = "Everything here is free";
        g.text(font, free, left + panelW - font.width(free), this.height - 18, 0xFF8FA0D0, false);

        double fade = Math.max(0, Math.min(1, (now - openedAt) / 300.0));
        int alpha = (int) ((1 - fade) * 255);
        if (alpha > 0) {
            g.fill(0, 0, this.width, this.height, alpha << 24);
        }
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
