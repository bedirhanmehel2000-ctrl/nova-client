package dev.nova.client;

/** Lyrics of the Nova Christmas songs. Generated together with the audio so the timing matches. */
final class Lyrics {
    private Lyrics() {
    }

    private static final double[] T0 = {3.6, 7.2, 10.8, 14.4, 18.0, 21.6, 25.2, 28.8, 32.4, 36.0, 39.6, 43.2, 46.8, 50.4, 54.0, 57.6};
    private static final double END0 = 61.2;
    private static final String[] L0 = {
            "Snow is falling on the stars tonight",
            "Every window wears a golden light",
            "Little flakes are dancing down to say",
            "Merry Christmas, welcome to the day",
            "Ring the bells across the silver sky",
            "Reindeer racing as the comets fly",
            "Hold your friends and hold them close and near",
            "Christmas is the best time of the year",
            "Lanterns glow along the frozen shore",
            "Cocoa warm and carols at the door",
            "Wrap a wish in ribbons red and green",
            "Brightest present that we've ever seen",
            "Build a castle white as moonlit sleet",
            "Stockings hang above the fire's heat",
            "Every heart is filled with joy and cheer",
            "Merry Christmas, Nova, join us here"
    };

    private static final double[] T1 = {3.81, 7.62, 11.43, 15.24, 19.05, 22.86, 26.67, 30.48, 34.29, 38.1, 41.9, 45.71, 49.52, 53.33, 57.14, 60.95};
    private static final double END1 = 64.76;
    private static final String[] L1 = {
            "Hitch the stars up to the sleigh tonight",
            "We are flying through the silver light",
            "Bells are ringing out across the black",
            "Santa waves as he comes circling back",
            "Over moons and rings of frozen blue",
            "Every wish is racing to come true",
            "Hear the jingle on the solar breeze",
            "Christmas joy across the galaxies",
            "Lights are blinking on the roof below",
            "Footprints twinkling in the glowing snow",
            "Chimney sparks and cookies on the plate",
            "Reindeer hurry, we can't be late",
            "Pass the presents, sing a little more",
            "Open up the sky and then the door",
            "Ring the bells and let the whole world hear",
            "Merry Christmas, and a happy new year"
    };

    private static final double[] T2 = {5.45, 10.91, 16.36, 21.82, 27.27, 32.73, 38.18, 43.64, 49.09, 54.55, 60.0, 65.45, 70.91, 76.36, 81.82, 87.27};
    private static final double END2 = 92.73;
    private static final String[] L2 = {
            "Silent stars above the sleeping town",
            "Snowflakes settle softly, drifting down",
            "Candles glowing gold in every pane",
            "Peace is whispering in the winter lane",
            "Carry me through midnight, calm and bright",
            "Every heart is warm on Christmas night",
            "Hush the world and let the old bells chime",
            "Christmas gives us all a little time",
            "Evergreen and holly on the door",
            "Stories by the fire, and one more",
            "Faraway friends are never far apart",
            "Christmas lives inside the heart",
            "Hold the light and share it, give it away",
            "Winter holds a spark for every day",
            "Silent stars, we're singing now for you",
            "Merry Christmas, and good night, from Nova too"
    };

    /** Index of the line that is sung at this time, or -1 before the first and after the last line. */
    private static int index(double[] times, double end, double t) {
        if (t < times[0] || t >= end) {
            return -1;
        }
        int idx = 0;
        for (int i = 0; i < times.length; i++) {
            if (t >= times[i]) {
                idx = i;
            }
        }
        return idx;
    }

    /** The line being sung (track = index in NovaMusic), or null if the track has no lyrics right now. */
    static String current(int track, double seconds) {
        return pick(track, seconds, 0);
    }

    /** The line that comes next, or null. */
    static String next(int track, double seconds) {
        return pick(track, seconds, 1);
    }

    private static String pick(int track, double t, int offset) {
        switch (track - 9) {
            case 0: {
                int i = index(T0, END0, t) + offset;
                return index(T0, END0, t) < 0 || i >= L0.length ? null : L0[i];
            }
            case 1: {
                int i = index(T1, END1, t) + offset;
                return index(T1, END1, t) < 0 || i >= L1.length ? null : L1[i];
            }
            case 2: {
                int i = index(T2, END2, t) + offset;
                return index(T2, END2, t) < 0 || i >= L2.length ? null : L2[i];
            }
            default:
                return null;
        }
    }
}
