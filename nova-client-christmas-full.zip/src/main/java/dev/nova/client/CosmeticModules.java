package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Switches for the cosmetics. What you pick is chosen in the shop. */
final class CosmeticModules {
    private CosmeticModules() {
    }

    static final class ChatTag extends Module {
        ChatTag() {
            super("chat_tag", "Nova chat tag", "Sun badge and Nova in front of your chat name.",
                    Category.VISUAL, true);
        }
    }

    static final class Trail extends Module {
        Trail() {
            super("trail", "Particle trail", "Particles follow you. Pick one in the shop.",
                    Category.VISUAL, true);
        }

        @Override
        public void tick(Minecraft mc) {
            Cosmetics.tickTrail(mc);
        }
    }

    static final class TitleScreenModule extends Module {
        TitleScreenModule() {
            super("title_screen", "Nova title screen", "Black hole main menu. Applies the next time the title opens.",
                    Category.VISUAL, true);
        }
    }

    static final class Christmas extends Module {
        Christmas() {
            super("christmas", "Christmas mode",
                    "Snow, lights, a Christmas welcome and Christmas songs in the Nova menus. Replaces the menu background.",
                    Category.VISUAL, true);
        }
    }

    static final class MenuSound extends Module {
        MenuSound() {
            super("menu_sound", "Menu sounds", "Space whoosh and ambient sound in the Nova menu.",
                    Category.VISUAL, true);
        }
    }

    static final class Wings extends Module {
        Wings() {
            super("wings", "Wings", "Particle wings on your back. Pick a style in the shop.",
                    Category.VISUAL, true);
        }

        @Override
        public void tick(Minecraft mc) {
            Cosmetics.tickWings(mc);
        }
    }

    static final class NameGlow extends Module {
        NameGlow() {
            super("name_glow", "Name glow", "A bright wave runs through your nametag and chat tag.",
                    Category.VISUAL, true);
        }
    }

    static final class BodyGlow extends Module {
        BodyGlow() {
            super("body_glow", "Body glow", "Glowing outline around you (third person). Costs some FPS.",
                    Category.VISUAL, false);
        }
    }

    /** Cheap "shader" look: a color tint and dark edges drawn on top of the screen. */
    static final class NovaLook extends Module {
        NovaLook() {
            super("nova_look", "Nova look", "Color tint and soft edges, almost no FPS cost. Pick in the shop.",
                    Category.VISUAL, true);
        }

        static void draw(GuiGraphicsExtractor g, int w, int h) {
            if (!NovaTag.moduleOn("nova_look")) {
                return;
            }
            int look = Cosmetics.look();
            if (look == 0) {
                return;
            }
            int tint = Cosmetics.LOOK_TINTS[look];
            if (tint != 0) {
                int baseAlpha = (tint >>> 24) & 0xFF;
                int rgb = tint & 0xFFFFFF;
                int bands = 8;
                for (int i = 0; i < bands; i++) {
                    // lighter at the top, stronger at the bottom: a soft gradient instead of a flat colour
                    int a = (int) (baseAlpha * (0.35 + 1.15 * i / (bands - 1.0)));
                    g.fill(0, h * i / bands, w, h * (i + 1) / bands + 1, (Math.min(255, a) << 24) | rgb);
                }
            }
            int step = Math.max(2, Math.min(w, h) / 26);
            for (int i = 1; i <= 6; i++) {
                int t = i * step;
                int c = tint != 0 ? ((0x18 << 24) | (tint & 0x3F3F3F)) : 0x16000010;
                g.fill(0, 0, w, t, c);
                g.fill(0, h - t, w, h, c);
                g.fill(0, 0, t, h, c);
                g.fill(w - t, 0, w, h, c);
            }
        }
    }
}
