package dev.nova.client;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.List;

/** All modules of Nova Client. */
public final class Modules {
    private Modules() {
    }

    public static List<Module> create() {
        return List.of(
                // HUD
                new Fps(),
                new Cps(),
                new Coords(),
                new Direction(),
                new Clock(),
                // PvP
                new Keystrokes(),
                new Armor(),
                new Potions(),
                new Ping(),
                new TargetDistance(),
                new ToggleSprint(),
                new PvpModules.LowFire(),
                new PvpModules.NoHurtCam(),
                new PvpModules.Combo(),
                new PvpModules.CrystalItems(),
                new PvpModules.TargetHealth(),
                new PvpModules.Saturation(),
                new PvpModules.Speed(),
                new PvpModules.MemoryUse(),
                // Visual
                new NightVision(),
                new NametagBadge(),
                new OptionModule("zoom", "Zoom (FOV 30)", "Narrow field of view for a zoomed look.",
                        Category.VISUAL, "fov", "30", false),
                // FPS boost
                new AllTweaks(),
                new OptionModule("low_distance", "Render distance 6", "Loads fewer chunks. Big FPS gain.",
                        Category.FPS, "renderDistance", "6", true),
                new OptionModule("min_particles", "Minimal particles", "Far fewer particles.",
                        Category.FPS, "particles", "MINIMAL", false),
                new OptionModule("no_clouds", "Clouds off", "No clouds in the sky.",
                        Category.FPS, "cloudStatus", "OFF", false),
                new OptionModule("no_shadows", "Entity shadows off", "No shadows under mobs and players.",
                        Category.FPS, "entityShadows", "false", false),
                new OptionModule("entity_distance", "Entity distance low", "Draws far entities less often.",
                        Category.FPS, "entityDistanceScaling", "0.5", false),
                new OptionModule("fast_graphics", "Fast graphics", "Simple graphics mode (if available).",
                        Category.FPS, "graphicsMode", "FAST", false),
                new OptionModule("biome_blend", "Biome blend off", "Faster chunk colors.",
                        Category.FPS, "biomeBlendRadius", "0", false),
                new OptionModule("vsync_off", "VSync off", "Uncapped frames (may tear).",
                        Category.FPS, "enableVsync", "false", false),
                new OptionModule("no_bobbing", "View bobbing off", "No camera sway while walking.",
                        Category.VISUAL, "bobView", "false", false)
        );
    }

    // ---------------------------------------------------------------- HUD

    /** FPS counter. Counts frames and rebuilds its text only twice per second. */
    static final class Fps extends Module {
        private int frames;
        private long windowStart;
        private String text = "FPS: --";

        Fps() {
            super("fps", "FPS counter", "Shows your frames per second.", Category.HUD, true, 4, 4);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            if (windowStart == 0 || now - windowStart > 5000) {
                windowStart = now;
                frames = 0;
            }
            frames++;
            long elapsed = now - windowStart;
            if (elapsed >= 500) {
                text = "FPS: " + (frames * 1000L / elapsed);
                frames = 0;
                windowStart = now;
            }
            line(g, font, text, x, y);
        }
    }

    /** Clicks per second for attack (left) and use (right). */
    static final class Cps extends Module {
        private final ArrayDeque<Long> left = new ArrayDeque<>();
        private final ArrayDeque<Long> right = new ArrayDeque<>();
        private boolean leftDown;
        private boolean rightDown;
        private int shownLeft = -1;
        private int shownRight = -1;
        private String text = "CPS: 0 | 0";

        Cps() {
            super("cps", "CPS counter", "Clicks per second (left | right).", Category.HUD, true, 4, 16);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            boolean l = mc.options.keyAttack.isDown();
            if (l && !leftDown) {
                left.addLast(now);
            }
            leftDown = l;
            boolean r = mc.options.keyUse.isDown();
            if (r && !rightDown) {
                right.addLast(now);
            }
            rightDown = r;
            while (!left.isEmpty() && now - left.peekFirst() > 1000) {
                left.pollFirst();
            }
            while (!right.isEmpty() && now - right.peekFirst() > 1000) {
                right.pollFirst();
            }
            if (left.size() != shownLeft || right.size() != shownRight) {
                shownLeft = left.size();
                shownRight = right.size();
                text = "CPS: " + shownLeft + " | " + shownRight;
            }
            line(g, font, text, x, y);
        }
    }

    /** XYZ coordinates. */
    static final class Coords extends Module {
        private long lastKey = Long.MIN_VALUE;
        private String text = "XYZ: --";

        Coords() {
            super("coords", "Coordinates", "Shows your X, Y and Z position.", Category.HUD, true, 4, 28);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            var player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            double px = player.getX();
            double py = player.getY();
            double pz = player.getZ();
            long key = Math.round(px * 10) * 961L + Math.round(py * 10) * 31L + Math.round(pz * 10);
            if (key != lastKey) {
                lastKey = key;
                text = String.format("XYZ: %.1f / %.1f / %.1f", px, py, pz);
            }
            line(g, font, text, x, y);
        }
    }

    /** Facing direction. */
    static final class Direction extends Module {
        Direction() {
            super("direction", "Direction", "Shows which way you are facing.", Category.HUD, false, 4, 40);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            var player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            String dir = player.getDirection().getName();
            String shown = dir.substring(0, 1).toUpperCase() + dir.substring(1);
            float yaw = ((player.getYRot() % 360f) + 360f) % 360f;
            line(g, font, String.format("Facing: %s (%.0f)", shown, yaw), x, y);
        }
    }

    /** Real-world clock. */
    static final class Clock extends Module {
        private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("HH:mm");

        Clock() {
            super("clock", "Clock", "Shows the real time.", Category.HUD, false, 4, 52);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            line(g, font, "Time: " + LocalTime.now().format(FORMAT), x, y);
        }
    }

    // ---------------------------------------------------------------- PvP

    /** WASD plus left/right mouse buttons. Keys light up while held. */
    static final class Keystrokes extends Module {
        private static final int BOX = 18;
        private static final int GAP = 2;

        Keystrokes() {
            super("keystrokes", "Keystrokes", "Shows WASD and mouse clicks.", Category.PVP, true, 4, 68);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            var options = Minecraft.getInstance().options;
            int step = BOX + GAP;
            key(g, font, "W", options.keyUp, x + step, y, BOX);
            key(g, font, "A", options.keyLeft, x, y + step, BOX);
            key(g, font, "S", options.keyDown, x + step, y + step, BOX);
            key(g, font, "D", options.keyRight, x + step * 2, y + step, BOX);
            int wide = (BOX * 3 + GAP) / 2;
            key(g, font, "LMB", options.keyAttack, x, y + step * 2, wide);
            key(g, font, "RMB", options.keyUse, x + wide + GAP, y + step * 2, wide);
        }

        private static void key(GuiGraphicsExtractor g, Font font, String label, KeyMapping mapping,
                                int x, int y, int width) {
            boolean down = mapping.isDown();
            g.fill(x, y, x + width, y + BOX, down ? 0xC0FFFFFF : 0x80000000);
            int textX = x + (width - font.width(label)) / 2;
            g.text(font, label, textX, y + (BOX - 8) / 2, down ? 0xFF000000 : 0xFFFFFFFF, false);
        }
    }

    /** Durability of worn armor. */
    static final class Armor extends Module {
        private static final EquipmentSlot[] SLOTS = {
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        private static final String[] NAMES = {"Helmet", "Chest", "Legs", "Boots"};

        Armor() {
            super("armor", "Armor status", "Shows durability of your armor.", Category.PVP, false, 120, 4);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            var player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            int row = 0;
            for (int i = 0; i < SLOTS.length; i++) {
                ItemStack stack = player.getItemBySlot(SLOTS[i]);
                if (stack.isEmpty()) {
                    continue;
                }
                int max = stack.getMaxDamage();
                String value = max > 0 ? (max - stack.getDamageValue()) + "/" + max : "ok";
                line(g, font, NAMES[i] + ": " + value, x, y + row * 12);
                row++;
            }
            if (row == 0) {
                line(g, font, "Armor: none", x, y);
            }
        }
    }

    /** Active potion effects with time left. */
    static final class Potions extends Module {
        Potions() {
            super("potions", "Potion status", "Shows your effects and time left.", Category.PVP, false, 120, 60);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            var player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            int row = 0;
            for (MobEffectInstance effect : player.getActiveEffects()) {
                int ticks = effect.getDuration();
                if (ticks > 500000) {
                    continue;
                }
                String name = effect.getEffect().value().getDisplayName().getString();
                int amp = effect.getAmplifier();
                String time = ticks < 0 ? "**:**" : String.format("%d:%02d", ticks / 1200, (ticks / 20) % 60);
                line(g, font, name + (amp > 0 ? " " + (amp + 1) : "") + " " + time, x, y + row * 12);
                row++;
            }
            if (row == 0) {
                line(g, font, "Effects: none", x, y);
            }
        }
    }

    /** Ping to the server. */
    static final class Ping extends Module {
        Ping() {
            super("ping", "Ping", "Shows your ping to the server.", Category.PVP, false, 4, 120);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            String text = "Ping: --";
            if (mc.player != null && mc.getConnection() != null) {
                var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (info != null) {
                    text = "Ping: " + info.getLatency() + " ms";
                }
            }
            line(g, font, text, x, y);
        }
    }

    /** Distance to the entity under the crosshair. */
    static final class TargetDistance extends Module {
        TargetDistance() {
            super("reach", "Target distance", "Distance to the player you aim at.", Category.PVP, false, 4, 132);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) {
                return;
            }
            Entity target = mc.crosshairPickEntity;
            line(g, font, target == null ? "Reach: --" : String.format("Reach: %.2f", mc.player.distanceTo(target)),
                    x, y);
        }
    }

    /** Holds sprint for you while you walk forward. */
    static final class ToggleSprint extends Module {
        ToggleSprint() {
            super("toggle_sprint", "Toggle sprint", "Sprints automatically while walking forward.",
                    Category.PVP, false);
        }

        @Override
        public void tick(Minecraft mc) {
            if (mc.player == null) {
                return;
            }
            mc.options.keySprint.setDown(mc.options.keyUp.isDown());
        }

        @Override
        public void onDisable(Minecraft mc) {
            mc.options.keySprint.setDown(false);
        }
    }

    // ---------------------------------------------------------------- Visual

    /** Full brightness like a night vision potion (only on your screen). */
    static final class NightVision extends Module {
        NightVision() {
            super("night_vision", "Night vision", "Bright everywhere, even in caves.", Category.VISUAL, false);
        }

        @Override
        public void tick(Minecraft mc) {
            if (mc.player != null && !mc.player.hasEffect(MobEffects.NIGHT_VISION)) {
                mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1000000, 0, false, false, false));
            }
        }

        @Override
        public void onDisable(Minecraft mc) {
            if (mc.player != null) {
                mc.player.removeEffect(MobEffects.NIGHT_VISION);
            }
        }
    }

    /** Only a switch: the mixins in dev.nova.client.mixin read it. */
    static final class NametagBadge extends Module {
        NametagBadge() {
            super("nametag", "Nova nametag", "Sun badge and blue rank above your name.", Category.VISUAL, true);
        }
    }

    // ---------------------------------------------------------------- Settings based modules

    /** Changes one video setting while enabled and restores it when disabled. */
    static final class OptionModule extends Module {
        private final String option;
        private final String value;
        private final boolean onlyIfHigher;

        OptionModule(String id, String name, String description, Category category,
                     String option, String value, boolean onlyIfHigher) {
            super(id, name, description, category, false);
            this.option = option;
            this.value = value;
            this.onlyIfHigher = onlyIfHigher;
        }

        @Override
        public void onEnable(Minecraft mc) {
            OptionTweaks.apply(option, value, onlyIfHigher);
        }

        @Override
        public void onDisable(Minecraft mc) {
            OptionTweaks.restore(option);
        }
    }

    /** Switches every FPS tweak on or off at once. */
    static final class AllTweaks extends Module {
        AllTweaks() {
            super("all_tweaks", "ALL FPS tweaks", "Turns every FPS tweak below on or off.", Category.FPS, false);
        }

        @Override
        public void onEnable(Minecraft mc) {
            set(true);
        }

        @Override
        public void onDisable(Minecraft mc) {
            set(false);
        }

        private void set(boolean on) {
            for (Module m : NovaClient.MODULES) {
                if (m != this && m instanceof OptionModule && m.category == Category.FPS) {
                    m.setEnabled(on);
                }
            }
        }
    }
}
