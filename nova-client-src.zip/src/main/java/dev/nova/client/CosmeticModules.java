package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Switches for the cosmetics. What you pick is chosen in the shop. */
final class CosmeticModules {
    private CosmeticModules() {
    }

    static final class ChatTag extends Module {
        ChatTag() {
            super("chat_tag", "Nova chat tag", "Sun badge and Nova in front of your chat name.",
                    Category.VISUAL, true);
        }
    }

    static final class Trail extends Module {
        Trail() {
            super("trail", "Particle trail", "Particles follow you. Pick one in the shop.",
                    Category.VISUAL, true);
        }

        @Override
        public void tick(Minecraft mc) {
            Cosmetics.tickTrail(mc);
        }
    }

    /** Cheap "shader" look: a color tint and dark edges drawn on top of the screen. */
    static final class NovaLook extends Module {
        NovaLook() {
            super("nova_look", "Nova look", "Color tint and soft edges, almost no FPS cost. Pick in the shop.",
                    Category.VISUAL, true);
        }

        static void draw(GuiGraphicsExtractor g, int w, int h) {
            if (!NovaTag.moduleOn("nova_look")) {
                return;
            }
            int look = Cosmetics.look();
            if (look == 0) {
                return;
            }
            int tint = switch (look) {
                case 1 -> 0x1C3060FF;
                case 2 -> 0x1CFF9A30;
                case 3 -> 0x28FF7A3D;
                case 4 -> 0x340A0A50;
                default -> 0;
            };
            if (tint != 0) {
                g.fill(0, 0, w, h, tint);
            }
            int step = Math.max(2, Math.min(w, h) / 26);
            for (int i = 1; i <= 6; i++) {
                int t = i * step;
                int c = 0x16000010;
                g.fill(0, 0, w, t, c);
                g.fill(0, h - t, w, h, c);
                g.fill(0, 0, t, h, c);
                g.fill(w - t, 0, w, h, c);
            }
        }
    }
}
