package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.lang.reflect.Field;

/** Extra PvP and utility modules (all are display or comfort features, nothing that gives an unfair edge). */
final class PvpModules {
    private PvpModules() {
    }

    private static Field hurtField;
    private static boolean hurtSearched;

    /** Reads hurtTime by name so a rename can never break the build. Returns 0 if not found. */
    static int hurtTime(Object living) {
        try {
            if (!hurtSearched) {
                hurtSearched = true;
                hurtField = LivingEntity.class.getField("hurtTime");
            }
            return hurtField == null ? 0 : hurtField.getInt(living);
        } catch (Throwable t) {
            hurtField = null;
            return 0;
        }
    }

    static void setHurtTime(Object living, int value) {
        try {
            if (!hurtSearched) {
                hurtSearched = true;
                hurtField = LivingEntity.class.getField("hurtTime");
            }
            if (hurtField != null) {
                hurtField.setInt(living, value);
            }
        } catch (Throwable t) {
            hurtField = null;
        }
    }

    /** Fire overlay is hidden by EntityFireMixin while this is on. */
    static final class LowFire extends Module {
        LowFire() {
            super("low_fire", "Low fire", "Hides the big fire on your screen while you burn.", Category.PVP, true);
        }
    }

    /** Removes the camera shake when you get hit. */
    static final class NoHurtCam extends Module {
        NoHurtCam() {
            super("no_hurt_cam", "No hurt shake", "No camera shake when you take damage.", Category.PVP, false);
        }

        @Override
        public void tick(Minecraft mc) {
            if (mc.player != null) {
                setHurtTime(mc.player, 0);
            }
        }
    }

    /** Counts your hits in a row until the enemy hits you back. */
    static final class Combo extends Module {
        private int combo;
        private long lastHit;
        private boolean attackDown;
        private long attackAt;
        private int lastTargetHurt;
        private int lastSelfHurt;

        Combo() {
            super("combo", "Combo counter", "Hits in a row before you get hit.", Category.PVP, false, 4, 148);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) {
                return;
            }
            boolean down = mc.options.keyAttack.isDown();
            if (down && !attackDown) {
                attackAt = now;
            }
            attackDown = down;

            Entity t = mc.crosshairPickEntity;
            if (t instanceof LivingEntity living) {
                int h = hurtTime(living);
                if (h > lastTargetHurt && now - attackAt < 600) {
                    combo++;
                    lastHit = now;
                }
                lastTargetHurt = h;
            } else {
                lastTargetHurt = 0;
            }

            int self = hurtTime(mc.player);
            if (self > lastSelfHurt) {
                combo = 0;
            }
            lastSelfHurt = self;
            if (now - lastHit > 3000) {
                combo = 0;
            }
            line(g, font, "Combo: " + combo, x, y);
        }
    }

    /** Counts the items crystal PvPers care about. */
    static final class CrystalItems extends Module {
        private static final Item[] ITEMS = {Items.END_CRYSTAL, Items.OBSIDIAN, Items.TOTEM_OF_UNDYING,
                Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.EXPERIENCE_BOTTLE};
        private static final String[] NAMES = {"Crystals", "Obsidian", "Totems", "Pearls", "Gapples", "XP"};

        CrystalItems() {
            super("crystal_items", "Crystal items", "Counts crystals, obsidian, totems, pearls, gapples, XP.",
                    Category.PVP, false, 240, 4);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) {
                return;
            }
            int[] counts = new int[ITEMS.length];
            int size = mc.player.getInventory().getContainerSize();
            for (int i = 0; i < size; i++) {
                ItemStack stack = mc.player.getInventory().getItem(i);
                if (stack.isEmpty()) {
                    continue;
                }
                for (int k = 0; k < ITEMS.length; k++) {
                    if (stack.is(ITEMS[k])) {
                        counts[k] += stack.getCount();
                    }
                }
            }
            for (int k = 0; k < ITEMS.length; k++) {
                line(g, font, NAMES[k] + ": " + counts[k], x, y + k * 12);
            }
        }
    }

    /** Name and health of the player you hit or aim at. */
    static final class TargetHealth extends Module {
        private LivingEntity last;
        private long seenAt;

        TargetHealth() {
            super("target_health", "Target health", "Health of the player you are fighting.",
                    Category.PVP, false, 120, 130);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) {
                return;
            }
            if (mc.crosshairPickEntity instanceof LivingEntity living) {
                last = living;
                seenAt = now;
            }
            if (last == null || now - seenAt > 3000 || !last.isAlive()) {
                line(g, font, "Target: --", x, y);
                return;
            }
            float hp = last.getHealth();
            float max = Math.max(1f, last.getMaxHealth());
            String text = last.getName().getString() + "  " + String.format("%.1f", hp) + " / "
                    + String.format("%.0f", max);
            line(g, font, text, x, y);
            int width = Math.max(60, font.width(text));
            int fill = (int) (width * Math.max(0f, Math.min(1f, hp / max)));
            g.fill(x - 2, y + 11, x + width + 2, y + 15, 0x80000000);
            int color = hp / max > 0.5f ? 0xFF35C98A : hp / max > 0.25f ? 0xFFFFC857 : 0xFFE0506A;
            g.fill(x, y + 12, x + fill, y + 14, color);
        }
    }

    /** Food and saturation. */
    static final class Saturation extends Module {
        Saturation() {
            super("saturation", "Saturation", "Shows your hunger and saturation.", Category.HUD, false, 240, 84);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) {
                return;
            }
            line(g, font, "Food: " + mc.player.getFoodData().getFoodLevel() + "  Sat: "
                    + String.format("%.1f", mc.player.getFoodData().getSaturationLevel()), x, y);
        }
    }

    /** Horizontal speed in blocks per second. */
    static final class Speed extends Module {
        Speed() {
            super("speed", "Speed", "Your speed in blocks per second.", Category.HUD, false, 4, 160);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) {
                return;
            }
            double speed = mc.player.getDeltaMovement().horizontalDistance() * 20.0;
            line(g, font, String.format("Speed: %.2f b/s", speed), x, y);
        }
    }

    /** Memory used by the game. */
    static final class MemoryUse extends Module {
        MemoryUse() {
            super("memory", "Memory", "Shows RAM used by the game.", Category.HUD, false, 240, 98);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Runtime rt = Runtime.getRuntime();
            long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
            long max = rt.maxMemory() / 1048576L;
            line(g, font, "RAM: " + used + " / " + max + " MB", x, y);
        }
    }
}
