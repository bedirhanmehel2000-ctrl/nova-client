package dev.nova.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** FPS counter. Counts frames and rebuilds its text only twice per second. */
public final class FpsModule extends HudModule {
    private int frames;
    private long windowStart;
    private String text = "FPS: --";

    public FpsModule() {
        super("fps", "FPS counter", 4, 4);
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, Font font, int x, int y, long nowMs) {
        if (windowStart == 0 || nowMs - windowStart > 5000) {
            windowStart = nowMs;
            frames = 0;
        }
        frames++;
        long elapsed = nowMs - windowStart;
        if (elapsed >= 500) {
            text = "FPS: " + (frames * 1000L / elapsed);
            frames = 0;
            windowStart = nowMs;
        }
        line(graphics, font, text, x, y);
    }
}
