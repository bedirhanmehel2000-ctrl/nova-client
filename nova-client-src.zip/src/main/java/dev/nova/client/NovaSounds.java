package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

/**
 * Space sounds for the Nova screens: a whoosh when the menu opens and a quiet ambient loop while any Nova
 * screen is open. Everything is looked up by name, so if sounds work differently in this version the game
 * just stays silent instead of crashing.
 */
public final class NovaSounds {
    private static final long AMBIENT_MS = 40000;

    private static final Map<String, Object> EVENTS = new HashMap<>();
    private static Method forUi;
    private static boolean forUiThreeArgs;
    private static boolean searched;
    private static boolean failed;
    private static int errors;

    private static Object ambient;
    private static long ambientStart;

    private NovaSounds() {
    }

    private static boolean isNovaScreen(Screen s) {
        return s instanceof NovaMenuScreen || s instanceof NovaShopScreen || s instanceof HudEditScreen
                || s instanceof NovaTitleScreen;
    }

    private static Object event(String name) throws Exception {
        Object event = EVENTS.get(name);
        if (event != null) {
            return event;
        }
        Identifier id = Identifier.fromNamespaceAndPath(NovaClient.MOD_ID, name);
        Class<?> type = Class.forName("net.minecraft.sounds.SoundEvent");
        for (Method m : type.getMethods()) {
            if (Modifier.isStatic(m.getModifiers()) && m.getName().equals("createVariableRangeEvent")
                    && m.getParameterCount() == 1 && m.getParameterTypes()[0] == Identifier.class) {
                event = m.invoke(null, id);
                break;
            }
        }
        if (event == null) {
            for (Constructor<?> c : type.getConstructors()) {
                if (c.getParameterCount() == 1 && c.getParameterTypes()[0] == Identifier.class) {
                    event = c.newInstance(id);
                    break;
                }
            }
        }
        if (event != null) {
            EVENTS.put(name, event);
        }
        return event;
    }

    private static Object instance(Object event, float volume) throws Exception {
        if (!searched) {
            searched = true;
            Class<?> type = Class.forName("net.minecraft.client.resources.sounds.SimpleSoundInstance");
            for (Method m : type.getMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (Modifier.isStatic(m.getModifiers()) && m.getName().equals("forUI") && p.length >= 2
                        && p[0].isInstance(event) && p[1] == float.class
                        && (p.length == 2 || (p.length == 3 && p[2] == float.class))) {
                    if (forUi == null || p.length == 3) {
                        forUi = m;
                        forUiThreeArgs = p.length == 3;
                    }
                }
            }
        }
        if (forUi == null) {
            return null;
        }
        return forUiThreeArgs ? forUi.invoke(null, event, 1.0f, volume) : forUi.invoke(null, event, 1.0f);
    }

    private static Method soundManagerMethod(Object manager, String name, Object argument) {
        for (Method m : manager.getClass().getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == 1 && m.getParameterTypes()[0].isInstance(argument)) {
                return m;
            }
        }
        return null;
    }

    private static Object play(Minecraft mc, String name, float volume) {
        if (failed || !NovaTag.moduleOn("menu_sound")) {
            return null;
        }
        try {
            Object event = event(name);
            if (event == null) {
                failed = true;
                return null;
            }
            Object instance = instance(event, volume);
            if (instance == null) {
                failed = true;
                return null;
            }
            Object manager = mc.getSoundManager();
            Method play = soundManagerMethod(manager, "play", instance);
            if (play == null) {
                failed = true;
                return null;
            }
            play.invoke(manager, instance);
            return instance;
        } catch (Throwable t) {
            errors++;
            if (errors >= 4) {
                failed = true;
                NovaClient.LOGGER.warn("Nova sounds are not available in this version", t);
            }
            return null;
        }
    }

    private static void stopAmbient(Minecraft mc) {
        if (ambient == null) {
            return;
        }
        try {
            Object manager = mc.getSoundManager();
            Method stop = soundManagerMethod(manager, "stop", ambient);
            if (stop != null) {
                stop.invoke(manager, ambient);
            }
        } catch (Throwable ignored) {
            // nothing to stop
        }
        ambient = null;
    }

    /** The whoosh when the Nova menu opens. */
    public static void whoosh() {
        play(Minecraft.getInstance(), "menu_open", 1.0f);
    }

    /** Called every tick: starts, repeats and stops the ambient space sound. */
    static void tick(Minecraft mc) {
        if (failed) {
            return;
        }
        long now = System.currentTimeMillis();
        boolean wanted = isNovaScreen(mc.screen) && NovaTag.moduleOn("menu_sound");
        if (!wanted) {
            stopAmbient(mc);
            return;
        }
        if (ambient == null || now - ambientStart >= AMBIENT_MS - 150) {
            Object next = play(mc, "menu_ambient", 1.0f);
            if (next != null) {
                ambient = next;
                ambientStart = now;
            }
        }
    }
}
