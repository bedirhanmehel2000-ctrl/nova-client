package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/** The free cosmetics you can pick in the shop. Everything here is only visible to you. */
public final class Cosmetics {
    public static final String[] BADGE_NAMES = {"Sun", "Star", "Heart", "Moon", "Spark", "Crown", "Bolt", "Flower"};
    public static final String[] BADGES = {"☀", "★", "❤", "☾", "✦", "♛", "⚡",
            "✿"};

    public static final String[] COLOR_NAMES = {"Blue", "Gold", "Pink", "Green", "Red", "Purple", "White", "Rainbow"};
    public static final int[] COLORS = {0x4D8DFF, 0xFFB84D, 0xFF6FB5, 0x35C98A, 0xE0506A, 0xB06CFF, 0xFFFFFF, -1};
    public static final int RAINBOW = 7;

    public static final String[] TRAIL_NAMES = {"Off", "Hearts", "Flames", "Stars", "Magic", "Leaves", "Soul fire"};
    private static final String[] TRAIL_PARTICLES = {null, "HEART", "FLAME", "END_ROD", "ENCHANT",
            "HAPPY_VILLAGER", "SOUL_FIRE_FLAME"};
    public static final int[] TRAIL_COLORS = {0xFF555566, 0xFFFF5577, 0xFFFF8A1E, 0xFFFFF3B0, 0xFFB06CFF,
            0xFF35C98A, 0xFF4DE0FF};

    public static final String[] WING_NAMES = {"No wings", "Angel", "Inferno", "Ender", "Soul", "Magic"};
    // per style: bone particle, feather particle, tip particle, accent particle
    private static final String[][] WING_PARTICLES = {
            {null, null, null, null},
            {"END_ROD", "END_ROD", "END_ROD", "CLOUD"},
            {"FLAME", "FLAME", "LAVA", "SMOKE"},
            {"WITCH", "WITCH", "ENCHANT", "PORTAL"},
            {"SOUL_FIRE_FLAME", "SOUL_FIRE_FLAME", "SOUL", "SOUL_FIRE_FLAME"},
            {"ENCHANT", "ENCHANT", "END_ROD", "HAPPY_VILLAGER"}};
    public static final int[] WING_COLORS = {0xFF555566, 0xFFEAF2FF, 0xFFFF8A1E, 0xFFB06CFF, 0xFF4DE0FF, 0xFF9AF0FF};
    public static final int[] WING_TIP_COLORS = {0xFF555566, 0xFFFFFFFF, 0xFFFFE066, 0xFFFF7AF0, 0xFFB8F4FF,
            0xFFFFFFFF};
    public static final int INFERNO = 2;

    public static final String[] CAPE_NAMES = {"No cape", "Nova Sun", "Galaxy", "Neon Storm", "Pink Void", "Rainbow",
            "Ice", "Fire", "Royal"};
    public static final String[] CAPE_IDS = {"none", "nova_sun", "galaxy", "neon_storm", "pink_void", "rainbow",
            "ice", "fire", "royal"};

    public static final String[] LOOK_NAMES = {"Off", "Cool", "Warm", "Sunrise", "Night", "Vignette"};
    public static final int[] LOOK_TINTS = {0, 0x1C3060FF, 0x1CFF9A30, 0x28FF7A3D, 0x340A0A50, 0};

    private static final Map<String, Object> PARTICLES = new HashMap<>();
    private static final Set<String> BAD = new HashSet<>();
    private static Method addParticle;
    private static boolean searched;
    private static Field bodyYaw;
    private static boolean bodyYawSearched;

    private Cosmetics() {
    }

    public static int get(String key, int max) {
        try {
            String v = NovaClient.config.cosmetics.get(key);
            if (v != null) {
                return Math.max(0, Math.min(max - 1, Integer.parseInt(v)));
            }
        } catch (Throwable ignored) {
            // use default
        }
        return 0;
    }

    public static void set(String key, int value) {
        NovaClient.config.cosmetics.put(key, String.valueOf(value));
        NovaClient.config.save();
    }

    public static String badge() {
        return BADGES[get("badge", BADGES.length)];
    }

    public static int colorIndex() {
        return get("color", COLORS.length);
    }

    public static int cape() {
        return get("cape", CAPE_IDS.length);
    }

    public static int look() {
        return get("look", LOOK_NAMES.length);
    }

    public static int trail() {
        return get("trail", TRAIL_NAMES.length);
    }

    public static int wings() {
        return get("wings", WING_NAMES.length);
    }

    /** Hue (0..1) to a plain RGB color. */
    public static int hue(float h) {
        float r = clamp(Math.abs(h * 6 - 3) - 1);
        float g = clamp(2 - Math.abs(h * 6 - 2));
        float b = clamp(2 - Math.abs(h * 6 - 4));
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Bold text in the chosen color. With Name glow on, a bright wave runs through the letters. */
    public static Component colored(String text) {
        int index = colorIndex();
        boolean glow = NovaTag.moduleOn("name_glow");
        if (index != RAINBOW && !glow) {
            int color = COLORS[index];
            return Component.literal(text).withStyle(s -> s.withColor(color).withBold(true));
        }
        long now = System.currentTimeMillis();
        MutableComponent out = Component.literal("");
        for (int i = 0; i < text.length(); i++) {
            int color;
            if (index == RAINBOW) {
                color = hue((i * 0.09f + now / 3000f) % 1f);
            } else {
                color = COLORS[index];
            }
            if (glow) {
                double wave = (Math.sin(now / 180.0 - i * 0.8) + 1) / 2;
                color = mix(color, 0xFFFFFF, Math.pow(wave, 4) * 0.85);
            }
            final int c = color;
            out.append(Component.literal(String.valueOf(text.charAt(i)))
                    .withStyle(s -> s.withColor(c).withBold(true)));
        }
        return out;
    }

    // ---------------------------------------------------------------- particles (looked up by name)

    private static void spawn(Minecraft mc, String name, double x, double y, double z,
                              double vx, double vy, double vz) {
        if (name == null || BAD.contains(name) || mc.level == null) {
            return;
        }
        try {
            Object particle = PARTICLES.get(name);
            if (particle == null) {
                try {
                    particle = Class.forName("net.minecraft.core.particles.ParticleTypes").getField(name).get(null);
                } catch (Throwable t) {
                    BAD.add(name);
                    return;
                }
                PARTICLES.put(name, particle);
            }
            if (!searched) {
                searched = true;
                Class<?> options = Class.forName("net.minecraft.core.particles.ParticleOptions");
                int bestScore = -1;
                for (Method m : mc.level.getClass().getMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    boolean always = m.getName().equals("addAlwaysVisibleParticle");
                    if (!(always || m.getName().equals("addParticle")) || p.length < 7 || p[0] != options) {
                        continue;
                    }
                    boolean ok = true;
                    for (int i = 1; i < p.length; i++) {
                        boolean last6 = i >= p.length - 6;
                        ok = ok && (last6 ? p[i] == double.class : p[i] == boolean.class);
                    }
                    int score = (always ? 100 : 0) + (p.length > 7 ? 1 : 0);
                    if (ok && score > bestScore) {
                        bestScore = score;
                        addParticle = m;
                    }
                }
                if (addParticle == null) {
                    NovaClient.LOGGER.warn("Particles (trail and wings) not available in this version");
                }
            }
            if (addParticle == null) {
                return;
            }
            if (!addParticle.getParameterTypes()[0].isInstance(particle)) {
                BAD.add(name);
                return;
            }
            int count = addParticle.getParameterCount();
            Object[] args = new Object[count];
            args[0] = particle;
            for (int i = 1; i < count - 6; i++) {
                args[i] = i == 1 ? Boolean.TRUE : Boolean.FALSE;   // first flag = force (ignore Minimal particles)
            }
            int d = count - 6;
            args[d] = x;
            args[d + 1] = y;
            args[d + 2] = z;
            args[d + 3] = vx;
            args[d + 4] = vy;
            args[d + 5] = vz;
            addParticle.invoke(mc.level, args);
        } catch (Throwable t) {
            addParticle = null;
            searched = true;
            NovaClient.LOGGER.warn("Particle failed", t);
        }
    }

    public static void tickTrail(Minecraft mc) {
        int trail = trail();
        if (trail == 0 || mc.player == null || mc.level == null) {
            return;
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int n = 0; n < 2; n++) {
            spawn(mc, TRAIL_PARTICLES[trail],
                    mc.player.getX() + rnd.nextDouble(-0.35, 0.35),
                    mc.player.getY() + rnd.nextDouble(0.1, 1.6),
                    mc.player.getZ() + rnd.nextDouble(-0.35, 0.35),
                    rnd.nextDouble(-0.02, 0.02), rnd.nextDouble(0.0, 0.05), rnd.nextDouble(-0.02, 0.02));
        }
    }

    /** Direction your body faces, in radians. Falls back to where you look. */
    private static double bodyYawRadians(Minecraft mc) {
        try {
            if (!bodyYawSearched) {
                bodyYawSearched = true;
                bodyYaw = net.minecraft.world.entity.LivingEntity.class.getField("yBodyRot");
            }
            if (bodyYaw != null) {
                return Math.toRadians(bodyYaw.getFloat(mc.player));
            }
        } catch (Throwable t) {
            bodyYaw = null;
        }
        return Math.toRadians(mc.player.getYRot());
    }

    public static final int FEATHERS = 7;
    private static final double SHOULDER_L = 0.15;
    private static final double SHOULDER_H = 1.35;

    /**
     * A point on one wing, in body coordinates: {sideways, height, backwards}.
     * feather = -1 is the bone (s runs along it); feather 0..FEATHERS-1 hangs down from the bone (s is 0 at the bone).
     * flap rotates the whole wing around the shoulder.
     */
    public static double[] wingPoint(int feather, double s, double flap, int feathers) {
        double u = feather < 0 ? s : 0.08 + 0.84 * feather / (double) (feathers - 1);
        double l = SHOULDER_L + 1.55 * u;
        double h = SHOULDER_H + 0.8 * Math.sin(u * Math.PI * 0.75) * (1 - 0.15 * u);
        double back = 0.28 + 0.22 * u;
        if (feather >= 0) {
            double len = 0.75 + 0.95 * Math.sin(Math.PI * (feather + 0.7) / (feathers + 0.4));
            l += s * (0.12 + 0.34 * u) + Math.sin(s * Math.PI) * 0.1;
            h -= s * len;
            back += s * 0.1;
        }
        double dl = l - SHOULDER_L;
        double dh = h - SHOULDER_H;
        double c = Math.cos(flap);
        double sn = Math.sin(flap);
        double l2 = SHOULDER_L + dl * c - dh * sn;
        double h2 = SHOULDER_H + dl * sn + dh * c;
        double back2 = back + Math.sin(flap) * dl * 0.35;
        return new double[]{l2, h2, back2};
    }

    /**
     * Big wings made of particles: a bone along the top, feathers hanging down from it, glowing tips
     * and extra sparks. Inferno has nine feathers, double density, flying embers and smoke. They flap slowly.
     */
    public static void tickWings(Minecraft mc) {
        int style = wings();
        if (style == 0 || mc.player == null || mc.level == null) {
            return;
        }
        double yaw = bodyYawRadians(mc);
        double backX = Math.sin(yaw);
        double backZ = -Math.cos(yaw);
        double rightX = -Math.cos(yaw);
        double rightZ = -Math.sin(yaw);
        double flap = Math.sin(System.currentTimeMillis() / 300.0) * 0.20;
        double px = mc.player.getX();
        double py = mc.player.getY() + (mc.player.isCrouching() ? -0.25 : 0.0);
        double pz = mc.player.getZ();
        String[] set = WING_PARTICLES[style];
        boolean inferno = style == INFERNO;
        int feathers = inferno ? 9 : FEATHERS;
        int perFeather = inferno ? 2 : 1;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int side = -1; side <= 1; side += 2) {
            for (int n = 0; n < 3; n++) {
                double[] p = wingPoint(-1, rnd.nextDouble(), flap, feathers);
                emit(mc, set[0], px, py, pz, backX, backZ, rightX, rightZ, side, p, 0, 0);
            }
            for (int k = 0; k < feathers; k++) {
                for (int n = 0; n < perFeather; n++) {
                    double[] p = wingPoint(k, rnd.nextDouble(0.05, 1.0), flap, feathers);
                    emit(mc, set[1], px, py, pz, backX, backZ, rightX, rightZ, side, p, 0, 0);
                }
            }
            for (int n = 0; n < 2; n++) {
                double[] p = wingPoint(rnd.nextInt(feathers), 1.0, flap, feathers);
                emit(mc, set[2], px, py, pz, backX, backZ, rightX, rightZ, side, p, 0, 0.01);
            }
            if (rnd.nextDouble() < (inferno ? 0.45 : 0.25)) {
                double[] p = wingPoint(rnd.nextInt(feathers), rnd.nextDouble(), flap, feathers);
                emit(mc, set[3], px, py, pz, backX, backZ, rightX, rightZ, side, p, 0, 0.02);
            }
        }
    }

    /** p = {sideways, height, backwards} in body coordinates. */
    private static void emit(Minecraft mc, String particle, double px, double py, double pz,
                             double backX, double backZ, double rightX, double rightZ,
                             int side, double[] p, double vx, double vy) {
        spawn(mc, particle,
                px + backX * p[2] + rightX * side * p[0],
                py + p[1],
                pz + backZ * p[2] + rightZ * side * p[0],
                vx, vy, 0);
    }
}
