package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/** The free cosmetics you can pick in the shop. Everything here is only visible to you. */
public final class Cosmetics {
    public static final String[] BADGE_NAMES = {"Sun", "Star", "Heart", "Moon", "Spark", "Crown", "Bolt", "Flower"};
    public static final String[] BADGES = {"☀", "★", "❤", "☾", "✦", "♛", "⚡",
            "✿"};

    public static final String[] COLOR_NAMES = {"Blue", "Gold", "Pink", "Green", "Red", "Purple", "White", "Rainbow"};
    public static final int[] COLORS = {0x4D8DFF, 0xFFB84D, 0xFF6FB5, 0x35C98A, 0xE0506A, 0xB06CFF, 0xFFFFFF, -1};
    public static final int RAINBOW = 7;

    public static final String[] TRAIL_NAMES = {"Off", "Hearts", "Flames", "Stars", "Magic", "Leaves", "Soul fire"};
    private static final String[] TRAIL_PARTICLES = {null, "HEART", "FLAME", "END_ROD", "ENCHANT",
            "HAPPY_VILLAGER", "SOUL_FIRE_FLAME"};
    public static final int[] TRAIL_COLORS = {0xFF555566, 0xFFFF5577, 0xFFFF8A1E, 0xFFFFF3B0, 0xFFB06CFF,
            0xFF35C98A, 0xFF4DE0FF};

    public static final String[] WING_NAMES = {"No wings", "Angel", "Inferno", "Ender", "Soul", "Magic", "Demon"};
    // per style: bone particle, feather particle, tip particle, accent particle
    private static final String[][] WING_PARTICLES = {
            {null, null, null, null},
            {"END_ROD", "END_ROD", "END_ROD", "CLOUD"},
            {"FLAME", "FLAME", "LAVA", "SMOKE"},
            {"WITCH", "WITCH", "ENCHANT", "PORTAL"},
            {"SOUL_FIRE_FLAME", "SOUL_FIRE_FLAME", "SOUL", "SOUL_FIRE_FLAME"},
            {"ENCHANT", "ENCHANT", "END_ROD", "HAPPY_VILLAGER"},
            {"DUST:1A0508:1.1", "DUST:8A0F18:1.3", "DUST:D02030:1.0", "LARGE_SMOKE"}};
    public static final int[] WING_COLORS = {0xFF555566, 0xFFEAF2FF, 0xFFFF8A1E, 0xFFB06CFF, 0xFF4DE0FF, 0xFF9AF0FF,
            0xFF8A0F18};
    public static final int[] WING_TIP_COLORS = {0xFF555566, 0xFFFFFFFF, 0xFFFFE066, 0xFFFF7AF0, 0xFFB8F4FF,
            0xFFFFFFFF, 0xFFE03030};
    public static final int INFERNO = 2;
    public static final int DEMON = 6;

    public static final String[] BG_NAMES = {"Auto", "Space", "Black hole", "Aurora", "Crimson", "Emerald", "Violet"};
    public static final String[] BG_FILES = {"auto", "space", "blackhole", "aurora", "crimson", "emerald", "violet"};

    public static final String[] CAPE_NAMES = {"No cape", "Nova Sun", "Galaxy", "Neon Storm", "Pink Void", "Rainbow",
            "Ice", "Fire", "Royal", "Sunset", "Emerald", "Shadow", "Sakura", "Cyber", "Gold", "Magma"};
    public static final String[] CAPE_IDS = {"none", "nova_sun", "galaxy", "neon_storm", "pink_void", "rainbow",
            "ice", "fire", "royal", "sunset", "emerald", "shadow", "sakura", "cyber", "gold", "magma"};

    public static final String[] LOOK_NAMES = {"Off", "Cool", "Warm", "Sunrise", "Night", "Vignette", "Emerald", "Violet", "Rose", "Gold", "Cinema"};
    public static final int[] LOOK_TINTS = {0, 0x1C3060FF, 0x1CFF9A30, 0x28FF7A3D, 0x340A0A50, 0, 0x2400C878, 0x2AA030E0, 0x26FF5A9A, 0x28FFC830, 0x1A200800};

    private static final Map<String, Object> PARTICLES = new HashMap<>();
    private static final Set<String> BAD = new HashSet<>();
    private static Method addParticle;
    private static boolean searched;
    private static Field bodyYaw;
    private static boolean bodyYawSearched;

    private Cosmetics() {
    }

    public static int get(String key, int max) {
        try {
            String v = NovaClient.config.cosmetics.get(key);
            if (v != null) {
                return Math.max(0, Math.min(max - 1, Integer.parseInt(v)));
            }
        } catch (Throwable ignored) {
            // use default
        }
        return 0;
    }

    public static void set(String key, int value) {
        NovaClient.config.cosmetics.put(key, String.valueOf(value));
        NovaClient.config.save();
    }

    public static String badge() {
        return BADGES[get("badge", BADGES.length)];
    }

    public static int colorIndex() {
        return get("color", COLORS.length);
    }

    public static int cape() {
        return get("cape", CAPE_IDS.length);
    }

    public static int look() {
        return get("look", LOOK_NAMES.length);
    }

    public static int trail() {
        return get("trail", TRAIL_NAMES.length);
    }

    public static int wings() {
        return get("wings", WING_NAMES.length);
    }

    /** Hue (0..1) to a plain RGB color. */
    public static int hue(float h) {
        float r = clamp(Math.abs(h * 6 - 3) - 1);
        float g = clamp(2 - Math.abs(h * 6 - 2));
        float b = clamp(2 - Math.abs(h * 6 - 4));
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Bold text in the chosen color. With Name glow on, a bright wave runs through the letters. */
    public static Component colored(String text) {
        int index = colorIndex();
        boolean glow = NovaTag.moduleOn("name_glow");
        if (index != RAINBOW && !glow) {
            int color = COLORS[index];
            return Component.literal(text).withStyle(s -> s.withColor(color).withBold(true));
        }
        long now = System.currentTimeMillis();
        MutableComponent out = Component.literal("");
        for (int i = 0; i < text.length(); i++) {
            int color;
            if (index == RAINBOW) {
                color = hue((i * 0.09f + now / 3000f) % 1f);
            } else {
                color = COLORS[index];
            }
            if (glow) {
                double wave = (Math.sin(now / 180.0 - i * 0.8) + 1) / 2;
                color = mix(color, 0xFFFFFF, Math.pow(wave, 4) * 0.85);
            }
            final int c = color;
            out.append(Component.literal(String.valueOf(text.charAt(i)))
                    .withStyle(s -> s.withColor(c).withBold(true)));
        }
        return out;
    }

    // ---------------------------------------------------------------- particles (looked up by name)

    private static void spawn(Minecraft mc, String name, double x, double y, double z,
                              double vx, double vy, double vz) {
        if (name == null || BAD.contains(name) || mc.level == null) {
            return;
        }
        try {
            Object particle = PARTICLES.get(name);
            if (particle == null) {
                try {
                    particle = name.startsWith("DUST:") ? dust(name)
                            : Class.forName("net.minecraft.core.particles.ParticleTypes").getField(name).get(null);
                } catch (Throwable t) {
                    BAD.add(name);
                    return;
                }
                PARTICLES.put(name, particle);
            }
            if (!searched) {
                searched = true;
                Class<?> options = Class.forName("net.minecraft.core.particles.ParticleOptions");
                int bestScore = -1;
                for (Method m : mc.level.getClass().getMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    boolean always = m.getName().equals("addAlwaysVisibleParticle");
                    if (!(always || m.getName().equals("addParticle")) || p.length < 7 || p[0] != options) {
                        continue;
                    }
                    boolean ok = true;
                    for (int i = 1; i < p.length; i++) {
                        boolean last6 = i >= p.length - 6;
                        ok = ok && (last6 ? p[i] == double.class : p[i] == boolean.class);
                    }
                    int score = (always ? 100 : 0) + (p.length > 7 ? 1 : 0);
                    if (ok && score > bestScore) {
                        bestScore = score;
                        addParticle = m;
                    }
                }
                if (addParticle == null) {
                    NovaClient.LOGGER.warn("Particles (trail and wings) not available in this version");
                }
            }
            if (addParticle == null) {
                return;
            }
            if (!addParticle.getParameterTypes()[0].isInstance(particle)) {
                BAD.add(name);
                return;
            }
            int count = addParticle.getParameterCount();
            Object[] args = new Object[count];
            args[0] = particle;
            for (int i = 1; i < count - 6; i++) {
                args[i] = i == 1 ? Boolean.TRUE : Boolean.FALSE;   // first flag = force (ignore Minimal particles)
            }
            int d = count - 6;
            args[d] = x;
            args[d + 1] = y;
            args[d + 2] = z;
            args[d + 3] = vx;
            args[d + 4] = vy;
            args[d + 5] = vz;
            addParticle.invoke(mc.level, args);
        } catch (Throwable t) {
            addParticle = null;
            searched = true;
            NovaClient.LOGGER.warn("Particle failed", t);
        }
    }

    /** Coloured dust particle, built by name. Falls back to smoke / red spores if it cannot be built. */
    private static Object dust(String spec) throws Exception {
        try {
            String[] parts = spec.split(":");
            int rgb = Integer.parseInt(parts[1], 16);
            float scale = Float.parseFloat(parts[2]);
            Class<?> type = Class.forName("net.minecraft.core.particles.DustParticleOptions");
            for (java.lang.reflect.Constructor<?> c : type.getConstructors()) {
                Class<?>[] p = c.getParameterTypes();
                if (p.length == 2 && p[0] == int.class && p[1] == float.class) {
                    return c.newInstance(rgb, scale);
                }
                if (p.length == 2 && p[1] == float.class && p[0].getName().equals("org.joml.Vector3f")) {
                    Object vec = p[0].getConstructor(float.class, float.class, float.class)
                            .newInstance(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f);
                    return c.newInstance(vec, scale);
                }
            }
        } catch (Throwable ignored) {
            // use the fallback below
        }
        String fallback = spec.startsWith("DUST:1A") ? "SMOKE" : "CRIMSON_SPORE";
        return Class.forName("net.minecraft.core.particles.ParticleTypes").getField(fallback).get(null);
    }

    public static void tickTrail(Minecraft mc) {
        int trail = trail();
        if (trail == 0 || mc.player == null || mc.level == null) {
            return;
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int n = 0; n < 2; n++) {
            spawn(mc, TRAIL_PARTICLES[trail],
                    mc.player.getX() + rnd.nextDouble(-0.35, 0.35),
                    mc.player.getY() + rnd.nextDouble(0.1, 1.6),
                    mc.player.getZ() + rnd.nextDouble(-0.35, 0.35),
                    rnd.nextDouble(-0.02, 0.02), rnd.nextDouble(0.0, 0.05), rnd.nextDouble(-0.02, 0.02));
        }
    }

    /** Direction your body faces, in radians. Falls back to where you look. */
    private static double bodyYawRadians(Minecraft mc) {
        try {
            if (!bodyYawSearched) {
                bodyYawSearched = true;
                bodyYaw = net.minecraft.world.entity.LivingEntity.class.getField("yBodyRot");
            }
            if (bodyYaw != null) {
                return Math.toRadians(bodyYaw.getFloat(mc.player));
            }
        } catch (Throwable t) {
            bodyYaw = null;
        }
        return Math.toRadians(mc.player.getYRot());
    }

    public static final int FEATHERS = 7;
    private static final double SHOULDER_L = 0.15;
    private static final double SHOULDER_H = 1.35;

    /**
     * A point on one wing, in body coordinates: {sideways, height, backwards}.
     * feather = -1 is the bone (s runs along it); feather 0..FEATHERS-1 hangs down from the bone (s is 0 at the bone).
     * flap rotates the whole wing around the shoulder.
     */
    public static double[] wingPoint(int feather, double s, double flap, int feathers) {
        double u = feather < 0 ? s : 0.08 + 0.84 * feather / (double) (feathers - 1);
        double l = SHOULDER_L + 1.55 * u;
        double h = SHOULDER_H + 0.8 * Math.sin(u * Math.PI * 0.75) * (1 - 0.15 * u);
        double back = 0.28 + 0.22 * u;
        if (feather >= 0) {
            double len = 0.75 + 0.95 * Math.sin(Math.PI * (feather + 0.7) / (feathers + 0.4));
            l += s * (0.12 + 0.34 * u) + Math.sin(s * Math.PI) * 0.1;
            h -= s * len;
            back += s * 0.1;
        }
        double dl = l - SHOULDER_L;
        double dh = h - SHOULDER_H;
        double c = Math.cos(flap);
        double sn = Math.sin(flap);
        double l2 = SHOULDER_L + dl * c - dh * sn;
        double h2 = SHOULDER_H + dl * sn + dh * c;
        double back2 = back + Math.sin(flap) * dl * 0.35;
        return new double[]{l2, h2, back2};
    }

    private static double wingPhase;
    private static double wingLag;
    private static double wingBias;
    private static double wingFold = 1.0;
    private static double lastWingY = Double.NaN;

    private static double[] rotateFlap(double l, double h, double back, double flap) {
        double dl = l - SHOULDER_L;
        double dh = h - SHOULDER_H;
        double c = Math.cos(flap);
        double sn = Math.sin(flap);
        return new double[]{SHOULDER_L + dl * c - dh * sn, SHOULDER_H + dl * sn + dh * c,
                back + Math.sin(flap) * dl * 0.35};
    }

    // ---- demon wings: an arm bone, four finger bones and red membrane with a jagged edge
    private static final double[][] D_TIP = {{2.75, 2.05}, {2.45, 1.40}, {1.95, 0.90}, {1.30, 0.62}};
    private static final double[] D_SHOULDER = {0.15, 1.35};
    private static final double[] D_ELBOW = {0.80, 2.30};
    private static final double[] D_WRIST = {1.55, 2.45};

    private static double[] demonFinger(int i, double r) {
        double l = D_WRIST[0] + (D_TIP[i][0] - D_WRIST[0]) * r;
        double h = D_WRIST[1] + (D_TIP[i][1] - D_WRIST[1]) * r - 0.10 * Math.sin(Math.PI * r) * (1 + 0.3 * i);
        return new double[]{l, h};
    }

    private static double demonEdge(double t) {
        return 1.0 - 0.18 * Math.sin(Math.PI * t);
    }

    /** A point on a demon wing. kind: 0 arm, 1 finger, 2 membrane, 3 inner membrane, 4 jagged edge. */
    public static double[] demonPoint(int kind, java.util.Random rnd, double flap) {
        double l;
        double h;
        switch (kind) {
            case 0 -> {
                double s = rnd.nextDouble();
                if (s < 0.5) {
                    double k = s / 0.5;
                    l = D_SHOULDER[0] + (D_ELBOW[0] - D_SHOULDER[0]) * k;
                    h = D_SHOULDER[1] + (D_ELBOW[1] - D_SHOULDER[1]) * k;
                } else {
                    double k = (s - 0.5) / 0.5;
                    l = D_ELBOW[0] + (D_WRIST[0] - D_ELBOW[0]) * k;
                    h = D_ELBOW[1] + (D_WRIST[1] - D_ELBOW[1]) * k;
                }
            }
            case 1 -> {
                double[] p = demonFinger(rnd.nextInt(4), rnd.nextDouble());
                l = p[0];
                h = p[1];
            }
            case 2, 4 -> {
                int i = rnd.nextInt(3);
                double t = rnd.nextDouble();
                double rmax = demonEdge(t);
                double r = kind == 4 ? rmax : 0.25 + rnd.nextDouble() * (rmax - 0.25);
                double[] a = demonFinger(i, r);
                double[] b = demonFinger(i + 1, r);
                l = a[0] + (b[0] - a[0]) * t;
                h = a[1] + (b[1] - a[1]) * t;
            }
            default -> {
                double[] A = D_SHOULDER;
                double[] B = rnd.nextDouble() < 0.55 ? D_WRIST : D_ELBOW;
                double[] C = B == D_WRIST ? D_TIP[3] : D_WRIST;
                double r1 = Math.sqrt(rnd.nextDouble());
                double r2 = rnd.nextDouble();
                l = (1 - r1) * A[0] + r1 * (1 - r2) * B[0] + r1 * r2 * C[0];
                h = (1 - r1) * A[1] + r1 * (1 - r2) * B[1] + r1 * r2 * C[1];
            }
        }
        double back = 0.28 + 0.12 * (l - D_SHOULDER[0]);
        return rotateFlap(l, h, back, flap);
    }

    /**
     * Big wings made of particles. They have simple physics: they flap faster and sweep back when you
     * run, spread up when you fall, fold when you sneak and stretch out when you glide with an elytra.
     */
    public static void tickWings(Minecraft mc) {
        int style = wings();
        if (style == 0 || mc.player == null || mc.level == null) {
            wingLag = 0;
            wingBias = 0;
            return;
        }
        double yaw = bodyYawRadians(mc);
        double backX = Math.sin(yaw);
        double backZ = -Math.cos(yaw);
        double rightX = -Math.cos(yaw);
        double rightZ = -Math.sin(yaw);
        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();
        double speed = Math.min(0.35, mc.player.getDeltaMovement().horizontalDistance());
        double vy = Double.isNaN(lastWingY) ? 0 : py - lastWingY;
        lastWingY = py;
        boolean glide = mc.player.isFallFlying();
        wingLag += ((glide ? 1.0 : Math.min(1.0, speed * 3.2)) - wingLag) * 0.2;
        double amp = 0.14 + speed * 0.9 + (vy > 0.05 ? 0.20 : 0.0);
        double bias = 0;
        if (glide) {
            amp = 0.04;
            bias = -0.15;
        } else if (vy < -0.35) {
            amp *= 0.3;
            bias = 0.45;
        }
        wingBias += (bias - wingBias) * 0.15;
        wingPhase += 0.17 + speed * 1.2 + (vy > 0.05 ? 0.25 : 0.0);
        double flap = wingBias + amp * Math.sin(wingPhase);
        wingFold += ((mc.player.isCrouching() ? 0.55 : 1.0) - wingFold) * 0.2;

        String[] set = WING_PARTICLES[style];
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int side = -1; side <= 1; side += 2) {
            if (style == DEMON) {
                int[] counts = {3, 4, 6, 2, 3};
                for (int kind = 0; kind < counts.length; kind++) {
                    String particle = kind <= 1 ? set[0] : kind == 4 ? set[2] : set[1];
                    for (int n = 0; n < counts[kind]; n++) {
                        emit(mc, particle, px, py, pz, backX, backZ, rightX, rightZ, side,
                                demonPoint(kind, rnd, flap), 0, 0);
                    }
                }
                if (rnd.nextDouble() < 0.2) {
                    emit(mc, set[3], px, py, pz, backX, backZ, rightX, rightZ, side,
                            demonPoint(2, rnd, flap), 0, 0.02);
                }
                continue;
            }
            boolean inferno = style == INFERNO;
            int feathers = inferno ? 9 : FEATHERS;
            int perFeather = inferno ? 2 : 1;
            for (int n = 0; n < 3; n++) {
                emit(mc, set[0], px, py, pz, backX, backZ, rightX, rightZ, side,
                        wingPoint(-1, rnd.nextDouble(), flap, feathers), 0, 0);
            }
            for (int k = 0; k < feathers; k++) {
                for (int n = 0; n < perFeather; n++) {
                    emit(mc, set[1], px, py, pz, backX, backZ, rightX, rightZ, side,
                            wingPoint(k, rnd.nextDouble(0.05, 1.0), flap, feathers), 0, 0);
                }
            }
            for (int n = 0; n < 2; n++) {
                emit(mc, set[2], px, py, pz, backX, backZ, rightX, rightZ, side,
                        wingPoint(rnd.nextInt(feathers), 1.0, flap, feathers), 0, 0.01);
            }
            if (rnd.nextDouble() < (inferno ? 0.45 : 0.25)) {
                emit(mc, set[3], px, py, pz, backX, backZ, rightX, rightZ, side,
                        wingPoint(rnd.nextInt(feathers), rnd.nextDouble(), flap, feathers), 0, 0.02);
            }
        }
    }

    /** p = {sideways, height, backwards} in body coordinates; applies fold (sneak) and sweep-back (speed). */
    private static void emit(Minecraft mc, String particle, double px, double py, double pz,
                             double backX, double backZ, double rightX, double rightZ,
                             int side, double[] p, double vx, double vy) {
        double out = p[0] - SHOULDER_L;
        double lateral = SHOULDER_L + out * wingFold;
        double back = p[2] + wingLag * 0.85 * out * wingFold;
        double height = p[1] - wingLag * 0.25 * out - (wingFold < 0.99 ? 0.15 * (1 - wingFold) : 0.0);
        spawn(mc, particle,
                px + backX * back + rightX * side * lateral,
                py + height,
                pz + backZ * back + rightZ * side * lateral,
                vx, vy, 0);
    }
}
