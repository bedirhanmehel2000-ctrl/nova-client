package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/** The free cosmetics you can pick in the shop. Everything here is only visible to you. */
public final class Cosmetics {
    public static final String[] BADGE_NAMES = {"Sun", "Star", "Heart", "Moon", "Spark", "Crown", "Bolt", "Flower"};
    public static final String[] BADGES = {"☀", "★", "❤", "☾", "✦", "♛", "⚡",
            "✿"};

    public static final String[] COLOR_NAMES = {"Blue", "Gold", "Pink", "Green", "Red", "Purple", "White", "Rainbow"};
    public static final int[] COLORS = {0x4D8DFF, 0xFFB84D, 0xFF6FB5, 0x35C98A, 0xE0506A, 0xB06CFF, 0xFFFFFF, -1};
    public static final int RAINBOW = 7;

    public static final String[] TRAIL_NAMES = {"Off", "Hearts", "Flames", "Stars", "Magic", "Leaves", "Soul fire"};
    private static final String[] TRAIL_PARTICLES = {null, "HEART", "FLAME", "END_ROD", "ENCHANT",
            "HAPPY_VILLAGER", "SOUL_FIRE_FLAME"};
    public static final int[] TRAIL_COLORS = {0xFF555566, 0xFFFF5577, 0xFFFF8A1E, 0xFFFFF3B0, 0xFFB06CFF,
            0xFF35C98A, 0xFF4DE0FF};

    public static final String[] WING_NAMES = {"No wings", "Angel", "Fire", "Ender", "Soul", "Magic"};
    private static final String[] WING_PARTICLES = {null, "END_ROD", "FLAME", "WITCH", "SOUL_FIRE_FLAME", "ENCHANT"};
    public static final int[] WING_COLORS = {0xFF555566, 0xFFEAF2FF, 0xFFFF8A1E, 0xFFB06CFF, 0xFF4DE0FF, 0xFF9AF0FF};

    public static final String[] CAPE_NAMES = {"No cape", "Nova Sun", "Galaxy", "Neon Storm", "Pink Void", "Rainbow",
            "Ice", "Fire", "Royal"};
    public static final String[] CAPE_IDS = {"none", "nova_sun", "galaxy", "neon_storm", "pink_void", "rainbow",
            "ice", "fire", "royal"};

    public static final String[] LOOK_NAMES = {"Off", "Cool", "Warm", "Sunrise", "Night", "Vignette"};
    public static final int[] LOOK_TINTS = {0, 0x1C3060FF, 0x1CFF9A30, 0x28FF7A3D, 0x340A0A50, 0};

    private static final Map<String, Object> PARTICLES = new HashMap<>();
    private static final Set<String> BAD = new HashSet<>();
    private static Method addParticle;
    private static boolean searched;
    private static Field bodyYaw;
    private static boolean bodyYawSearched;

    private Cosmetics() {
    }

    public static int get(String key, int max) {
        try {
            String v = NovaClient.config.cosmetics.get(key);
            if (v != null) {
                return Math.max(0, Math.min(max - 1, Integer.parseInt(v)));
            }
        } catch (Throwable ignored) {
            // use default
        }
        return 0;
    }

    public static void set(String key, int value) {
        NovaClient.config.cosmetics.put(key, String.valueOf(value));
        NovaClient.config.save();
    }

    public static String badge() {
        return BADGES[get("badge", BADGES.length)];
    }

    public static int colorIndex() {
        return get("color", COLORS.length);
    }

    public static int cape() {
        return get("cape", CAPE_IDS.length);
    }

    public static int look() {
        return get("look", LOOK_NAMES.length);
    }

    public static int trail() {
        return get("trail", TRAIL_NAMES.length);
    }

    public static int wings() {
        return get("wings", WING_NAMES.length);
    }

    /** Hue (0..1) to a plain RGB color. */
    public static int hue(float h) {
        float r = clamp(Math.abs(h * 6 - 3) - 1);
        float g = clamp(2 - Math.abs(h * 6 - 2));
        float b = clamp(2 - Math.abs(h * 6 - 4));
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Bold text in the chosen color. With Name glow on, a bright wave runs through the letters. */
    public static Component colored(String text) {
        int index = colorIndex();
        boolean glow = NovaTag.moduleOn("name_glow");
        if (index != RAINBOW && !glow) {
            int color = COLORS[index];
            return Component.literal(text).withStyle(s -> s.withColor(color).withBold(true));
        }
        long now = System.currentTimeMillis();
        MutableComponent out = Component.literal("");
        for (int i = 0; i < text.length(); i++) {
            int color;
            if (index == RAINBOW) {
                color = hue((i * 0.09f + now / 3000f) % 1f);
            } else {
                color = COLORS[index];
            }
            if (glow) {
                double wave = (Math.sin(now / 180.0 - i * 0.8) + 1) / 2;
                color = mix(color, 0xFFFFFF, Math.pow(wave, 4) * 0.85);
            }
            final int c = color;
            out.append(Component.literal(String.valueOf(text.charAt(i)))
                    .withStyle(s -> s.withColor(c).withBold(true)));
        }
        return out;
    }

    // ---------------------------------------------------------------- particles (looked up by name)

    private static void spawn(Minecraft mc, String name, double x, double y, double z,
                              double vx, double vy, double vz) {
        if (name == null || BAD.contains(name) || mc.level == null) {
            return;
        }
        try {
            Object particle = PARTICLES.get(name);
            if (particle == null) {
                try {
                    particle = Class.forName("net.minecraft.core.particles.ParticleTypes").getField(name).get(null);
                } catch (Throwable t) {
                    BAD.add(name);
                    return;
                }
                PARTICLES.put(name, particle);
            }
            if (!searched) {
                searched = true;
                Class<?> options = Class.forName("net.minecraft.core.particles.ParticleOptions");
                for (Method m : mc.level.getClass().getMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    if (!m.getName().equals("addParticle") || p.length < 7 || p[0] != options) {
                        continue;
                    }
                    boolean ok = true;
                    for (int i = 1; i < p.length; i++) {
                        boolean last6 = i >= p.length - 6;
                        ok = ok && (last6 ? p[i] == double.class : p[i] == boolean.class);
                    }
                    if (ok) {
                        addParticle = m;
                        break;
                    }
                }
                if (addParticle == null) {
                    NovaClient.LOGGER.warn("Particles (trail and wings) not available in this version");
                }
            }
            if (addParticle == null) {
                return;
            }
            if (!addParticle.getParameterTypes()[0].isInstance(particle)) {
                BAD.add(name);
                return;
            }
            int count = addParticle.getParameterCount();
            Object[] args = new Object[count];
            args[0] = particle;
            for (int i = 1; i < count - 6; i++) {
                args[i] = Boolean.FALSE;
            }
            int d = count - 6;
            args[d] = x;
            args[d + 1] = y;
            args[d + 2] = z;
            args[d + 3] = vx;
            args[d + 4] = vy;
            args[d + 5] = vz;
            addParticle.invoke(mc.level, args);
        } catch (Throwable t) {
            addParticle = null;
            searched = true;
            NovaClient.LOGGER.warn("Particle failed", t);
        }
    }

    public static void tickTrail(Minecraft mc) {
        int trail = trail();
        if (trail == 0 || mc.player == null || mc.level == null) {
            return;
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int n = 0; n < 2; n++) {
            spawn(mc, TRAIL_PARTICLES[trail],
                    mc.player.getX() + rnd.nextDouble(-0.35, 0.35),
                    mc.player.getY() + rnd.nextDouble(0.1, 1.6),
                    mc.player.getZ() + rnd.nextDouble(-0.35, 0.35),
                    rnd.nextDouble(-0.02, 0.02), rnd.nextDouble(0.0, 0.05), rnd.nextDouble(-0.02, 0.02));
        }
    }

    /** Direction your body faces, in radians. Falls back to where you look. */
    private static double bodyYawRadians(Minecraft mc) {
        try {
            if (!bodyYawSearched) {
                bodyYawSearched = true;
                bodyYaw = net.minecraft.world.entity.LivingEntity.class.getField("yBodyRot");
            }
            if (bodyYaw != null) {
                return Math.toRadians(bodyYaw.getFloat(mc.player));
            }
        } catch (Throwable t) {
            bodyYaw = null;
        }
        return Math.toRadians(mc.player.getYRot());
    }

    /** Wings made of particles behind your back, flapping slowly. */
    public static void tickWings(Minecraft mc) {
        int wings = wings();
        if (wings == 0 || mc.player == null || mc.level == null) {
            return;
        }
        double yaw = bodyYawRadians(mc);
        double backX = Math.sin(yaw);
        double backZ = -Math.cos(yaw);
        double rightX = -Math.cos(yaw);
        double rightZ = -Math.sin(yaw);
        double flap = Math.sin(System.currentTimeMillis() / 260.0) * 0.25;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int side = -1; side <= 1; side += 2) {
            for (int n = 0; n < 5; n++) {
                double t = rnd.nextDouble();
                double lateral = 0.2 + t * 1.0;
                double height = 1.25 + t * 0.55 * (1 - t * 0.6) - rnd.nextDouble() * t * 0.9 - flap * t * 0.6;
                double depth = 0.28 + t * 0.25 + flap * t * 0.4;
                spawn(mc, WING_PARTICLES[wings],
                        mc.player.getX() + backX * depth + rightX * side * lateral,
                        mc.player.getY() + height,
                        mc.player.getZ() + backZ * depth + rightZ * side * lateral,
                        0, 0, 0);
            }
        }
    }
}
