package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/** The free cosmetics you can pick in the shop. Everything here is only visible to you. */
public final class Cosmetics {
    public static final String[] BADGE_NAMES = {"Sun", "Star", "Heart", "Moon", "Spark", "Crown", "Bolt", "Flower"};
    public static final String[] BADGES = {"☀", "★", "❤", "☾", "✦", "♛", "⚡",
            "✿"};

    public static final String[] COLOR_NAMES = {"Blue", "Gold", "Pink", "Green", "Red", "Purple", "White", "Rainbow"};
    public static final int[] COLORS = {0x4D8DFF, 0xFFB84D, 0xFF6FB5, 0x35C98A, 0xE0506A, 0xB06CFF, 0xFFFFFF, -1};
    public static final int RAINBOW = 7;

    public static final String[] TRAIL_NAMES = {"Off", "Hearts", "Flames", "Stars", "Magic", "Leaves", "Soul fire"};
    private static final String[] TRAIL_PARTICLES = {null, "HEART", "FLAME", "END_ROD", "ENCHANT",
            "HAPPY_VILLAGER", "SOUL_FIRE_FLAME"};

    public static final String[] CAPE_NAMES = {"No cape", "Nova Sun", "Galaxy", "Neon Storm", "Pink Void", "Rainbow",
            "Ice", "Fire", "Royal"};
    public static final String[] CAPE_IDS = {"none", "nova_sun", "galaxy", "neon_storm", "pink_void", "rainbow",
            "ice", "fire", "royal"};

    public static final int[] TRAIL_COLORS = {0xFF555566, 0xFFFF5577, 0xFFFF8A1E, 0xFFFFF3B0, 0xFFB06CFF,
            0xFF35C98A, 0xFF4DE0FF};
    public static final int[] LOOK_TINTS = {0, 0x1C3060FF, 0x1CFF9A30, 0x28FF7A3D, 0x340A0A50, 0};

    public static final String[] LOOK_NAMES = {"Off", "Cool", "Warm", "Sunrise", "Night", "Vignette"};

    private static final Map<String, Object> PARTICLES = new HashMap<>();
    private static Method addParticle;
    private static boolean searched;

    private Cosmetics() {
    }

    public static int get(String key, int max) {
        try {
            String v = NovaClient.config.cosmetics.get(key);
            if (v != null) {
                return Math.max(0, Math.min(max - 1, Integer.parseInt(v)));
            }
        } catch (Throwable ignored) {
            // use default
        }
        return 0;
    }

    public static void set(String key, int value) {
        NovaClient.config.cosmetics.put(key, String.valueOf(value));
        NovaClient.config.save();
    }

    public static String badge() {
        return BADGES[get("badge", BADGES.length)];
    }

    public static int colorIndex() {
        return get("color", COLORS.length);
    }

    public static int cape() {
        return get("cape", CAPE_IDS.length);
    }

    public static int look() {
        return get("look", LOOK_NAMES.length);
    }

    public static int trail() {
        return get("trail", TRAIL_NAMES.length);
    }

    /** Hue (0..1) to a plain RGB color. */
    public static int hue(float h) {
        float r = clamp(Math.abs(h * 6 - 3) - 1);
        float g = clamp(2 - Math.abs(h * 6 - 2));
        float b = clamp(2 - Math.abs(h * 6 - 4));
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    /** Bold text in the chosen color (rainbow gives every letter its own color). */
    public static Component colored(String text) {
        int index = colorIndex();
        if (index != RAINBOW) {
            int color = COLORS[index];
            return Component.literal(text).withStyle(s -> s.withColor(color).withBold(true));
        }
        MutableComponent out = Component.literal("");
        for (int i = 0; i < text.length(); i++) {
            int color = hue((i * 0.09f) % 1f);
            out.append(Component.literal(String.valueOf(text.charAt(i)))
                    .withStyle(s -> s.withColor(color).withBold(true)));
        }
        return out;
    }

    /** Spawns the chosen trail around the player. Looked up by name so a rename cannot break the build. */
    public static void tickTrail(Minecraft mc) {
        int trail = trail();
        if (trail == 0 || mc.player == null || mc.level == null || searched && addParticle == null) {
            return;
        }
        try {
            String name = TRAIL_PARTICLES[trail];
            Object particle = PARTICLES.get(name);
            if (particle == null) {
                particle = Class.forName("net.minecraft.core.particles.ParticleTypes").getField(name).get(null);
                PARTICLES.put(name, particle);
            }
            if (!searched) {
                searched = true;
                for (Method m : mc.level.getClass().getMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    if (!m.getName().equals("addParticle") || p.length < 7 || !p[0].isInstance(particle)) {
                        continue;
                    }
                    boolean ok = true;
                    for (int i = 1; i < p.length; i++) {
                        boolean last6 = i >= p.length - 6;
                        ok = ok && (last6 ? p[i] == double.class : p[i] == boolean.class);
                    }
                    if (ok) {
                        addParticle = m;
                        break;
                    }
                }
                if (addParticle == null) {
                    NovaClient.LOGGER.warn("Particle trail not available in this version");
                    return;
                }
            }
            int count = addParticle.getParameterCount();
            java.util.concurrent.ThreadLocalRandom rnd = java.util.concurrent.ThreadLocalRandom.current();
            for (int n = 0; n < 2; n++) {
                Object[] args = new Object[count];
                args[0] = particle;
                for (int i = 1; i < count - 6; i++) {
                    args[i] = Boolean.FALSE;
                }
                int d = count - 6;
                args[d] = mc.player.getX() + rnd.nextDouble(-0.35, 0.35);
                args[d + 1] = mc.player.getY() + rnd.nextDouble(0.1, 1.6);
                args[d + 2] = mc.player.getZ() + rnd.nextDouble(-0.35, 0.35);
                args[d + 3] = rnd.nextDouble(-0.02, 0.02);
                args[d + 4] = rnd.nextDouble(0.0, 0.05);
                args[d + 5] = rnd.nextDouble(-0.02, 0.02);
                addParticle.invoke(mc.level, args);
            }
        } catch (Throwable t) {
            addParticle = null;
            searched = true;
            NovaClient.LOGGER.warn("Particle trail failed", t);
        }
    }
}
