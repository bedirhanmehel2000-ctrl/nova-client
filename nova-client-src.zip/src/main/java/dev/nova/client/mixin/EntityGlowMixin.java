package dev.nova.client.mixin;

import dev.nova.client.NovaTag;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Body glow: a glowing outline around you. Only affects you. Skipped quietly if not found. */
@Mixin(Entity.class)
public abstract class EntityGlowMixin {
    @Inject(method = "isCurrentlyGlowing", at = @At("RETURN"), cancellable = true, require = 0)
    private void nova$glow(CallbackInfoReturnable<Boolean> cir) {
        try {
            if (!cir.getReturnValueZ() && NovaTag.isSelf(this) && NovaTag.moduleOn("body_glow")) {
                cir.setReturnValue(true);
            }
        } catch (Throwable ignored) {
            // never break the game
        }
    }
}
