package dev.nova.client.mixin;

import dev.nova.client.NovaTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Adds the Nova badge to your own display name. Skipped quietly if the method is not found. */
@Mixin(Entity.class)
public abstract class EntityNameMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
    private void nova$tag(CallbackInfoReturnable<Component> cir) {
        try {
            if (NovaTag.isSelf(this) && NovaTag.enabled()) {
                cir.setReturnValue(NovaTag.decorate(cir.getReturnValue()));
            }
        } catch (Throwable ignored) {
            // never break the game because of a nametag
        }
    }
}
