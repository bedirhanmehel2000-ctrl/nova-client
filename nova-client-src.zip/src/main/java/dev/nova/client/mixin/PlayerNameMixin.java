package dev.nova.client.mixin;

import dev.nova.client.NovaTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Same as EntityNameMixin, for versions where Player has its own getDisplayName. */
@Mixin(Player.class)
public abstract class PlayerNameMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
    private void nova$tag(CallbackInfoReturnable<Component> cir) {
        try {
            if (NovaTag.isSelf(this) && NovaTag.enabled()) {
                cir.setReturnValue(NovaTag.decorate(cir.getReturnValue()));
            }
        } catch (Throwable ignored) {
            // never break the game because of a nametag
        }
    }
}
