package dev.nova.client.mixin;

import dev.nova.client.NovaTag;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Low fire: you look like you are not burning, so the fire overlay is skipped. Only affects you. */
@Mixin(Entity.class)
public abstract class EntityFireMixin {
    @Inject(method = "isOnFire", at = @At("RETURN"), cancellable = true, require = 0)
    private void nova$lowFire(CallbackInfoReturnable<Boolean> cir) {
        try {
            if (cir.getReturnValueZ() && NovaTag.isSelf(this) && NovaTag.moduleOn("low_fire")) {
                cir.setReturnValue(false);
            }
        } catch (Throwable ignored) {
            // never break the game
        }
    }
}
