package dev.nova.client.mixin;

import dev.nova.client.PauseStyle;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Gives the pause menu the Nova look. Does nothing for any other screen. Skipped quietly if not found. */
@Mixin(Screen.class)
public abstract class ScreenMixin {
    /** Preferred: draws right after the vanilla background, so the panorama or dirt cannot cover it. */
    @Inject(method = "extractBackground", at = @At("TAIL"), require = 0)
    private void nova$background(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        try {
            PauseStyle.backgroundHookWorks = true;
            PauseStyle.before(this, g);
        } catch (Throwable ignored) {
            // never break a screen
        }
    }

    /** Fallback if the background method is not found: draw before everything else. */
    @Inject(method = "extractRenderState", at = @At("HEAD"), require = 0)
    private void nova$pauseBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        try {
            if (!PauseStyle.backgroundHookWorks) {
                PauseStyle.before(this, g);
            }
        } catch (Throwable ignored) {
            // never break a screen
        }
    }

    @Inject(method = "extractRenderState", at = @At("TAIL"), require = 0)
    private void nova$pauseButtons(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        try {
            PauseStyle.after(this, g, mouseX, mouseY);
        } catch (Throwable ignored) {
            // never break a screen
        }
    }
}
