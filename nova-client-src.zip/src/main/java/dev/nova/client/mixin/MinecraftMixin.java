package dev.nova.client.mixin;

import dev.nova.client.NovaTitleScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Whenever the normal title screen is about to open, the Nova one opens instead (no flicker). */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true, require = 0)
    private Screen nova$title(Screen screen) {
        try {
            return NovaTitleScreen.wrap(screen);
        } catch (Throwable t) {
            return screen;
        }
    }
}
