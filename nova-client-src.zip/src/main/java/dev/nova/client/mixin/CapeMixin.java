package dev.nova.client.mixin;

import dev.nova.client.CapeSkin;
import dev.nova.client.NovaTag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Gives you the cape you picked in the shop. Only affects you. Skipped quietly if not found. */
@Mixin(targets = "net.minecraft.client.player.AbstractClientPlayer")
public abstract class CapeMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true, require = 0)
    private void nova$cape(CallbackInfoReturnable<Object> cir) {
        try {
            if (NovaTag.isSelf(this)) {
                Object skin = CapeSkin.apply(cir.getReturnValue());
                if (skin != null) {
                    cir.setReturnValue(skin);
                }
            }
        } catch (Throwable ignored) {
            // never break the game because of a cape
        }
    }
}
