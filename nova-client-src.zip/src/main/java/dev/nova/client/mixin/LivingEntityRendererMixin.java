package dev.nova.client.mixin;

import dev.nova.client.NovaTag;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Vanilla never shows a nametag over yourself. This lets it show when you look at yourself in third person. */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "shouldShowName(Lnet/minecraft/world/entity/LivingEntity;D)Z",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void nova$showSelf(LivingEntity entity, double distance, CallbackInfoReturnable<Boolean> cir) {
        try {
            if (NovaTag.isSelf(entity) && NovaTag.enabled()) {
                cir.setReturnValue(true);
            }
        } catch (Throwable ignored) {
            // never break the game because of a nametag
        }
    }
}
