package dev.nova.client.mixin;

import dev.nova.client.NovaTag;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Puts the Nova tag in front of your own chat messages. Skipped quietly if the target is not found. */
@Mixin(targets = "net.minecraft.client.gui.components.ChatComponent")
public abstract class ChatComponentMixin {
    @ModifyVariable(method = "addMessage", at = @At("HEAD"), argsOnly = true, require = 0)
    private Component nova$chatTag(Component message) {
        try {
            if (NovaTag.moduleOn("chat_tag")) {
                return NovaTag.decorateChat(message);
            }
        } catch (Throwable ignored) {
            // never break chat
        }
        return message;
    }
}
