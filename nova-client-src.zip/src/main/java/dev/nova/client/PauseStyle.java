package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/** Nova look and Nova buttons for the pause menu. All lookups are by name, so a rename cannot crash the game. */
public final class PauseStyle {
    private static Screen handled;
    private static int handledWidth = -1;
    private static int handledHeight = -1;
    private static Method addWidget;
    private static boolean searched;

    private PauseStyle() {
    }

    static boolean isPause(Object screen) {
        return screen != null && screen.getClass().getSimpleName().equals("PauseScreen");
    }

    /** Called every tick: adds the Nova buttons to the pause menu once. */
    static void tick(Minecraft mc) {
        Screen s = mc.screen;
        if (!isPause(s)) {
            handled = null;
            return;
        }
        if (s == handled && s.width == handledWidth && s.height == handledHeight) {
            return;
        }
        try {
            if (!searched) {
                searched = true;
                for (Method m : Screen.class.getDeclaredMethods()) {
                    if (m.getName().equals("addRenderableWidget") && m.getParameterCount() == 1) {
                        m.setAccessible(true);
                        addWidget = m;
                        break;
                    }
                }
            }
            if (addWidget == null) {
                return;
            }
            Button menu = Button.builder(Component.literal("§6NOVA MENU"),
                    b -> mc.setScreen(new NovaMenuScreen())).bounds(s.width - 108, 8, 100, 20).build();
            Button shop = Button.builder(Component.literal("§6NOVA SHOP"),
                    b -> mc.setScreen(new NovaShopScreen(s))).bounds(s.width - 108, 32, 100, 20).build();
            Button music = Button.builder(Component.literal("\u00a76NOVA MUSIC"),
                    b -> mc.setScreen(new NovaMusicScreen(s))).bounds(s.width - 108, 56, 100, 20).build();
            addWidget.invoke(s, music);
            addWidget.invoke(s, menu);
            addWidget.invoke(s, shop);
            handled = s;
            handledWidth = s.width;
            handledHeight = s.height;
        } catch (Throwable t) {
            addWidget = null;
            handled = s;
            NovaClient.LOGGER.warn("Could not add Nova buttons to the pause menu", t);
        }
    }

    /** Set once the background hook (after the vanilla background) has run, so the early draw is skipped. */
    public static boolean backgroundHookWorks;

    /** Menus that get the Nova look: pause, worlds, servers, options and the settings pages. */
    static boolean isStyled(Object screen) {
        if (screen == null) {
            return false;
        }
        String name = screen.getClass().getName();
        if (!name.startsWith("net.minecraft.client.gui.screens.")) {
            return false;
        }
        String simple = screen.getClass().getSimpleName();
        return simple.equals("PauseScreen") || simple.equals("ShareToLanScreen") || simple.equals("ConfirmScreen")
                || name.contains(".options.") || name.contains(".worldselection.")
                || name.contains(".multiplayer.") || name.contains(".packs.");
    }

    /** Space picture behind the menu (and a banner on the pause menu). */
    public static void before(Object screen, GuiGraphicsExtractor g) {
        if (!isStyled(screen)) {
            return;
        }
        Screen s = (Screen) screen;
        long now = System.currentTimeMillis();
        SpaceUi.background(g, s.width, s.height, now);
        Font font = Minecraft.getInstance().font;
        if (isPause(screen)) {
            String title = "N O V A   C L I E N T";
            int x = (s.width - font.width(title)) / 2;
            SpaceUi.sun(g, x - 16, 14, 7, now);
            g.text(font, title, x, 10, 0xFFFFFFFF, true);
        } else {
            SpaceUi.sun(g, 14, 14, 6, now);
        }
    }

    private static boolean restyle(Object child) {
        if (!(child instanceof AbstractButton button) || button.getMessage().getString().isEmpty()) {
            return false;
        }
        String simple = child.getClass().getSimpleName();
        return !(simple.contains("Checkbox") || simple.contains("Image") || simple.contains("Icon")
                || simple.contains("Tab"));
    }

    /** Restyles the buttons of the menu in the Nova look. */
    public static void after(Object screen, GuiGraphicsExtractor g, int mouseX, int mouseY) {
        if (!isStyled(screen)) {
            return;
        }
        Screen s = (Screen) screen;
        List<AbstractWidget> widgets = new ArrayList<>();
        for (Object child : s.children()) {
            if (restyle(child)) {
                widgets.add((AbstractWidget) child);
            }
        }
        SpaceUi.drawButtons(widgets, g, Minecraft.getInstance().font, mouseX, mouseY, true);
    }
}
