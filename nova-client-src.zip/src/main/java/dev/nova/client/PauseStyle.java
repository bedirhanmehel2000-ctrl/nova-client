package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/** Nova look and Nova buttons for the pause menu. All lookups are by name, so a rename cannot crash the game. */
public final class PauseStyle {
    private static Screen handled;
    private static int handledWidth = -1;
    private static int handledHeight = -1;
    private static Method addWidget;
    private static boolean searched;

    private PauseStyle() {
    }

    static boolean isPause(Object screen) {
        return screen != null && screen.getClass().getSimpleName().equals("PauseScreen");
    }

    /** Called every tick: adds the Nova buttons to the pause menu once. */
    static void tick(Minecraft mc) {
        Screen s = mc.screen;
        if (!isPause(s)) {
            handled = null;
            return;
        }
        if (s == handled && s.width == handledWidth && s.height == handledHeight) {
            return;
        }
        try {
            if (!searched) {
                searched = true;
                for (Method m : Screen.class.getDeclaredMethods()) {
                    if (m.getName().equals("addRenderableWidget") && m.getParameterCount() == 1) {
                        m.setAccessible(true);
                        addWidget = m;
                        break;
                    }
                }
            }
            if (addWidget == null) {
                return;
            }
            Button menu = Button.builder(Component.literal("§6NOVA MENU"),
                    b -> mc.setScreen(new NovaMenuScreen())).bounds(s.width - 108, 8, 100, 20).build();
            Button shop = Button.builder(Component.literal("§6NOVA SHOP"),
                    b -> mc.setScreen(new NovaShopScreen(s))).bounds(s.width - 108, 32, 100, 20).build();
            addWidget.invoke(s, menu);
            addWidget.invoke(s, shop);
            handled = s;
            handledWidth = s.width;
            handledHeight = s.height;
        } catch (Throwable t) {
            addWidget = null;
            handled = s;
            NovaClient.LOGGER.warn("Could not add Nova buttons to the pause menu", t);
        }
    }

    /** Space picture and banner behind the pause menu. */
    public static void before(Object screen, GuiGraphicsExtractor g) {
        if (!isPause(screen)) {
            return;
        }
        Screen s = (Screen) screen;
        long now = System.currentTimeMillis();
        SpaceUi.background(g, s.width, s.height, now);
        Font font = Minecraft.getInstance().font;
        String title = "N O V A   C L I E N T";
        int x = (s.width - font.width(title)) / 2;
        SpaceUi.sun(g, x - 16, 14, 7, now);
        g.text(font, title, x, 10, 0xFFFFFFFF, true);
    }

    /** Restyles every button of the pause menu in the Nova look. */
    public static void after(Object screen, GuiGraphicsExtractor g, int mouseX, int mouseY) {
        if (!isPause(screen)) {
            return;
        }
        Screen s = (Screen) screen;
        List<AbstractWidget> widgets = new ArrayList<>();
        for (Object child : s.children()) {
            if (child instanceof AbstractWidget w) {
                widgets.add(w);
            }
        }
        SpaceUi.drawButtons(widgets, g, Minecraft.getInstance().font, mouseX, mouseY, true);
    }
}
