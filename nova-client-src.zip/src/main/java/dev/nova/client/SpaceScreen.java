package dev.nova.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Base for the Nova screens: space picture behind everything, a fade-in when opening,
 * and helpers for slide-in animations.
 */
public abstract class SpaceScreen extends Screen {
    private final List<AbstractWidget> own = new ArrayList<>();
    private final long openedAt = System.currentTimeMillis();

    protected SpaceScreen(Component title) {
        super(title);
    }

    /** Create your widgets here with put(...). */
    protected abstract void build();

    /** Called every frame before drawing, move animated widgets here. */
    protected void animate(long now) {
    }

    /** Drawn under the widgets (only when the picture background is active). */
    protected void drawBehind(GuiGraphicsExtractor g, long now, int mouseX, int mouseY) {
    }

    /** Drawn on top of the widgets. */
    protected void drawFront(GuiGraphicsExtractor g, long now, int mouseX, int mouseY) {
    }

    protected final <T extends AbstractWidget> T put(T widget) {
        own.add(widget);
        return this.addRenderableWidget(widget);
    }

    @Override
    protected final void init() {
        own.clear();
        build();
    }

    /** 0 to 1 with a soft stop, starting after delayMs and lasting durationMs. */
    protected final float ease(long now, long delayMs, long durationMs) {
        float t = (now - openedAt - delayMs) / (float) durationMs;
        t = Math.max(0f, Math.min(1f, t));
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        animate(now);
        if (SpaceImage.ready()) {
            SpaceImage.drawBackground(g, this.width, this.height, now);
            drawBehind(g, now, mouseX, mouseY);
            for (AbstractWidget widget : own) {
                SpaceImage.drawWidget(widget, g, mouseX, mouseY, delta);
            }
        } else {
            super.extractRenderState(g, mouseX, mouseY, delta);
        }
        drawFront(g, now, mouseX, mouseY);

        float open = ease(now, 0, 450);
        if (open < 1f) {
            int alpha = Math.round((1f - open) * 255f);
            g.fill(0, 0, this.width, this.height, alpha << 24);
        }
    }
}
