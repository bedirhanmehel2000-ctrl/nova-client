package dev.nova.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Method;

/**
 * Draws the space picture behind the menus. The drawing calls are looked up by name, so if Minecraft changes
 * one of them the menus still open and simply use the plain background instead.
 */
public final class SpaceImage {
    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(NovaClient.MOD_ID, "textures/gui/space.png");
    private static final int TW = 2560;
    private static final int TH = 1440;

    private static boolean checked;
    private static boolean ok;
    private static boolean failed;
    private static Object pipeline;
    private static Method blit;
    private static Method widgetRender;
    private static Method setAlpha;

    private SpaceImage() {
    }

    private static synchronized boolean init() {
        if (checked) {
            return ok;
        }
        checked = true;
        try {
            Class<?> pipes = Class.forName("net.minecraft.client.renderer.RenderPipelines");
            pipeline = pipes.getField("GUI_TEXTURED").get(null);
            for (Method m : GuiGraphicsExtractor.class.getMethods()) {
                if (m.getName().equals("blit") && m.getParameterCount() == 12
                        && m.getParameterTypes()[1] == Identifier.class
                        && m.getParameterTypes()[0].isInstance(pipeline)) {
                    blit = m;
                    break;
                }
            }
            widgetRender = AbstractWidget.class.getMethod("extractRenderState",
                    GuiGraphicsExtractor.class, int.class, int.class, float.class);
            try {
                setAlpha = AbstractWidget.class.getMethod("setAlpha", float.class);
            } catch (Throwable ignored) {
                setAlpha = null;
            }
            ok = blit != null && pipeline != null;
        } catch (Throwable t) {
            ok = false;
        }
        if (!ok) {
            NovaClient.LOGGER.info("Picture background not available, using the plain space background.");
        }
        return ok;
    }

    public static boolean ready() {
        return init() && !failed;
    }

    /** Space picture with a slow drift, then twinkling stars on top. */
    public static void drawBackground(GuiGraphicsExtractor g, int w, int h, long now) {
        SpaceUi.gradient(g, w, h);
        try {
            double zoom = 1.12;
            double aspect = w / (double) h;
            double imageAspect = TW / (double) TH;
            int rw;
            int rh;
            if (aspect >= imageAspect) {
                rw = (int) (TW / zoom);
                rh = (int) (rw / aspect);
            } else {
                rh = (int) (TH / zoom);
                rw = (int) (rh * aspect);
            }
            rw = Math.max(16, Math.min(rw, TW));
            rh = Math.max(16, Math.min(rh, TH));
            int u = (int) ((TW - rw) / 2.0 * (1 + Math.sin(now / 9000.0)));
            int v = (int) ((TH - rh) / 2.0 * (1 + Math.cos(now / 11000.0)));
            blit.invoke(g, pipeline, TEXTURE, 0, 0, u, v, w, h, rw, rh, TW, TH);
        } catch (Throwable t) {
            failed = true;
            NovaClient.LOGGER.warn("Picture background failed, using the plain one", t);
        }
        SpaceUi.stars(g, w, h, now);
        g.fill(0, 0, w, h, 0x28000000);
    }

    /** Draw one widget (button). */
    public static void drawWidget(AbstractWidget widget, GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        try {
            widgetRender.invoke(widget, g, mouseX, mouseY, delta);
        } catch (Throwable t) {
            failed = true;
            NovaClient.LOGGER.warn("Widget drawing failed, using the normal menu drawing", t);
        }
    }

    public static void setAlpha(AbstractWidget widget, float alpha) {
        if (setAlpha == null) {
            return;
        }
        try {
            setAlpha.invoke(widget, alpha);
        } catch (Throwable ignored) {
            setAlpha = null;
        }
    }
}
