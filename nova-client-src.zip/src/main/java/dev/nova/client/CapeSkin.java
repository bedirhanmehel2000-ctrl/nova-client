package dev.nova.client;

import net.minecraft.resources.Identifier;

import java.lang.reflect.Constructor;
import java.lang.reflect.RecordComponent;
import java.util.ArrayList;
import java.util.List;

/**
 * Swaps the cape inside your player skin. Everything is done by name at runtime; if this Minecraft
 * version stores the cape differently, it quietly does nothing and the game is not affected.
 */
public final class CapeSkin {
    private static boolean broken;
    private static Object lastIn;
    private static int lastCape = -1;
    private static Object lastOut;

    private CapeSkin() {
    }

    /** Returns a skin with the chosen cape, or null to keep the original. */
    public static Object apply(Object skin) {
        int cape = Cosmetics.cape();
        if (cape == 0 || skin == null || broken) {
            return null;
        }
        if (skin == lastIn && cape == lastCape) {
            return lastOut;
        }
        try {
            Class<?> type = skin.getClass();
            RecordComponent[] parts = type.getRecordComponents();
            if (parts == null) {
                broken = true;
                return null;
            }
            Object[] values = new Object[parts.length];
            Class<?>[] types = new Class<?>[parts.length];
            boolean replaced = false;
            for (int i = 0; i < parts.length; i++) {
                parts[i].getAccessor().setAccessible(true);
                values[i] = parts[i].getAccessor().invoke(skin);
                types[i] = parts[i].getType();
                String name = parts[i].getName().toLowerCase();
                if (name.equals("cape") || name.equals("capetexture")) {
                    Object texture = makeTexture(types[i], Cosmetics.CAPE_IDS[cape]);
                    if (texture != null) {
                        values[i] = texture;
                        replaced = true;
                    }
                }
            }
            if (!replaced) {
                NovaClient.LOGGER.warn("Cape not supported in this version");
                broken = true;
                return null;
            }
            Constructor<?> ctor = type.getDeclaredConstructor(types);
            ctor.setAccessible(true);
            lastOut = ctor.newInstance(values);
            lastIn = skin;
            lastCape = cape;
            return lastOut;
        } catch (Throwable t) {
            broken = true;
            NovaClient.LOGGER.warn("Cape failed", t);
            return null;
        }
    }

    private static Object makeTexture(Class<?> type, String name) {
        Identifier shortId = Identifier.fromNamespaceAndPath(NovaClient.MOD_ID, "cape/" + name);
        Identifier full = Identifier.fromNamespaceAndPath(NovaClient.MOD_ID, "textures/cape/" + name + ".png");
        if (type == Identifier.class) {
            return full;
        }
        List<Class<?>> candidates = new ArrayList<>();
        candidates.add(type);
        Class<?> outer = type.getEnclosingClass();
        if (outer != null) {
            for (Class<?> c : outer.getDeclaredClasses()) {
                candidates.add(c);
            }
        }
        for (Class<?> c : type.getDeclaredClasses()) {
            candidates.add(c);
        }
        for (Class<?> c : candidates) {
            if (c.isInterface() || java.lang.reflect.Modifier.isAbstract(c.getModifiers())
                    || !type.isAssignableFrom(c)) {
                continue;
            }
            for (Constructor<?> k : c.getDeclaredConstructors()) {
                Class<?>[] p = k.getParameterTypes();
                try {
                    k.setAccessible(true);
                    if (p.length == 2 && p[0] == Identifier.class && p[1] == Identifier.class) {
                        return k.newInstance(shortId, full);
                    }
                    if (p.length == 1 && p[0] == Identifier.class) {
                        return k.newInstance(shortId);
                    }
                } catch (Throwable ignored) {
                    // try the next constructor
                }
            }
        }
        return null;
    }
}
