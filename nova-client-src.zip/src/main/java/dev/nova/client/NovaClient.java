package dev.nova.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public final class NovaClient implements ClientModInitializer {
    public static final String MOD_ID = "nova_client";
    public static final Logger LOGGER = LoggerFactory.getLogger("Nova Client");

    public static final List<HudModule> MODULES = List.of(
            new FpsModule(),
            new CpsModule(),
            new CoordsModule(),
            new KeystrokesModule()
    );

    public static NovaConfig config;

    @Override
    public void onInitializeClient() {
        config = NovaConfig.load();
        for (HudModule module : MODULES) {
            config.entry(module);
        }
        config.save();

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
                NovaClient::renderHud
        );

        ClientCommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess) -> NovaCommands.register(dispatcher));

        LOGGER.info("Nova Client loaded. Type /nova in chat to configure the HUD.");
    }

    private static void renderHud(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        long now = System.currentTimeMillis();
        for (HudModule module : MODULES) {
            NovaConfig.Entry entry = config.modules.get(module.id);
            if (entry == null || !entry.enabled) {
                continue;
            }
            module.render(graphics, mc.font, entry.x, entry.y, now);
        }
    }
}
