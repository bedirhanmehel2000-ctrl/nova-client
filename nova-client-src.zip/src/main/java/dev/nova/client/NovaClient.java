package dev.nova.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.List;

public final class NovaClient implements ClientModInitializer {
    public static final String MOD_ID = "nova_client";
    public static final Logger LOGGER = LoggerFactory.getLogger("Nova Client");

    public static final List<Module> MODULES = Modules.create();

    public static NovaConfig config;

    /** Set by the /nova command; the menu opens on the next tick (after chat has closed). */
    public static boolean openMenuNextTick;

    private static KeyMapping menuKey;

    @Override
    public void onInitializeClient() {
        config = NovaConfig.load();
        for (Module module : MODULES) {
            config.entry(module);
        }
        config.save();

        menuKey = registerMenuKey();

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
                NovaClient::renderHud
        );

        ClientTickEvents.END_CLIENT_TICK.register(NovaClient::tick);

        ClientCommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess) -> NovaCommands.register(dispatcher));

        LOGGER.info("Nova Client loaded. Type /nova in chat to open the menu.");
    }

    /** Right Shift opens the menu. Done by name lookup so a package rename in Fabric API cannot crash it. */
    private static KeyMapping registerMenuKey() {
        try {
            KeyMapping.Category category = KeyMapping.Category.register(
                    Identifier.fromNamespaceAndPath(MOD_ID, "keys"));
            KeyMapping key = new KeyMapping("key.nova_client.menu", InputConstants.Type.KEYSYM,
                    InputConstants.KEY_RSHIFT, category);
            String[] helpers = {
                    "net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper",
                    "net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper"
            };
            for (String helper : helpers) {
                try {
                    Class<?> type = Class.forName(helper);
                    for (Method method : type.getMethods()) {
                        if (Modifier.isStatic(method.getModifiers()) && method.getParameterCount() == 1
                                && method.getName().startsWith("register")
                                && method.getParameterTypes()[0].isAssignableFrom(KeyMapping.class)) {
                            method.invoke(null, key);
                            return key;
                        }
                    }
                } catch (ClassNotFoundException ignored) {
                    // try the next name
                }
            }
        } catch (Throwable t) {
            LOGGER.warn("Could not register the menu key, use /nova instead", t);
        }
        return null;
    }

    private static void tick(Minecraft mc) {
        if (menuKey != null) {
            while (menuKey.consumeClick()) {
                if (mc.screen == null) {
                    openMenuNextTick = true;
                }
            }
        }
        PauseStyle.tick(mc);
        NovaSounds.tick(mc);
        if (openMenuNextTick) {
            openMenuNextTick = false;
            mc.setScreen(new NovaMenuScreen());
        }
        for (Module module : MODULES) {
            if (module.enabled()) {
                try {
                    module.tick(mc);
                } catch (Throwable t) {
                    LOGGER.warn("Module {} failed", module.id, t);
                }
            }
        }
    }

    private static void renderHud(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        long now = System.currentTimeMillis();
        try {
            CosmeticModules.NovaLook.draw(graphics, mc.getWindow().getGuiScaledWidth(),
                    mc.getWindow().getGuiScaledHeight());
        } catch (Throwable t) {
            LOGGER.warn("Nova look failed", t);
        }
        for (Module module : MODULES) {
            if (!module.hud) {
                continue;
            }
            NovaConfig.Entry entry = config.entry(module);
            if (entry.enabled) {
                module.render(graphics, mc.font, entry.x, entry.y, now);
            }
        }
    }
}
