package dev.nova.client;

import net.minecraft.client.Minecraft;

import java.util.ArrayDeque;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The Nova music player. Original tracks, no looping: when a song ends a different one starts
 * (shuffled, never the same as one of the last two). Keeps playing in game until you stop it.
 */
public final class NovaMusic {
    static final String[] IDS = {"starlight_drift", "event_horizon", "neon_orbit", "crimson_dawn", "aurora_pulse"};
    static final String[] NAMES = {"Starlight Drift", "Event Horizon", "Neon Orbit", "Crimson Dawn", "Aurora Pulse"};
    static final int[] SECONDS = {123, 107, 106, 117, 109};

    static boolean shuffle = true;

    private static int current = -1;
    private static long startedAt;
    private static Object instance;
    private static final ArrayDeque<Integer> RECENT = new ArrayDeque<>();

    private NovaMusic() {
    }

    static boolean playing() {
        return current >= 0;
    }

    static int current() {
        return current;
    }

    /** Seconds played of the current song. */
    static int elapsed() {
        return current < 0 ? 0 : (int) Math.min(SECONDS[current], (System.currentTimeMillis() - startedAt) / 1000);
    }

    static void play(int index) {
        Minecraft mc = Minecraft.getInstance();
        NovaSounds.stopInstance(mc, instance);
        instance = NovaSounds.playTrack(mc, "music_" + IDS[index]);
        if (instance == null) {
            current = -1;
            return;
        }
        current = index;
        startedAt = System.currentTimeMillis();
        RECENT.addLast(index);
        while (RECENT.size() > 2) {
            RECENT.pollFirst();
        }
    }

    static void stop() {
        NovaSounds.stopInstance(Minecraft.getInstance(), instance);
        instance = null;
        current = -1;
    }

    /** Next song: shuffled, never the same as the last two; or simply the next in the list. */
    static void next() {
        int n = IDS.length;
        if (!shuffle) {
            play((current + 1 + n) % n);
            return;
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int tries = 0; tries < 30; tries++) {
            int pick = rnd.nextInt(n);
            if (pick != current && !RECENT.contains(pick)) {
                play(pick);
                return;
            }
        }
        play((current + 1 + n) % n);
    }

    static void previous() {
        int n = IDS.length;
        play(((current < 0 ? 0 : current) - 1 + n) % n);
    }

    /** Called every tick: when a song is over, a different one starts. */
    static void tick(Minecraft mc) {
        if (current >= 0 && System.currentTimeMillis() - startedAt >= SECONDS[current] * 1000L + 800) {
            next();
        }
    }

    static String time(int seconds) {
        return String.format("%d:%02d", seconds / 60, seconds % 60);
    }
}
