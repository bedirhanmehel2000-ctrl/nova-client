package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** Builds the nametag: a sun badge, the rank in blue, then the normal name. */
public final class NovaTag {
    public static final String BADGE = "☀";

    private NovaTag() {
    }

    public static boolean enabled() {
        if (NovaClient.config == null) {
            return false;
        }
        NovaConfig.Entry entry = NovaClient.config.modules.get("nametag");
        return entry != null && entry.enabled;
    }

    public static boolean moduleOn(String id) {
        if (NovaClient.config == null) {
            return false;
        }
        NovaConfig.Entry entry = NovaClient.config.modules.get(id);
        return entry != null && entry.enabled;
    }

    /** Only you get the tag: other players do not run Nova Client. */
    public static boolean isSelf(Object entity) {
        return entity != null && entity == Minecraft.getInstance().player;
    }

    public static Component decorate(Component original) {
        String badge = Cosmetics.badge();
        if (original.getString().startsWith(badge)) {
            return original;
        }
        MutableComponent out = Component.literal(badge + " ").withStyle(s -> s.withColor(0xFFB84D));
        out.append(Cosmetics.colored("[" + NovaClient.config.rank + "] "));
        out.append(original);
        return out;
    }

    /** Chat: "badge Nova Name: message", only on messages that carry your own name. */
    public static Component decorateChat(Component original) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return original;
        }
        String badge = Cosmetics.badge();
        String text = original.getString();
        if (text.startsWith(badge)) {
            return original;
        }
        int a = text.indexOf('>');
        int b = text.indexOf(':');
        int cut = a < 0 ? b : (b < 0 ? a : Math.min(a, b));
        if (cut < 0 || cut > 70 || !text.substring(0, cut).contains(mc.player.getName().getString())) {
            return original;
        }
        MutableComponent out = Component.literal(badge + " ").withStyle(s -> s.withColor(0xFFB84D));
        out.append(Cosmetics.colored("Nova "));
        out.append(original);
        return out;
    }
}
