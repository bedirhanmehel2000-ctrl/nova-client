package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** Builds the nametag: a sun badge, the rank in blue, then the normal name. */
public final class NovaTag {
    public static final String BADGE = "☀";

    private NovaTag() {
    }

    public static boolean enabled() {
        if (NovaClient.config == null) {
            return false;
        }
        NovaConfig.Entry entry = NovaClient.config.modules.get("nametag");
        return entry != null && entry.enabled;
    }

    /** Only you get the tag: other players do not run Nova Client. */
    public static boolean isSelf(Object entity) {
        return entity != null && entity == Minecraft.getInstance().player;
    }

    public static Component decorate(Component original) {
        if (original.getString().startsWith(BADGE)) {
            return original;
        }
        MutableComponent out = Component.literal(BADGE + " ").withStyle(s -> s.withColor(0xFFB84D));
        out.append(Component.literal("[" + NovaClient.config.rank + "] ")
                .withStyle(s -> s.withColor(0x4D8DFF).withBold(true)));
        out.append(original);
        return out;
    }
}
