package dev.nova.client;

public enum Category {
    HUD("HUD"),
    PVP("PvP"),
    VISUAL("Visual"),
    FPS("FPS boost");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
