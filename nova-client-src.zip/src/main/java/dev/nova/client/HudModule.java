package dev.nova.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Base class for every HUD element. Subclasses draw themselves at (x, y). */
public abstract class HudModule {
    public final String id;
    public final String label;
    public final int defaultX;
    public final int defaultY;

    protected HudModule(String id, String label, int defaultX, int defaultY) {
        this.id = id;
        this.label = label;
        this.defaultX = defaultX;
        this.defaultY = defaultY;
    }

    public abstract void render(GuiGraphicsExtractor graphics, Font font, int x, int y, long nowMs);

    /** One line of text on a translucent dark box. */
    protected static void line(GuiGraphicsExtractor graphics, Font font, String text, int x, int y) {
        int width = font.width(text);
        graphics.fill(x - 2, y - 2, x + width + 2, y + 10, 0x80000000);
        graphics.text(font, text, x, y, 0xFFFFFFFF, false);
    }
}
