package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** One feature of the client. HUD modules draw on screen, others just do something while enabled. */
public abstract class Module {
    public final String id;
    public final String name;
    public final String description;
    public final Category category;
    public final boolean hud;
    public final boolean defaultEnabled;
    public final int defaultX;
    public final int defaultY;

    /** Module without anything drawn on screen. */
    protected Module(String id, String name, String description, Category category, boolean defaultEnabled) {
        this(id, name, description, category, defaultEnabled, false, 0, 0);
    }

    /** HUD module drawn at (x, y). */
    protected Module(String id, String name, String description, Category category, boolean defaultEnabled,
                     int x, int y) {
        this(id, name, description, category, defaultEnabled, true, x, y);
    }

    private Module(String id, String name, String description, Category category, boolean defaultEnabled,
                   boolean hud, int x, int y) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.defaultEnabled = defaultEnabled;
        this.hud = hud;
        this.defaultX = x;
        this.defaultY = y;
    }

    /** Called every frame for enabled HUD modules. */
    public void render(GuiGraphicsExtractor graphics, Font font, int x, int y, long nowMs) {
    }

    /** Called every game tick while the module is enabled. */
    public void tick(Minecraft mc) {
    }

    public void onEnable(Minecraft mc) {
    }

    public void onDisable(Minecraft mc) {
    }

    public boolean enabled() {
        return NovaClient.config.entry(this).enabled;
    }

    public void setEnabled(boolean value) {
        NovaConfig.Entry entry = NovaClient.config.entry(this);
        if (entry.enabled == value) {
            return;
        }
        entry.enabled = value;
        Minecraft mc = Minecraft.getInstance();
        try {
            if (value) {
                onEnable(mc);
            } else {
                onDisable(mc);
            }
        } catch (Throwable t) {
            NovaClient.LOGGER.warn("Module {} failed to switch", id, t);
        }
        NovaClient.config.save();
    }

    /** One line of text on a translucent dark box. */
    protected static void line(GuiGraphicsExtractor graphics, Font font, String text, int x, int y) {
        int width = font.width(text);
        graphics.fill(x - 2, y - 2, x + width + 2, y + 10, 0x80000000);
        graphics.text(font, text, x, y, 0xFFFFFFFF, false);
    }
}
