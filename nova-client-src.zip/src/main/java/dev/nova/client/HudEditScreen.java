package dev.nova.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Move HUD modules with buttons: pick a module, then tap the arrows. */
public final class HudEditScreen extends Screen {
    private static final int[] STEPS = {1, 5, 10, 20};

    private final Screen parent;
    private final List<Module> huds = new ArrayList<>();
    private final List<AbstractWidget> all = new ArrayList<>();
    private int selected;
    private int stepIndex = 2;
    private Button moduleButton;
    private Button stepButton;
    private Button toggleButton;

    public HudEditScreen(Screen parent) {
        super(Component.literal("Edit HUD"));
        this.parent = parent;
        for (Module m : NovaClient.MODULES) {
            if (m.hud) {
                huds.add(m);
            }
        }
    }

    private Module current() {
        return huds.get(selected);
    }

    private Button add(Button button) {
        this.addRenderableWidget(button);
        all.add(button);
        return button;
    }

    @Override
    protected void init() {
        all.clear();
        int cx = this.width / 2;
        int rowA = this.height - 78;
        int rowB = this.height - 54;
        int rowC = this.height - 30;

        moduleButton = add(Button.builder(moduleLabel(), b -> {
            selected = (selected + 1) % huds.size();
            refresh();
        }).bounds(cx - 110, rowA, 220, 20).build());

        add(Button.builder(Component.literal("<"), b -> move(-1, 0)).bounds(cx - 120, rowB, 40, 20).build());
        add(Button.builder(Component.literal(">"), b -> move(1, 0)).bounds(cx - 76, rowB, 40, 20).build());
        add(Button.builder(Component.literal("^"), b -> move(0, -1)).bounds(cx - 32, rowB, 40, 20).build());
        add(Button.builder(Component.literal("v"), b -> move(0, 1)).bounds(cx + 12, rowB, 40, 20).build());

        stepButton = add(Button.builder(stepLabel(), b -> {
            stepIndex = (stepIndex + 1) % STEPS.length;
            refresh();
        }).bounds(cx + 56, rowB, 64, 20).build());

        toggleButton = add(Button.builder(toggleLabel(), b -> {
            current().setEnabled(!current().enabled());
            refresh();
        }).bounds(cx - 120, rowC, 76, 20).build());

        add(Button.builder(Component.literal("Reset"), b -> {
            NovaClient.config.resetPositions();
            NovaClient.config.save();
        }).bounds(cx - 40, rowC, 76, 20).build());

        add(Button.builder(Component.literal("Back"), b -> this.onClose())
                .bounds(cx + 44, rowC, 76, 20).build());
    }

    private Component moduleLabel() {
        return Component.literal("Module: " + current().name + " (tap to switch)");
    }

    private Component stepLabel() {
        return Component.literal("Step " + STEPS[stepIndex]);
    }

    private Component toggleLabel() {
        return Component.literal(current().enabled() ? "§aOn" : "§cOff");
    }

    private void refresh() {
        moduleButton.setMessage(moduleLabel());
        stepButton.setMessage(stepLabel());
        toggleButton.setMessage(toggleLabel());
    }

    private void move(int dx, int dy) {
        NovaConfig.Entry e = NovaClient.config.entry(current());
        int step = STEPS[stepIndex];
        e.x = Math.max(0, Math.min(this.width - 10, e.x + dx * step));
        e.y = Math.max(0, Math.min(this.height - 10, e.y + dy * step));
        NovaClient.config.save();
    }

    /** Used when Minecraft calls the background step itself. */
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        SpaceUi.background(graphics, this.width, this.height, System.currentTimeMillis());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        SpaceUi.background(graphics, this.width, this.height, now);
        if (!SpaceUi.drawWidgets(all, graphics, mouseX, mouseY, delta)) {
            super.extractRenderState(graphics, mouseX, mouseY, delta);
        }
        for (Module m : huds) {
            NovaConfig.Entry e = NovaClient.config.entry(m);
            boolean isSelected = m == current();
            if (m.enabled() || isSelected) {
                m.render(graphics, this.font, e.x, e.y, now);
            }
            if (isSelected) {
                graphics.fill(Math.max(0, e.x - 8), e.y, Math.max(0, e.x - 4), e.y + 8, 0xFFFFFF55);
            }
        }
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
