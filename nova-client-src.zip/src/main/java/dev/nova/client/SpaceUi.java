package dev.nova.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.List;

/**
 * Drawing helpers for the space look: the space picture, stars, a pixel sun and so on.
 * Parts that depend on exact Minecraft method names are looked up by name at runtime, so a rename
 * falls back to a plain look instead of breaking the build or the game.
 */
public final class SpaceUi {
    private static final int PIC_W = 2560;
    private static final int PIC_H = 1440;
    private static final Identifier SPACE_PICTURE =
            Identifier.fromNamespaceAndPath(NovaClient.MOD_ID, "textures/gui/space.png");

    private static boolean pictureSearched;
    private static boolean pictureBroken;
    private static Method blit;
    private static Object pipeline;

    private static boolean widgetSearched;
    private static Method widgetRender;

    private SpaceUi() {
    }

    private static int lerp(int a, int b, float t) {
        return a + Math.round((b - a) * t);
    }

    // ---------------------------------------------------------------- picture

    private static boolean preparePicture() {
        if (pictureSearched) {
            return !pictureBroken;
        }
        pictureSearched = true;
        try {
            Class<?> pipelines = Class.forName("net.minecraft.client.renderer.RenderPipelines");
            pipeline = pipelines.getField("GUI_TEXTURED").get(null);
            for (Method m : GuiGraphicsExtractor.class.getMethods()) {
                if (!m.getName().equals("blit") || m.getParameterCount() != 12) {
                    continue;
                }
                Class<?>[] p = m.getParameterTypes();
                boolean ok = p[0].isInstance(pipeline) && p[1] == Identifier.class
                        && p[2] == int.class && p[3] == int.class
                        && (p[4] == int.class || p[4] == float.class)
                        && (p[5] == int.class || p[5] == float.class);
                for (int i = 6; i < 12; i++) {
                    ok = ok && p[i] == int.class;
                }
                if (ok) {
                    blit = m;
                    break;
                }
            }
        } catch (Throwable t) {
            NovaClient.LOGGER.warn("Space picture not available, using the plain sky", t);
        }
        pictureBroken = blit == null || pipeline == null;
        if (pictureBroken) {
            NovaClient.LOGGER.warn("Could not find the image draw method, using the plain sky");
        }
        return !pictureBroken;
    }

    /** Draws the space picture over the whole screen, drifting slowly. Returns false if it could not. */
    private static boolean picture(GuiGraphicsExtractor g, int w, int h, long now) {
        if (!preparePicture()) {
            return false;
        }
        try {
            double aspect = w / (double) Math.max(1, h);
            int regionW;
            int regionH;
            if (aspect > PIC_W / (double) PIC_H) {
                regionW = 2380;
                regionH = (int) Math.round(regionW / aspect);
            } else {
                regionH = 1340;
                regionW = (int) Math.round(regionH * aspect);
            }
            regionW = Math.min(regionW, PIC_W);
            regionH = Math.min(regionH, PIC_H);
            int maxU = PIC_W - regionW;
            int maxV = PIC_H - regionH;
            int u = (int) Math.round(maxU * (0.5 + 0.45 * Math.sin(now / 7000.0)));
            int v = (int) Math.round(maxV * (0.5 + 0.45 * Math.cos(now / 9000.0)));
            Class<?>[] p = blit.getParameterTypes();
            Object uArg = p[4] == float.class ? (Object) (float) u : (Object) u;
            Object vArg = p[5] == float.class ? (Object) (float) v : (Object) v;
            blit.invoke(g, pipeline, SPACE_PICTURE, 0, 0, uArg, vArg, w, h, regionW, regionH, PIC_W, PIC_H);
            return true;
        } catch (Throwable t) {
            pictureBroken = true;
            NovaClient.LOGGER.warn("Drawing the space picture failed, using the plain sky", t);
            return false;
        }
    }

    // ---------------------------------------------------------------- background

    /** Space picture (or a dark blue sky if that fails) with drifting stars and a shooting star. */
    public static void background(GuiGraphicsExtractor g, int w, int h, long now) {
        if (picture(g, w, h, now)) {
            g.fill(0, 0, w, h, 0x30000010);
        } else {
            plainSky(g, w, h, now);
        }
        twinklingStars(g, w, h, now);
        shootingStar(g, w, h, now);
    }

    private static void plainSky(GuiGraphicsExtractor g, int w, int h, long now) {
        int bands = 28;
        for (int i = 0; i < bands; i++) {
            float t = i / (float) (bands - 1);
            int r = lerp(0x04, 0x1C, t);
            int gr = lerp(0x05, 0x0B, t);
            int b = lerp(0x12, 0x3A, t);
            g.fill(0, h * i / bands, w, h * (i + 1) / bands + 1, 0xFF000000 | (r << 16) | (gr << 8) | b);
        }
        disk(g, w - 30, h - 30, 22, 0xFF2A1F5E);
        disk(g, w - 35, h - 35, 15, 0xFF3D2F82);
        disk(g, w - 70, h - 66, 5, 0xFF8FB4FF);
    }

    private static void twinklingStars(GuiGraphicsExtractor g, int w, int h, long now) {
        long seed = 1234567L;
        for (int i = 0; i < 70; i++) {
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int bx = (int) ((seed >>> 33) % Math.max(1, w));
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int y = (int) ((seed >>> 33) % Math.max(1, h));
            int drift = (int) ((now / (90 + (i % 5) * 40)) % Math.max(1, w));
            int x = (bx + drift) % Math.max(1, w);
            int lum = 120 + (int) (135 * Math.abs(Math.sin(now / 650.0 + i * 1.7)));
            int color = 0xFF000000 | (lum << 16) | (lum << 8) | Math.min(255, lum + 25);
            int size = i % 11 == 0 ? 2 : 1;
            g.fill(x, y, x + size, y + size, color);
        }
    }

    private static void shootingStar(GuiGraphicsExtractor g, int w, int h, long now) {
        long cycle = 7000;
        long t = now % cycle;
        if (t > 900) {
            return;
        }
        long index = now / cycle;
        int startX = (int) ((index * 7919L) % Math.max(1, w / 2)) + w / 3;
        int startY = (int) ((index * 104729L) % Math.max(1, h / 3));
        double progress = t / 900.0;
        for (int i = 0; i < 14; i++) {
            double p = progress - i * 0.02;
            if (p < 0) {
                continue;
            }
            int x = startX - (int) (p * w * 0.35);
            int y = startY + (int) (p * h * 0.3);
            int a = Math.max(0, 255 - i * 18);
            g.fill(x, y, x + 2, y + 2, (a << 24) | 0xEAF2FF);
        }
    }

    // ---------------------------------------------------------------- shapes

    /** Filled circle made from one-pixel rows. */
    public static void disk(GuiGraphicsExtractor g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.floor(Math.sqrt((double) r * r - (double) dy * dy));
            g.fill(cx - w, cy + dy, cx + w + 1, cy + dy + 1, color);
        }
    }

    /** Pixel sun with slowly turning rays. */
    public static void sun(GuiGraphicsExtractor g, int cx, int cy, int r, long now) {
        double turn = now / 2500.0;
        for (int k = 0; k < 8; k++) {
            double angle = turn + k * Math.PI / 4;
            for (int step = r + 2; step <= r + 5; step++) {
                int px = cx + (int) Math.round(Math.cos(angle) * step);
                int py = cy + (int) Math.round(Math.sin(angle) * step);
                g.fill(px, py, px + 2, py + 2, 0xFFFFC857);
            }
        }
        disk(g, cx, cy, r, 0xFFFF9F1C);
        disk(g, cx, cy, Math.max(1, r - 3), 0xFFFFD166);
        disk(g, cx - 1, cy - 1, Math.max(1, r - 6), 0xFFFFF3B0);
    }

    /** Draw a 1 pixel outline just outside a rectangle. */
    public static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x - 1, y - 1, x + w + 1, y, color);
        g.fill(x - 1, y + h, x + w + 1, y + h + 1, color);
        g.fill(x - 1, y, x, y + h, color);
        g.fill(x + w, y, x + w + 1, y + h, color);
    }

    // ---------------------------------------------------------------- widgets

    /**
     * Draws buttons ourselves (so the vanilla grey background is not painted over the space picture).
     * Returns false if the draw method could not be found; the caller then uses the normal screen drawing.
     */
    public static boolean drawWidgets(List<? extends AbstractWidget> widgets, GuiGraphicsExtractor g,
                                      int mouseX, int mouseY, float delta) {
        if (!widgetSearched) {
            widgetSearched = true;
            for (Method m : AbstractWidget.class.getMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (m.getParameterCount() == 4 && p[0] == GuiGraphicsExtractor.class && p[1] == int.class
                        && p[2] == int.class && p[3] == float.class && !Modifier.isStatic(m.getModifiers())) {
                    if (widgetRender == null || m.getName().equals("extractRenderState")) {
                        widgetRender = m;
                    }
                }
            }
            if (widgetRender == null) {
                NovaClient.LOGGER.warn("Could not find the button draw method, using the normal screen drawing");
            }
        }
        if (widgetRender == null) {
            return false;
        }
        try {
            for (AbstractWidget widget : widgets) {
                widgetRender.invoke(widget, g, mouseX, mouseY, delta);
            }
            return true;
        } catch (Throwable t) {
            widgetRender = null;
            NovaClient.LOGGER.warn("Drawing buttons failed, using the normal screen drawing", t);
            return false;
        }
    }
}
