package dev.nova.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Drawing helpers for the space look: night sky, stars, planet and the pixel sun logo. */
public final class SpaceUi {
    private SpaceUi() {
    }

    private static int lerp(int a, int b, float t) {
        return a + Math.round((b - a) * t);
    }

    /** Filled circle made from one-pixel rows. */
    public static void disk(GuiGraphicsExtractor g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.floor(Math.sqrt((double) r * r - (double) dy * dy));
            g.fill(cx - w, cy + dy, cx + w + 1, cy + dy + 1, color);
        }
    }

    /** Dark blue to purple sky, twinkling stars and a small planet. */
    public static void background(GuiGraphicsExtractor g, int w, int h, long now) {
        int bands = 28;
        for (int i = 0; i < bands; i++) {
            float t = i / (float) (bands - 1);
            int r = lerp(0x04, 0x1C, t);
            int gr = lerp(0x05, 0x0B, t);
            int b = lerp(0x12, 0x3A, t);
            g.fill(0, h * i / bands, w, h * (i + 1) / bands + 1, 0xFF000000 | (r << 16) | (gr << 8) | b);
        }

        long seed = 1234567L;
        for (int i = 0; i < 90; i++) {
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int x = (int) ((seed >>> 33) % Math.max(1, w));
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int y = (int) ((seed >>> 33) % Math.max(1, h));
            int lum = 130 + (int) (125 * Math.abs(Math.sin(now / 700.0 + i * 1.7)));
            int color = 0xFF000000 | (lum << 16) | (lum << 8) | Math.min(255, lum + 25);
            int size = i % 9 == 0 ? 2 : 1;
            g.fill(x, y, x + size, y + size, color);
        }

        disk(g, w - 30, h - 30, 22, 0xFF2A1F5E);
        disk(g, w - 35, h - 35, 15, 0xFF3D2F82);
        disk(g, w - 70, h - 66, 5, 0xFF8FB4FF);
        disk(g, 34, h - 52, 3, 0xFFFFB4D8);
    }

    /** Pixel sun with slowly turning rays. */
    public static void sun(GuiGraphicsExtractor g, int cx, int cy, int r, long now) {
        double turn = now / 2500.0;
        for (int k = 0; k < 8; k++) {
            double angle = turn + k * Math.PI / 4;
            for (int step = r + 2; step <= r + 5; step++) {
                int px = cx + (int) Math.round(Math.cos(angle) * step);
                int py = cy + (int) Math.round(Math.sin(angle) * step);
                g.fill(px, py, px + 2, py + 2, 0xFFFFC857);
            }
        }
        disk(g, cx, cy, r, 0xFFFF9F1C);
        disk(g, cx, cy, Math.max(1, r - 3), 0xFFFFD166);
        disk(g, cx - 1, cy - 1, Math.max(1, r - 6), 0xFFFFF3B0);
    }

    /** Draw a 1 pixel outline just outside a rectangle. */
    public static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x - 1, y - 1, x + w + 1, y, color);
        g.fill(x - 1, y + h, x + w + 1, y + h + 1, color);
        g.fill(x - 1, y, x, y + h, color);
        g.fill(x + w, y, x + w + 1, y + h, color);
    }
}
