package dev.nova.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Nova menu: space picture, filter chips and a grid of module cards that slide in when it opens. */
public final class NovaMenuScreen extends Screen {
    private static final String[] CHIPS = {"ALL", "HUD", "PVP", "VISUAL", "FPS"};
    private static final int CARD_H = 54;
    private static final int GAP = 4;

    private static int filter = 0;
    private static int page = 0;

    private record Card(Module module, int x, int y, int w, int h, int index) {
    }

    private record Slide(Button button, int baseY, int index) {
    }

    private final List<Card> cards = new ArrayList<>();
    private final List<Slide> slides = new ArrayList<>();
    private final List<AbstractWidget> all = new ArrayList<>();
    private final long openedAt = System.currentTimeMillis();
    private long cardsStart = openedAt;

    private int left;
    private int panelW;
    private int pageCount = 1;

    public NovaMenuScreen() {
        super(Component.literal("Nova Client"));
    }

    private Button add(Button button) {
        this.addRenderableWidget(button);
        all.add(button);
        return button;
    }

    @Override
    protected void init() {
        cards.clear();
        slides.clear();
        all.clear();
        panelW = Math.min(this.width - 16, 480);
        left = (this.width - panelW) / 2;

        add(Button.builder(Component.literal("X"), b -> this.onClose())
                .bounds(left + panelW - 22, 7, 20, 18).build());

        int chipW = (panelW - 3 * (CHIPS.length - 1)) / CHIPS.length;
        for (int i = 0; i < CHIPS.length; i++) {
            final int index = i;
            String label = (i == filter ? "§e" : "") + CHIPS[i];
            add(Button.builder(Component.literal(label), b -> {
                filter = index;
                page = 0;
                cardsStart = System.currentTimeMillis();
                this.rebuildWidgets();
            }).bounds(left + i * (chipW + 3), 34, chipW, 16).build());
        }

        List<Module> list = new ArrayList<>();
        for (Module m : NovaClient.MODULES) {
            if (filter == 0 || m.category == Category.values()[filter - 1]) {
                list.add(m);
            }
        }

        int cols = panelW >= 330 ? 3 : 2;
        int cardW = (panelW - GAP * (cols - 1)) / cols;
        int gridTop = 58;
        int gridBottom = this.height - 30;
        int rows = Math.max(1, (gridBottom - gridTop + GAP) / (CARD_H + GAP));
        int perPage = rows * cols;
        pageCount = Math.max(1, (list.size() + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pageCount - 1));

        int start = page * perPage;
        for (int i = start; i < Math.min(list.size(), start + perPage); i++) {
            int slot = i - start;
            int x = left + (slot % cols) * (cardW + GAP);
            int y = gridTop + (slot / cols) * (CARD_H + GAP);
            final Module m = list.get(i);
            cards.add(new Card(m, x, y, cardW, CARD_H, slot));
            Button state = add(Button.builder(stateLabel(m), b -> {
                m.setEnabled(!m.enabled());
                b.setMessage(stateLabel(m));
            }).bounds(x + 4, y + CARD_H - 24, cardW - 8, 20).build());
            slides.add(new Slide(state, y + CARD_H - 24, slot));
        }

        int bottom = this.height - 24;
        add(Button.builder(Component.literal("EDIT HUD"),
                b -> this.minecraft.setScreen(new HudEditScreen(this)))
                .bounds(left, bottom, 80, 20).build());
        add(Button.builder(Component.literal("\u00a76SHOP"),
                b -> this.minecraft.setScreen(new NovaShopScreen(this)))
                .bounds(left + 84, bottom, 60, 20).build());
        if (pageCount > 1) {
            add(Button.builder(Component.literal("<"), b -> {
                page = (page + pageCount - 1) % pageCount;
                cardsStart = System.currentTimeMillis();
                this.rebuildWidgets();
            }).bounds(left + panelW - 112, bottom, 24, 20).build());
            add(Button.builder(Component.literal(">"), b -> {
                page = (page + 1) % pageCount;
                cardsStart = System.currentTimeMillis();
                this.rebuildWidgets();
            }).bounds(left + panelW - 24, bottom, 24, 20).build());
        }
    }

    private static Component stateLabel(Module m) {
        return Component.literal(m.enabled() ? "§aENABLED" : "§cDISABLED");
    }

    /** How far below its place a card still is (0 when it has arrived). */
    private int slideOffset(long now, int index) {
        double t = (now - cardsStart - 80 - index * 35L) / 260.0;
        t = Math.max(0, Math.min(1, t));
        double eased = 1 - Math.pow(1 - t, 3);
        return (int) Math.round((1 - eased) * 26);
    }

    /** Used when Minecraft calls the background step itself. */
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        SpaceUi.background(g, this.width, this.height, System.currentTimeMillis());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        Font font = this.font;

        SpaceUi.background(g, this.width, this.height, now);
        g.fill(left, 4, left + panelW, 28, 0xB0101A3A);
        for (Card c : cards) {
            int off = slideOffset(now, c.index());
            g.fill(c.x(), c.y() + off, c.x() + c.w(), c.y() + c.h() + off, 0xA00E1636);
        }
        for (Slide s : slides) {
            s.button().setY(s.baseY() + slideOffset(now, s.index()));
        }

        SpaceUi.drawButtons(all, g, this.font, mouseX, mouseY);

        long since = now - openedAt;
        double burst = Math.max(0, Math.min(1, since / 700.0));
        if (burst < 1) {
            int alpha = (int) ((1 - burst) * 90);
            SpaceUi.disk(g, left + 16, 16, 4 + (int) (burst * 70), (alpha << 24) | 0xFFC857);
        }
        SpaceUi.sun(g, left + 16, 16, 7, now);
        g.text(font, "N O V A   C L I E N T", left + 36, 12, 0xFFFFFFFF, true);

        for (Card c : cards) {
            Module m = c.module();
            int off = slideOffset(now, c.index());
            int cy = c.y() + off;
            SpaceUi.outline(g, c.x(), cy, c.w(), c.h(), 0xFF2A3B7A);
            int iconColor = switch (m.category) {
                case HUD -> 0xFF4D8DFF;
                case PVP -> 0xFFE0506A;
                case VISUAL -> 0xFFB06CFF;
                case FPS -> 0xFF35C98A;
            };
            SpaceUi.disk(g, c.x() + 14, cy + 16, 8, iconColor);
            String letter = m.name.substring(0, 1).toUpperCase();
            g.text(font, letter, c.x() + 14 - font.width(letter) / 2, cy + 12, 0xFFFFFFFF, false);
            g.text(font, fit(m.name, c.w() - 30), c.x() + 26, cy + 8, 0xFFFFFFFF, false);
            g.text(font, m.category.label, c.x() + 26, cy + 19, 0xFF8FA0D0, false);
        }

        if (pageCount > 1) {
            String label = (page + 1) + " / " + pageCount;
            int labelX = left + panelW - 88 + (64 - font.width(label)) / 2;
            g.text(font, label, labelX, this.height - 18, 0xFFFFFFFF, false);
        }

        double fade = Math.max(0, Math.min(1, since / 350.0));
        int fadeAlpha = (int) ((1 - fade) * 255);
        if (fadeAlpha > 0) {
            g.fill(0, 0, this.width, this.height, fadeAlpha << 24);
        }
    }

    private String fit(String text, int maxWidth) {
        String shown = text;
        while (this.font.width(shown) > maxWidth && shown.length() > 1) {
            shown = shown.substring(0, shown.length() - 1);
        }
        return shown;
    }
}
