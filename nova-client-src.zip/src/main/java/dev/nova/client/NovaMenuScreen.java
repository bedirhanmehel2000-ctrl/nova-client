package dev.nova.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Nova menu: space background, filter chips and a grid of module cards. */
public final class NovaMenuScreen extends Screen {
    private static final String[] CHIPS = {"ALL", "HUD", "PVP", "VISUAL", "FPS"};
    private static final int CARD_H = 54;
    private static final int GAP = 4;

    private static int filter = 0;
    private static int page = 0;

    private record Card(Module module, int x, int y, int w, int h) {
    }

    private final List<Card> cards = new ArrayList<>();
    private int left;
    private int panelW;
    private int pageCount = 1;

    public NovaMenuScreen() {
        super(Component.literal("Nova Client"));
    }

    @Override
    protected void init() {
        cards.clear();
        panelW = Math.min(this.width - 16, 480);
        left = (this.width - panelW) / 2;

        this.addRenderableWidget(Button.builder(Component.literal("X"), b -> this.onClose())
                .bounds(left + panelW - 22, 7, 20, 18).build());

        int chipW = (panelW - 3 * (CHIPS.length - 1)) / CHIPS.length;
        for (int i = 0; i < CHIPS.length; i++) {
            final int index = i;
            String label = (i == filter ? "§e" : "") + CHIPS[i];
            this.addRenderableWidget(Button.builder(Component.literal(label), b -> {
                filter = index;
                page = 0;
                this.rebuildWidgets();
            }).bounds(left + i * (chipW + 3), 34, chipW, 16).build());
        }

        List<Module> list = new ArrayList<>();
        for (Module m : NovaClient.MODULES) {
            if (filter == 0 || m.category == Category.values()[filter - 1]) {
                list.add(m);
            }
        }

        int cols = panelW >= 330 ? 3 : 2;
        int cardW = (panelW - GAP * (cols - 1)) / cols;
        int gridTop = 58;
        int gridBottom = this.height - 30;
        int rows = Math.max(1, (gridBottom - gridTop + GAP) / (CARD_H + GAP));
        int perPage = rows * cols;
        pageCount = Math.max(1, (list.size() + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pageCount - 1));

        int start = page * perPage;
        for (int i = start; i < Math.min(list.size(), start + perPage); i++) {
            int slot = i - start;
            int x = left + (slot % cols) * (cardW + GAP);
            int y = gridTop + (slot / cols) * (CARD_H + GAP);
            final Module m = list.get(i);
            cards.add(new Card(m, x, y, cardW, CARD_H));
            this.addRenderableWidget(Button.builder(stateLabel(m), b -> {
                m.setEnabled(!m.enabled());
                b.setMessage(stateLabel(m));
            }).bounds(x + 4, y + CARD_H - 24, cardW - 8, 20).build());
        }

        int bottom = this.height - 24;
        this.addRenderableWidget(Button.builder(Component.literal("EDIT HUD LAYOUT"),
                b -> this.minecraft.setScreen(new HudEditScreen(this)))
                .bounds(left, bottom, Math.min(130, panelW / 2 - 4), 20).build());
        if (pageCount > 1) {
            this.addRenderableWidget(Button.builder(Component.literal("<"), b -> {
                page = (page + pageCount - 1) % pageCount;
                this.rebuildWidgets();
            }).bounds(left + panelW - 112, bottom, 24, 20).build());
            this.addRenderableWidget(Button.builder(Component.literal(">"), b -> {
                page = (page + 1) % pageCount;
                this.rebuildWidgets();
            }).bounds(left + panelW - 24, bottom, 24, 20).build());
        }
    }

    private static Component stateLabel(Module m) {
        return Component.literal(m.enabled() ? "§aENABLED" : "§cDISABLED");
    }

    /** Space sky, header bar and card backgrounds. Drawn first, widgets go on top. */
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        SpaceUi.background(g, this.width, this.height, now);
        g.fill(left, 4, left + panelW, 28, 0xB0101A3A);
        for (Card c : cards) {
            g.fill(c.x(), c.y(), c.x() + c.w(), c.y() + c.h(), 0xA00E1636);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        long now = System.currentTimeMillis();
        Font font = this.font;

        SpaceUi.sun(g, left + 16, 16, 7, now);
        g.text(font, "N O V A   C L I E N T", left + 36, 12, 0xFFFFFFFF, true);

        for (Card c : cards) {
            Module m = c.module();
            SpaceUi.outline(g, c.x(), c.y(), c.w(), c.h(), 0xFF2A3B7A);
            int iconColor = switch (m.category) {
                case HUD -> 0xFF4D8DFF;
                case PVP -> 0xFFE0506A;
                case VISUAL -> 0xFFB06CFF;
                case FPS -> 0xFF35C98A;
            };
            SpaceUi.disk(g, c.x() + 14, c.y() + 16, 8, iconColor);
            String letter = m.name.substring(0, 1).toUpperCase();
            g.text(font, letter, c.x() + 14 - font.width(letter) / 2, c.y() + 12, 0xFFFFFFFF, false);
            g.text(font, fit(m.name, c.w() - 30), c.x() + 26, c.y() + 8, 0xFFFFFFFF, false);
            g.text(font, m.category.label, c.x() + 26, c.y() + 19, 0xFF8FA0D0, false);
            SpaceUi.outline(g, c.x() + 4, c.y() + c.h() - 24, c.w() - 8, 20,
                    m.enabled() ? 0xFF2EAA5E : 0xFFC03A4B);
        }

        if (pageCount > 1) {
            String label = (page + 1) + " / " + pageCount;
            int labelX = left + panelW - 88 + (64 - font.width(label)) / 2;
            g.text(font, label, labelX, this.height - 18, 0xFFFFFFFF, false);
        }
    }

    private String fit(String text, int maxWidth) {
        String shown = text;
        while (this.font.width(shown) > maxWidth && shown.length() > 1) {
            shown = shown.substring(0, shown.length() - 1);
        }
        return shown;
    }
}
