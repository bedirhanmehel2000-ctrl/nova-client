package dev.nova.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Cosmetic shop: everything is free and only you can see it. */
public final class NovaShopScreen extends Screen {
    private static final String[] TABS = {"BADGE", "COLOR", "TRAIL", "LOOK"};
    private static final String[] KEYS = {"badge", "color", "trail", "look"};

    private static int tab = 0;

    private final Screen parent;
    private final List<AbstractWidget> all = new ArrayList<>();
    private final long openedAt = System.currentTimeMillis();
    private int left;
    private int panelW;

    public NovaShopScreen(Screen parent) {
        super(Component.literal("Nova Shop"));
        this.parent = parent;
    }

    private Button add(Button b) {
        this.addRenderableWidget(b);
        all.add(b);
        return b;
    }

    private String[] options() {
        return switch (tab) {
            case 0 -> Cosmetics.BADGE_NAMES;
            case 1 -> Cosmetics.COLOR_NAMES;
            case 2 -> Cosmetics.TRAIL_NAMES;
            default -> Cosmetics.LOOK_NAMES;
        };
    }

    @Override
    protected void init() {
        all.clear();
        panelW = Math.min(this.width - 16, 480);
        left = (this.width - panelW) / 2;

        add(Button.builder(Component.literal("X"), b -> this.onClose())
                .bounds(left + panelW - 22, 7, 20, 18).build());

        int chipW = (panelW - 3 * (TABS.length - 1)) / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            final int index = i;
            String label = (i == tab ? "§e" : "") + TABS[i];
            add(Button.builder(Component.literal(label), b -> {
                tab = index;
                this.rebuildWidgets();
            }).bounds(left + i * (chipW + 3), 34, chipW, 16).build());
        }

        String[] names = options();
        int selected = Cosmetics.get(KEYS[tab], names.length);
        int cols = panelW >= 330 ? 4 : 3;
        int w = (panelW - 4 * (cols - 1)) / cols;
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            String label = i == selected ? "§a✔ " + names[i] : names[i];
            int x = left + (i % cols) * (w + 4);
            int y = 108 + (i / cols) * 26;
            add(Button.builder(Component.literal(label), b -> {
                Cosmetics.set(KEYS[tab], index);
                this.rebuildWidgets();
            }).bounds(x, y, w, 22).build());
        }

        add(Button.builder(Component.literal("Back"), b -> this.onClose())
                .bounds(left, this.height - 24, 80, 20).build());
    }

    /** Draws text in the chosen color (rainbow per letter) and returns the x after it. */
    private int coloredText(GuiGraphicsExtractor g, Font font, String text, int x, int y) {
        int index = Cosmetics.colorIndex();
        if (index != Cosmetics.RAINBOW) {
            g.text(font, text, x, y, 0xFF000000 | Cosmetics.COLORS[index], true);
            return x + font.width(text);
        }
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            g.text(font, ch, x, y, 0xFF000000 | Cosmetics.hue((i * 0.09f) % 1f), true);
            x += font.width(ch);
        }
        return x;
    }

    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        SpaceUi.background(g, this.width, this.height, System.currentTimeMillis());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        Font font = this.font;
        SpaceUi.background(g, this.width, this.height, now);
        g.fill(left, 4, left + panelW, 28, 0xB0101A3A);
        g.fill(left, 56, left + panelW, 100, 0xA00E1636);

        if (!SpaceUi.drawWidgets(all, g, mouseX, mouseY, delta)) {
            super.extractRenderState(g, mouseX, mouseY, delta);
        }

        SpaceUi.sun(g, left + 16, 16, 7, now);
        g.text(font, "N O V A   S H O P", left + 36, 12, 0xFFFFFFFF, true);

        g.text(font, "Preview (only you see this)", left + 8, 60, 0xFF8FA0D0, false);
        String badge = Cosmetics.badge();
        int x = left + 8;
        g.text(font, badge + " ", x, 72, 0xFFFFB84D, true);
        x += font.width(badge + " ");
        x = coloredText(g, font, "[" + NovaClient.config.rank + "] ", x, 72);
        g.text(font, "You", x, 72, 0xFFFFFFFF, true);

        x = left + 8;
        g.text(font, badge + " ", x, 86, 0xFFFFB84D, true);
        x += font.width(badge + " ");
        x = coloredText(g, font, "Nova ", x, 86);
        g.text(font, "You: hello", x, 86, 0xFFFFFFFF, true);

        g.text(font, "Everything here is free.", left + panelW - font.width("Everything here is free."),
                this.height - 18, 0xFF8FA0D0, false);

        double fade = Math.max(0, Math.min(1, (now - openedAt) / 300.0));
        int alpha = (int) ((1 - fade) * 255);
        if (alpha > 0) {
            g.fill(0, 0, this.width, this.height, alpha << 24);
        }
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
