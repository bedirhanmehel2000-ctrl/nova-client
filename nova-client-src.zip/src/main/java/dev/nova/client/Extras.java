package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.lang.reflect.Method;

/** More HUD modules, handy for videos and streams. */
final class Extras {
    private Extras() {
    }

    /** How long you have been playing in this session. */
    static final class SessionTimer extends Module {
        private final long start = System.currentTimeMillis();

        SessionTimer() {
            super("session", "Session timer", "How long you have been playing.", Category.HUD, false, 4, 172);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            long sec = (now - start) / 1000;
            String text = sec >= 3600
                    ? String.format("Time: %d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60)
                    : String.format("Time: %d:%02d", sec / 60, sec % 60);
            line(g, font, text, x, y);
        }
    }

    /** In-game day number. Looked up by name because world time changed between versions. */
    static final class WorldDay extends Module {
        private Method method;
        private boolean searched;

        WorldDay() {
            super("world_day", "World day", "Shows which in-game day it is.", Category.HUD, false, 240, 112);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) {
                return;
            }
            if (!searched) {
                searched = true;
                for (String name : new String[]{"getDayTime", "getGameTime"}) {
                    try {
                        Method m = mc.level.getClass().getMethod(name);
                        if (m.getReturnType() == long.class) {
                            method = m;
                            break;
                        }
                    } catch (Throwable ignored) {
                        // try the next name
                    }
                }
            }
            if (method == null) {
                line(g, font, "Day: --", x, y);
                return;
            }
            try {
                long ticks = (Long) method.invoke(mc.level);
                line(g, font, "Day: " + (ticks / 24000L + 1), x, y);
            } catch (Throwable t) {
                method = null;
            }
        }
    }
}
