package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.lang.reflect.Method;

/** More HUD modules, handy for videos and streams. */
final class Extras {
    private Extras() {
    }

    /** How long you have been playing in this session. */
    static final class SessionTimer extends Module {
        private final long start = System.currentTimeMillis();

        SessionTimer() {
            super("session", "Session timer", "How long you have been playing.", Category.HUD, false, 4, 172);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            long sec = (now - start) / 1000;
            String text = sec >= 3600
                    ? String.format("Time: %d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60)
                    : String.format("Time: %d:%02d", sec / 60, sec % 60);
            line(g, font, text, x, y);
        }
    }

    /** In-game day number. Looked up by name because world time changed between versions. */
    static final class WorldDay extends Module {
        private Method method;
        private boolean searched;

        WorldDay() {
            super("world_day", "World day", "Shows which in-game day it is.", Category.HUD, false, 240, 112);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) {
                return;
            }
            if (!searched) {
                searched = true;
                for (String name : new String[]{"getDayTime", "getGameTime"}) {
                    try {
                        Method m = mc.level.getClass().getMethod(name);
                        if (m.getReturnType() == long.class) {
                            method = m;
                            break;
                        }
                    } catch (Throwable ignored) {
                        // try the next name
                    }
                }
            }
            if (method == null) {
                line(g, font, "Day: --", x, y);
                return;
            }
            try {
                long ticks = (Long) method.invoke(mc.level);
                line(g, font, "Day: " + (ticks / 24000L + 1), x, y);
            } catch (Throwable t) {
                method = null;
            }
        }
    }

    /** Shows the current song on screen (only while music is playing). */
    static final class NowPlaying extends Module {
        NowPlaying() {
            super("now_playing", "Now playing", "Shows the song from the Nova music player.", Category.HUD, true, 4, 184);
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            int current = NovaMusic.current();
            if (current < 0) {
                return;
            }
            line(g, font, "\u266A " + NovaMusic.NAMES[current] + "  " + NovaMusic.time(NovaMusic.elapsed()), x, y);
        }
    }

    /** Big red "LIVE" badge with the minutes since you pressed the Go live button. */
    static final class Live extends Module {
        static long liveSince = -1;

        Live() {
            super("live_badge", "Live badge", "Shows LIVE and how long you are live. Start it with the Go live button.",
                    Category.HUD, true, 4, 24);
        }

        static boolean isLive() {
            return liveSince >= 0;
        }

        static void toggle() {
            liveSince = isLive() ? -1 : System.currentTimeMillis();
        }

        static String text() {
            long minutes = (System.currentTimeMillis() - liveSince) / 60000L;
            return "LIVE  " + minutes + " min";
        }

        @Override
        public void render(GuiGraphicsExtractor g, Font font, int x, int y, long now) {
            if (!isLive()) {
                return;
            }
            String t = text();
            int w = font.width(t) + 30;
            int h = 20;
            g.fill(x, y, x + w, y + h, 0xE0B01020);
            g.fill(x, y, x + 3, y + h, 0xFFFF3040);
            g.fill(x, y + h - 2, x + w, y + h, 0xFF600A12);
            int pulse = 140 + (int) (115 * Math.abs(Math.sin(now / 450.0)));
            g.fill(x + 9, y + 6, x + 17, y + 14, 0xFF000000 | (pulse << 16) | 0x2030);
            g.text(font, t, x + 22, y + 6, 0xFFFFFFFF, true);
        }
    }
}
