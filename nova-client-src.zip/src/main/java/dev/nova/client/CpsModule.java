package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayDeque;

/** Clicks per second for attack (left) and use (right). Counts a click when the key goes down. */
public final class CpsModule extends HudModule {
    private final ArrayDeque<Long> left = new ArrayDeque<>();
    private final ArrayDeque<Long> right = new ArrayDeque<>();
    private boolean leftDown;
    private boolean rightDown;
    private int shownLeft = -1;
    private int shownRight = -1;
    private String text = "CPS: 0 | 0";

    public CpsModule() {
        super("cps", "CPS counter", 4, 16);
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, Font font, int x, int y, long nowMs) {
        Minecraft mc = Minecraft.getInstance();

        boolean l = mc.options.keyAttack.isDown();
        if (l && !leftDown) {
            left.addLast(nowMs);
        }
        leftDown = l;

        boolean r = mc.options.keyUse.isDown();
        if (r && !rightDown) {
            right.addLast(nowMs);
        }
        rightDown = r;

        while (!left.isEmpty() && nowMs - left.peekFirst() > 1000) {
            left.pollFirst();
        }
        while (!right.isEmpty() && nowMs - right.peekFirst() > 1000) {
            right.pollFirst();
        }

        if (left.size() != shownLeft || right.size() != shownRight) {
            shownLeft = left.size();
            shownRight = right.size();
            text = "CPS: " + shownLeft + " | " + shownRight;
        }
        line(graphics, font, text, x, y);
    }
}
