package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** XYZ coordinates. Only rebuilds the string when the position changes by 0.1 or more. */
public final class CoordsModule extends HudModule {
    private long lastKey = Long.MIN_VALUE;
    private String text = "XYZ: --";

    public CoordsModule() {
        super("coords", "Coordinates", 4, 28);
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, Font font, int x, int y, long nowMs) {
        var player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }
        double px = player.getX();
        double py = player.getY();
        double pz = player.getZ();

        long key = Math.round(px * 10) * 31L * 31L + Math.round(py * 10) * 31L + Math.round(pz * 10);
        if (key != lastKey) {
            lastKey = key;
            text = String.format("XYZ: %.1f / %.1f / %.1f", px, py, pz);
        }
        line(graphics, font, text, x, y);
    }
}
