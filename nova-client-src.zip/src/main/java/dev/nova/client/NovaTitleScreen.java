package dev.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

/**
 * Nova title screen: black hole background, a big pixel logo and Nova buttons. The vanilla screens
 * (worlds, servers, options) are opened by name; if that ever fails the normal title screen comes back.
 */
public final class NovaTitleScreen extends Screen {
    private static boolean disabled;

    private static final String[] LETTERS = {"N", "O", "V", "A", "C", "L", "I", "E", "T"};
    private static final String[][] GLYPHS = {
            {"10001", "11001", "10101", "10101", "10011", "10001", "10001"},
            {"01110", "10001", "10001", "10001", "10001", "10001", "01110"},
            {"10001", "10001", "10001", "10001", "10001", "01010", "00100"},
            {"01110", "10001", "10001", "11111", "10001", "10001", "10001"},
            {"01110", "10001", "10000", "10000", "10000", "10001", "01110"},
            {"10000", "10000", "10000", "10000", "10000", "10000", "11111"},
            {"11111", "00100", "00100", "00100", "00100", "00100", "11111"},
            {"11111", "10000", "11110", "10000", "10000", "10000", "11111"},
            {"11111", "00100", "00100", "00100", "00100", "00100", "00100"}};

    private record Slide(Button button, int baseX, int index) {
    }

    private final Screen vanilla;
    private final List<AbstractWidget> all = new ArrayList<>();
    private final List<Slide> slides = new ArrayList<>();
    private final long openedAt = System.currentTimeMillis();
    private int logoBottom;
    private String status = "";
    private long statusUntil;

    public NovaTitleScreen(Screen vanilla) {
        super(Component.literal("Nova Client"));
        this.vanilla = vanilla;
    }

    /** Used by the setScreen hook: the normal title screen is replaced before it is ever shown. */
    public static Screen wrap(Screen screen) {
        if (!disabled && screen != null && screen.getClass().getSimpleName().equals("TitleScreen")
                && NovaTag.moduleOn("title_screen")) {
            return new NovaTitleScreen(screen);
        }
        return screen;
    }

    /** Called every tick: swaps the normal title screen for the Nova one (backup for the hook). */
    static void tick(Minecraft mc) {
        Screen s = mc.screen;
        if (!disabled && s != null && s.getClass().getSimpleName().equals("TitleScreen")
                && NovaTag.moduleOn("title_screen")) {
            mc.setScreen(new NovaTitleScreen(s));
        }
    }

    private Button add(Button b) {
        this.addRenderableWidget(b);
        all.add(b);
        return b;
    }

    private Button slide(Button b, int index) {
        add(b);
        slides.add(new Slide(b, b.getX(), index));
        return b;
    }

    @Override
    protected void init() {
        all.clear();
        slides.clear();
        boolean compact = this.height < 240;
        int big = compact ? 3 : 4;
        int small = compact ? 1 : 2;
        int x0 = Math.max(14, this.width / 14);
        logoBottom = 14 + big * 7 + 6 + small * 7 + 10;

        int total = Math.min(220, Math.max(150, this.width / 2 - x0 - 10));
        int gap = 4;
        int half = (total - gap) / 2;
        int bh = compact ? 20 : 22;
        int y = logoBottom + 10;

        slide(Button.builder(Component.literal("SINGLEPLAYER"), b -> openVanilla(
                "net.minecraft.client.gui.screens.worldselection.SelectWorldScreen"))
                .bounds(x0, y, total, bh).build(), 0);
        y += bh + gap;
        slide(Button.builder(Component.literal("MULTIPLAYER"), b -> openVanilla(
                "net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen"))
                .bounds(x0, y, total, bh).build(), 1);
        y += bh + gap;
        slide(Button.builder(Component.literal("§6NOVA MENU"), b -> this.minecraft.setScreen(new NovaMenuScreen()))
                .bounds(x0, y, half, bh).build(), 2);
        slide(Button.builder(Component.literal("§6NOVA SHOP"),
                b -> this.minecraft.setScreen(new NovaShopScreen(this)))
                .bounds(x0 + half + gap, y, half, bh).build(), 3);
        y += bh + gap;
        slide(Button.builder(Component.literal("\u00a76MUSIC"),
                b -> this.minecraft.setScreen(new NovaMusicScreen(this)))
                .bounds(x0, y, half, bh).build(), 4);
        slide(Button.builder(Component.literal("OPTIONS"), b -> openVanilla(
                "net.minecraft.client.gui.screens.options.OptionsScreen",
                "net.minecraft.client.gui.screens.OptionsScreen"))
                .bounds(x0 + half + gap, y, half, bh).build(), 5);
        y += bh + gap;
        slide(Button.builder(Component.literal("\u00a7cQUIT"), b -> this.minecraft.stop())
                .bounds(x0, y, total, bh).build(), 6);

        add(Button.builder(Component.literal("Vanilla menu"), b -> {
            disabled = true;
            this.minecraft.setScreen(vanilla);
        }).bounds(6, this.height - 18, 76, 14).build());
    }

    /** Opens a vanilla screen by class name; the constructor is (Screen) or (Screen, Options). */
    private void openVanilla(String... classNames) {
        Minecraft mc = this.minecraft;
        for (String name : classNames) {
            try {
                Class<?> type = Class.forName(name);
                for (Constructor<?> c : type.getConstructors()) {
                    Class<?>[] p = c.getParameterTypes();
                    Object screen = null;
                    if (p.length == 1 && p[0] == Screen.class) {
                        screen = c.newInstance(this);
                    } else if (p.length == 2 && p[0] == Screen.class && p[1].isInstance(mc.options)) {
                        screen = c.newInstance(this, mc.options);
                    }
                    if (screen != null) {
                        mc.setScreen((Screen) screen);
                        return;
                    }
                }
            } catch (Throwable t) {
                NovaClient.LOGGER.warn("Could not open {}", name, t);
            }
        }
        status = "Could not open that screen. Use the Vanilla menu button.";
        statusUntil = System.currentTimeMillis() + 4000;
    }

    private static int flame(int row, int rows, long now, int col) {
        double t = row / (double) Math.max(1, rows - 1);
        double wave = (Math.sin(now / 260.0 - col * 0.55) + 1) / 2;
        int r = 255;
        int g = (int) (236 - t * 120 + wave * 18);
        int b = (int) (170 - t * 150 + wave * 25);
        return 0xFF000000 | (r << 16) | (Math.max(30, Math.min(255, g)) << 8) | Math.max(0, Math.min(255, b));
    }

    /** Draws a word with the 5x7 pixel font. Returns the width in pixels. */
    private int word(GuiGraphicsExtractor g, String word, int x, int y, int scale, long now) {
        int cx = x;
        int col = 0;
        for (char ch : word.toCharArray()) {
            int index = -1;
            for (int i = 0; i < LETTERS.length; i++) {
                if (LETTERS[i].charAt(0) == ch) {
                    index = i;
                }
            }
            if (index < 0) {
                cx += 3 * scale;
                continue;
            }
            String[] rows = GLYPHS[index];
            for (int row = 0; row < 7; row++) {
                for (int c = 0; c < 5; c++) {
                    if (rows[row].charAt(c) == '1') {
                        int px = cx + c * scale;
                        int py = y + row * scale;
                        g.fill(px - 1, py - 1, px + scale + 1, py + scale + 1, 0x30FF8A1E);
                        g.fill(px + 1, py + 1, px + scale + 1, py + scale + 1, 0xA0000000);
                        g.fill(px, py, px + scale, py + scale, flame(row, 7, now, col * 5 + c));
                    }
                }
            }
            cx += 6 * scale;
            col++;
        }
        return cx - x;
    }

    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        SpaceUi.titleBackground(g, this.width, this.height, System.currentTimeMillis());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        Font font = this.font;
        long since = now - openedAt;
        SpaceUi.titleBackground(g, this.width, this.height, now);

        boolean compact = this.height < 240;
        int big = compact ? 3 : 4;
        int small = compact ? 1 : 2;
        int x0 = Math.max(14, this.width / 14);
        for (Slide s : slides) {
            double t = Math.max(0, Math.min(1, (since - 200 - s.index() * 70L) / 320.0));
            double eased = 1 - Math.pow(1 - t, 3);
            s.button().setX(s.baseX() - (int) ((1 - eased) * 60));
        }

        int sunR = big * 3;
        SpaceUi.sun(g, x0 + sunR + 2, 14 + big * 7 / 2, sunR, now);
        int tx = x0 + sunR * 2 + 12;
        int w = word(g, "NOVA", tx, 14, big, now);
        word(g, "CLIENT", tx, 14 + big * 7 + 6, small, now);
        g.text(font, "performance · pvp · space", tx + 6 * small * 6 + 8, 14 + big * 7 + 6 + small * 3,
                0xFF8FA0D0, false);

        SpaceUi.drawButtons(all, g, font, mouseX, mouseY);
        if (now < statusUntil) {
            g.text(font, status, 6, this.height - 32, 0xFFFF7777, true);
        }

        double fade = Math.max(0, Math.min(1, since / 500.0));
        int alpha = (int) ((1 - fade) * 255);
        if (alpha > 0) {
            g.fill(0, 0, this.width, this.height, alpha << 24);
        }
    }

    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void onClose() {
        // the title screen has nowhere to go back to
    }
}
