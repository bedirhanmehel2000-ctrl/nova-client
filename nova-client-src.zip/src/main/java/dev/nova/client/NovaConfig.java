package dev.nova.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Saved to config/nova-client.json. */
public final class NovaConfig {
    public static final class Entry {
        public boolean enabled;
        public int x;
        public int y;

        public Entry() {
        }

        public Entry(boolean enabled, int x, int y) {
            this.enabled = enabled;
            this.x = x;
            this.y = y;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public Map<String, Entry> modules = new LinkedHashMap<>();

    /** Rank shown in the nametag, for example Owner. */
    public String rank = "Owner";

    /** Original video settings, saved so that switching a tweak off puts them back. */
    public Map<String, String> originals = new LinkedHashMap<>();

    /** Cosmetic choices (badge, color, trail, look) saved as numbers. */
    public Map<String, String> cosmetics = new LinkedHashMap<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("nova-client.json");
    }

    public static NovaConfig load() {
        NovaConfig cfg = null;
        Path file = file();
        if (Files.exists(file)) {
            try (Reader reader = Files.newBufferedReader(file)) {
                cfg = GSON.fromJson(reader, NovaConfig.class);
            } catch (Exception e) {
                NovaClient.LOGGER.warn("Could not read config, using defaults", e);
            }
        }
        if (cfg == null) {
            cfg = new NovaConfig();
        }
        if (cfg.modules == null) {
            cfg.modules = new LinkedHashMap<>();
        }
        if (cfg.rank == null || cfg.rank.isBlank()) {
            cfg.rank = "Owner";
        }
        if (cfg.originals == null) {
            cfg.originals = new LinkedHashMap<>();
        }
        if (cfg.cosmetics == null) {
            cfg.cosmetics = new LinkedHashMap<>();
        }
        return cfg;
    }

    public Entry entry(Module module) {
        return modules.computeIfAbsent(module.id,
                k -> new Entry(module.defaultEnabled, module.defaultX, module.defaultY));
    }

    public void resetPositions() {
        for (Module module : NovaClient.MODULES) {
            if (module.hud) {
                Entry e = entry(module);
                e.x = module.defaultX;
                e.y = module.defaultY;
            }
        }
    }

    public void save() {
        try (Writer writer = Files.newBufferedWriter(file())) {
            GSON.toJson(this, writer);
        } catch (Exception e) {
            NovaClient.LOGGER.warn("Could not save config", e);
        }
    }
}
