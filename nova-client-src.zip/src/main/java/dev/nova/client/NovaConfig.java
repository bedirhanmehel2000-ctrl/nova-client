package dev.nova.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Saved to config/nova-client.json. Stores on/off state and position for each HUD module. */
public final class NovaConfig {
    public static final class Entry {
        public boolean enabled = true;
        public int x;
        public int y;

        public Entry() {
        }

        public Entry(boolean enabled, int x, int y) {
            this.enabled = enabled;
            this.x = x;
            this.y = y;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public Map<String, Entry> modules = new LinkedHashMap<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("nova-client.json");
    }

    public static NovaConfig load() {
        NovaConfig cfg = null;
        Path file = file();
        if (Files.exists(file)) {
            try (Reader reader = Files.newBufferedReader(file)) {
                cfg = GSON.fromJson(reader, NovaConfig.class);
            } catch (Exception e) {
                NovaClient.LOGGER.warn("Could not read config, using defaults", e);
            }
        }
        if (cfg == null) {
            cfg = new NovaConfig();
        }
        if (cfg.modules == null) {
            cfg.modules = new LinkedHashMap<>();
        }
        return cfg;
    }

    public Entry entry(HudModule module) {
        return modules.computeIfAbsent(module.id, k -> new Entry(true, module.defaultX, module.defaultY));
    }

    public void resetAll() {
        modules.clear();
        for (HudModule module : NovaClient.MODULES) {
            entry(module);
        }
    }

    public void save() {
        try (Writer writer = Files.newBufferedWriter(file())) {
            GSON.toJson(this, writer);
        } catch (Exception e) {
            NovaClient.LOGGER.warn("Could not save config", e);
        }
    }
}
