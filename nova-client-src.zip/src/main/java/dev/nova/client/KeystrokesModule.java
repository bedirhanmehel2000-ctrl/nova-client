package dev.nova.client;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** WASD plus left/right mouse buttons. Keys light up while held. */
public final class KeystrokesModule extends HudModule {
    private static final int BOX = 18;
    private static final int GAP = 2;

    public KeystrokesModule() {
        super("keystrokes", "Keystrokes", 4, 44);
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, Font font, int x, int y, long nowMs) {
        var options = Minecraft.getInstance().options;
        int step = BOX + GAP;

        key(graphics, font, "W", options.keyUp, x + step, y, BOX);
        key(graphics, font, "A", options.keyLeft, x, y + step, BOX);
        key(graphics, font, "S", options.keyDown, x + step, y + step, BOX);
        key(graphics, font, "D", options.keyRight, x + step * 2, y + step, BOX);

        int wide = (BOX * 3 + GAP * 2 - GAP) / 2;
        key(graphics, font, "LMB", options.keyAttack, x, y + step * 2, wide);
        key(graphics, font, "RMB", options.keyUse, x + wide + GAP, y + step * 2, wide);
    }

    private static void key(GuiGraphicsExtractor graphics, Font font, String label, KeyMapping mapping,
                            int x, int y, int width) {
        boolean down = mapping.isDown();
        int background = down ? 0xC0FFFFFF : 0x80000000;
        int textColor = down ? 0xFF000000 : 0xFFFFFFFF;

        graphics.fill(x, y, x + width, y + BOX, background);
        int textX = x + (width - font.width(label)) / 2;
        int textY = y + (BOX - 8) / 2;
        graphics.text(font, label, textX, textY, textColor, false);
    }
}
