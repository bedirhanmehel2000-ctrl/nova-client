package dev.nova.client;

import net.minecraft.client.Minecraft;

import java.lang.reflect.Method;
import java.util.Map;

/**
 * Changes video settings (render distance, particles, clouds ...) and puts them back later.
 * Settings are looked up by name, so if Minecraft renames one it is skipped instead of crashing.
 */
public final class OptionTweaks {
    private OptionTweaks() {
    }

    private static Object instance(String option) {
        try {
            Object options = Minecraft.getInstance().options;
            Method m = options.getClass().getMethod(option);
            return m.invoke(options);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Object read(Object inst) throws Exception {
        return inst.getClass().getMethod("get").invoke(inst);
    }

    private static void write(Object inst, Object value) throws Exception {
        inst.getClass().getMethod("set", Object.class).invoke(inst, value);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Object parse(Object like, String text) {
        if (like instanceof Boolean) {
            return Boolean.parseBoolean(text);
        }
        if (like instanceof Integer) {
            return Integer.parseInt(text);
        }
        if (like instanceof Double) {
            return Double.parseDouble(text);
        }
        if (like instanceof Enum<?> e) {
            return Enum.valueOf((Class) e.getDeclaringClass(), text);
        }
        return null;
    }

    private static String text(Object value) {
        return value instanceof Enum<?> e ? e.name() : String.valueOf(value);
    }

    /** Set a setting. With onlyIfHigher the value is only applied when the current one is bigger. */
    public static void apply(String option, String target, boolean onlyIfHigher) {
        try {
            Object inst = instance(option);
            if (inst == null) {
                NovaClient.LOGGER.info("Setting '{}' not found, skipped", option);
                return;
            }
            Object current = read(inst);
            Object wanted = parse(current, target);
            if (wanted == null) {
                return;
            }
            if (onlyIfHigher && current instanceof Number c && wanted instanceof Number w
                    && c.doubleValue() <= w.doubleValue()) {
                return;
            }
            Map<String, String> saved = NovaClient.config.originals;
            saved.putIfAbsent(option, text(current));
            write(inst, wanted);
        } catch (Throwable t) {
            NovaClient.LOGGER.warn("Could not change setting '{}'", option, t);
        }
    }

    /** Put a setting back to what it was before apply. */
    public static void restore(String option) {
        try {
            String original = NovaClient.config.originals.remove(option);
            if (original == null) {
                return;
            }
            Object inst = instance(option);
            if (inst == null) {
                return;
            }
            Object value = parse(read(inst), original);
            if (value != null) {
                write(inst, value);
            }
        } catch (Throwable t) {
            NovaClient.LOGGER.warn("Could not restore setting '{}'", option, t);
        }
    }
}
