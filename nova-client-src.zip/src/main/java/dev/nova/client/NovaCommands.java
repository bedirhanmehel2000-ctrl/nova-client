package dev.nova.client;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;

/**
 * Chat commands, so the HUD can be set up from a touchscreen without a keyboard:
 * /nova list, /nova toggle &lt;module&gt;, /nova move &lt;module&gt; &lt;x&gt; &lt;y&gt;, /nova reset
 */
public final class NovaCommands {
    private NovaCommands() {
    }

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommands.literal("nova")
                .executes(ctx -> help(ctx.getSource()))
                .then(ClientCommands.literal("list")
                        .executes(ctx -> list(ctx.getSource())))
                .then(ClientCommands.literal("toggle")
                        .then(moduleArgument()
                                .executes(ctx -> toggle(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "module")))))
                .then(ClientCommands.literal("move")
                        .then(moduleArgument()
                                .then(ClientCommands.argument("x", IntegerArgumentType.integer(0, 4000))
                                        .then(ClientCommands.argument("y", IntegerArgumentType.integer(0, 4000))
                                                .executes(ctx -> move(ctx.getSource(),
                                                        StringArgumentType.getString(ctx, "module"),
                                                        IntegerArgumentType.getInteger(ctx, "x"),
                                                        IntegerArgumentType.getInteger(ctx, "y")))))))
                .then(ClientCommands.literal("reset")
                        .executes(ctx -> reset(ctx.getSource()))));
    }

    private static RequiredArgumentBuilder<FabricClientCommandSource, String> moduleArgument() {
        return ClientCommands.argument("module", StringArgumentType.word())
                .suggests(NovaCommands::suggestModules);
    }

    private static CompletableFuture<Suggestions> suggestModules(
            CommandContext<FabricClientCommandSource> context, SuggestionsBuilder builder) {
        String typed = builder.getRemaining().toLowerCase(Locale.ROOT);
        for (HudModule module : NovaClient.MODULES) {
            if (module.id.startsWith(typed)) {
                builder.suggest(module.id);
            }
        }
        return builder.buildFuture();
    }

    private static HudModule find(String id) {
        for (HudModule module : NovaClient.MODULES) {
            if (module.id.equalsIgnoreCase(id)) {
                return module;
            }
        }
        return null;
    }

    private static void say(FabricClientCommandSource source, String message) {
        source.sendFeedback(Component.literal("[Nova] " + message));
    }

    private static int help(FabricClientCommandSource source) {
        say(source, "/nova list - show modules");
        say(source, "/nova toggle <module> - turn a module on or off");
        say(source, "/nova move <module> <x> <y> - move a module (pixels from top-left)");
        say(source, "/nova reset - restore defaults");
        return Command.SINGLE_SUCCESS;
    }

    private static int list(FabricClientCommandSource source) {
        for (HudModule module : NovaClient.MODULES) {
            NovaConfig.Entry entry = NovaClient.config.entry(module);
            say(source, module.id + " (" + module.label + "): " + (entry.enabled ? "ON" : "off")
                    + " at " + entry.x + ", " + entry.y);
        }
        return Command.SINGLE_SUCCESS;
    }

    private static int toggle(FabricClientCommandSource source, String id) {
        HudModule module = find(id);
        if (module == null) {
            say(source, "Unknown module '" + id + "'. Use /nova list.");
            return 0;
        }
        NovaConfig.Entry entry = NovaClient.config.entry(module);
        entry.enabled = !entry.enabled;
        NovaClient.config.save();
        say(source, module.label + " is now " + (entry.enabled ? "ON" : "off"));
        return Command.SINGLE_SUCCESS;
    }

    private static int move(FabricClientCommandSource source, String id, int x, int y) {
        HudModule module = find(id);
        if (module == null) {
            say(source, "Unknown module '" + id + "'. Use /nova list.");
            return 0;
        }
        NovaConfig.Entry entry = NovaClient.config.entry(module);
        entry.x = x;
        entry.y = y;
        NovaClient.config.save();
        say(source, module.label + " moved to " + x + ", " + y);
        return Command.SINGLE_SUCCESS;
    }

    private static int reset(FabricClientCommandSource source) {
        NovaClient.config.resetAll();
        NovaClient.config.save();
        say(source, "HUD reset to defaults.");
        return Command.SINGLE_SUCCESS;
    }
}
