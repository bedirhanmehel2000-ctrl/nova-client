package dev.nova.client;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;

/**
 * /nova            opens the menu
 * /nova list       lists modules
 * /nova toggle id  switches a module
 * /nova move id x y
 * /nova rank text  changes the rank in your nametag (default Owner)
 * /nova reset      puts the HUD back to default positions
 */
public final class NovaCommands {
    private NovaCommands() {
    }

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommands.literal("nova")
                .executes(ctx -> openMenu())
                .then(ClientCommands.literal("menu").executes(ctx -> openMenu()))
                .then(ClientCommands.literal("list").executes(ctx -> list(ctx.getSource())))
                .then(ClientCommands.literal("toggle")
                        .then(moduleArgument()
                                .executes(ctx -> toggle(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "module")))))
                .then(ClientCommands.literal("move")
                        .then(moduleArgument()
                                .then(ClientCommands.argument("x", IntegerArgumentType.integer(0, 4000))
                                        .then(ClientCommands.argument("y", IntegerArgumentType.integer(0, 4000))
                                                .executes(ctx -> move(ctx.getSource(),
                                                        StringArgumentType.getString(ctx, "module"),
                                                        IntegerArgumentType.getInteger(ctx, "x"),
                                                        IntegerArgumentType.getInteger(ctx, "y")))))))
                .then(ClientCommands.literal("rank")
                        .then(ClientCommands.argument("text", StringArgumentType.greedyString())
                                .executes(ctx -> rank(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "text")))))
                .then(ClientCommands.literal("reset").executes(ctx -> reset(ctx.getSource()))));
    }

    private static RequiredArgumentBuilder<FabricClientCommandSource, String> moduleArgument() {
        return ClientCommands.argument("module", StringArgumentType.word())
                .suggests(NovaCommands::suggestModules);
    }

    private static CompletableFuture<Suggestions> suggestModules(
            CommandContext<FabricClientCommandSource> context, SuggestionsBuilder builder) {
        String typed = builder.getRemaining().toLowerCase(Locale.ROOT);
        for (Module module : NovaClient.MODULES) {
            if (module.id.startsWith(typed)) {
                builder.suggest(module.id);
            }
        }
        return builder.buildFuture();
    }

    private static Module find(String id) {
        for (Module module : NovaClient.MODULES) {
            if (module.id.equalsIgnoreCase(id)) {
                return module;
            }
        }
        return null;
    }

    private static void say(FabricClientCommandSource source, String message) {
        source.sendFeedback(Component.literal("[Nova] " + message));
    }

    private static int openMenu() {
        NovaClient.openMenuNextTick = true;
        return Command.SINGLE_SUCCESS;
    }

    private static int list(FabricClientCommandSource source) {
        for (Module module : NovaClient.MODULES) {
            say(source, module.id + ": " + (module.enabled() ? "ON" : "off"));
        }
        return Command.SINGLE_SUCCESS;
    }

    private static int toggle(FabricClientCommandSource source, String id) {
        Module module = find(id);
        if (module == null) {
            say(source, "Unknown module '" + id + "'. Use /nova list.");
            return 0;
        }
        module.setEnabled(!module.enabled());
        say(source, module.name + " is now " + (module.enabled() ? "ON" : "off"));
        return Command.SINGLE_SUCCESS;
    }

    private static int move(FabricClientCommandSource source, String id, int x, int y) {
        Module module = find(id);
        if (module == null || !module.hud) {
            say(source, "'" + id + "' is not a HUD module. Use /nova list.");
            return 0;
        }
        NovaConfig.Entry entry = NovaClient.config.entry(module);
        entry.x = x;
        entry.y = y;
        NovaClient.config.save();
        say(source, module.name + " moved to " + x + ", " + y);
        return Command.SINGLE_SUCCESS;
    }

    private static int rank(FabricClientCommandSource source, String text) {
        String clean = text.strip();
        if (clean.isEmpty() || clean.length() > 16) {
            say(source, "Rank must be 1 to 16 characters.");
            return 0;
        }
        NovaClient.config.rank = clean;
        NovaClient.config.save();
        say(source, "Nametag rank is now '" + clean + "'.");
        return Command.SINGLE_SUCCESS;
    }

    private static int reset(FabricClientCommandSource source) {
        NovaClient.config.resetPositions();
        NovaClient.config.save();
        say(source, "HUD positions reset.");
        return Command.SINGLE_SUCCESS;
    }
}
