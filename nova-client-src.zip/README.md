# Nova Client (Fabric, Minecraft 26.1.2)

Client-side PvP HUD: FPS, CPS, coordinates, keystrokes.

## Commands (type in chat)
- `/nova list`
- `/nova toggle fps|cps|coords|keystrokes`
- `/nova move <module> <x> <y>`
- `/nova reset`

Settings are saved in `config/nova-client.json`.

## Needs
- Fabric Loader 0.18.4 or newer
- Fabric API for 26.1.2
- Java 25
- For FPS: Sodium (and Sodium Extra) for 26.1.2

## Build
`gradle build` with Java 25 and Gradle 9.4+. The jar is in `build/libs/`.
