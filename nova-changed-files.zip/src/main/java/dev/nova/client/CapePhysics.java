package dev.nova.client;

import net.minecraft.client.Minecraft;

import java.lang.reflect.Field;

/**
 * Spring physics for your cape. Vanilla keeps a "cloak" point that follows you with a stiff, dead lag.
 * Here that point is a bouncy spring instead: the cape swings back when you start running, overshoots
 * when you stop, whips up in a wind that grows with speed, and flutters wildly while you glide.
 * Only affects you, and only while you wear a Nova cape. The cloak fields are found by name at runtime;
 * if this version names them differently it quietly does nothing.
 */
public final class CapePhysics {
    private static boolean searched;
    private static boolean broken;
    private static Field xo;
    private static Field yo;
    private static Field zo;
    private static Field xf;
    private static Field yf;
    private static Field zf;

    private static Object lastPlayer;
    private static double cx;
    private static double cy;
    private static double cz;
    private static double vx;
    private static double vy;
    private static double vz;
    private static double phase;

    private CapePhysics() {
    }

    private static Field find(Class<?> type, String name) {
        for (Class<?> c = type; c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                if (f.getType() == double.class) {
                    f.setAccessible(true);
                    return f;
                }
            } catch (NoSuchFieldException ignored) {
                // look in the parent class
            }
        }
        return null;
    }

    /** Called every tick, after the game has moved the cloak. */
    static void tick(Minecraft mc) {
        if (broken || mc.player == null || Cosmetics.cape() == 0) {
            lastPlayer = null;
            return;
        }
        try {
            Object p = mc.player;
            if (!searched) {
                searched = true;
                Class<?> type = p.getClass();
                xo = find(type, "xCloakO");
                yo = find(type, "yCloakO");
                zo = find(type, "zCloakO");
                xf = find(type, "xCloak");
                yf = find(type, "yCloak");
                zf = find(type, "zCloak");
                if (xo == null || yo == null || zo == null || xf == null || yf == null || zf == null) {
                    broken = true;
                    NovaClient.LOGGER.warn("Cape physics not available in this version");
                    return;
                }
            }
            double px = mc.player.getX();
            double py = mc.player.getY();
            double pz = mc.player.getZ();
            if (p != lastPlayer) {
                lastPlayer = p;
                cx = px;
                cy = py;
                cz = pz;
                vx = 0;
                vy = 0;
                vz = 0;
            }
            double dx = px - cx;
            double dy = py - cy;
            double dz = pz - cz;
            if (dx * dx + dy * dy + dz * dz > 100) {
                // teleported: snap like vanilla does
                cx = px;
                cy = py;
                cz = pz;
                vx = 0;
                vy = 0;
                vz = 0;
                dx = 0;
                dy = 0;
                dz = 0;
            }
            double speed = mc.player.getDeltaMovement().horizontalDistance();

            // spring pulling the cape point towards you, with a little damping (so it overshoots and settles)
            double stiffness = 0.11;
            double damping = 0.20;
            vx += dx * stiffness - vx * damping;
            vy += dy * stiffness - vy * damping;
            vz += dz * stiffness - vz * damping;

            // wind: the faster you move, the more the cape ripples; gliding makes it whip hard
            phase += 0.35 + speed * 3.0;
            double wind = Math.sin(phase) * 0.03 * Math.min(1.0, speed * 4.0);
            if (mc.player.isFallFlying()) {
                wind += Math.sin(phase * 1.7) * 0.05;
            }
            vy += wind;

            double oldX = cx;
            double oldY = cy;
            double oldZ = cz;
            cx += vx;
            cy += vy;
            cz += vz;

            xo.setDouble(p, oldX);
            yo.setDouble(p, oldY);
            zo.setDouble(p, oldZ);
            xf.setDouble(p, cx);
            yf.setDouble(p, cy);
            zf.setDouble(p, cz);
        } catch (Throwable t) {
            broken = true;
            NovaClient.LOGGER.warn("Cape physics failed", t);
        }
    }
}
