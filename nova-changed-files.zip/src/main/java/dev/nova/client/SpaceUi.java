package dev.nova.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Method;
import java.util.List;

/**
 * Drawing helpers for the space look: the space picture, stars, a pixel sun and so on.
 * Parts that depend on exact Minecraft method names are looked up by name at runtime, so a rename
 * falls back to a plain look instead of breaking the build or the game.
 */
public final class SpaceUi {
    private static final int PIC_W = 2560;
    private static final int PIC_H = 1440;
    private static final Identifier SPACE_PICTURE =
            Identifier.fromNamespaceAndPath(NovaClient.MOD_ID, "textures/gui/space.png");

    private static boolean pictureSearched;
    private static boolean pictureBroken;
    private static Method blit;
    private static Object pipeline;

    private SpaceUi() {
    }

    private static int lerp(int a, int b, float t) {
        return a + Math.round((b - a) * t);
    }

    // ---------------------------------------------------------------- picture

    private static boolean preparePicture() {
        if (pictureSearched) {
            return !pictureBroken;
        }
        pictureSearched = true;
        try {
            Class<?> pipelines = Class.forName("net.minecraft.client.renderer.RenderPipelines");
            pipeline = pipelines.getField("GUI_TEXTURED").get(null);
            for (Method m : GuiGraphicsExtractor.class.getMethods()) {
                if (!m.getName().equals("blit") || m.getParameterCount() != 12) {
                    continue;
                }
                Class<?>[] p = m.getParameterTypes();
                boolean ok = p[0].isInstance(pipeline) && p[1] == Identifier.class
                        && p[2] == int.class && p[3] == int.class
                        && (p[4] == int.class || p[4] == float.class)
                        && (p[5] == int.class || p[5] == float.class);
                for (int i = 6; i < 12; i++) {
                    ok = ok && p[i] == int.class;
                }
                if (ok) {
                    blit = m;
                    break;
                }
            }
        } catch (Throwable t) {
            NovaClient.LOGGER.warn("Space picture not available, using the plain sky", t);
        }
        pictureBroken = blit == null || pipeline == null;
        if (pictureBroken) {
            NovaClient.LOGGER.warn("Could not find the image draw method, using the plain sky");
        }
        return !pictureBroken;
    }

    /** Draws the space picture over the whole screen, drifting slowly. Returns false if it could not. */
    private static boolean picture(GuiGraphicsExtractor g, int w, int h, long now) {
        return cover(g, bgTexture(false), w, h, now, 0.45);
    }

    /** The background picture chosen in the shop (Auto = black hole on the title, space elsewhere). */
    static Identifier bgTexture(boolean title) {
        int choice = Cosmetics.get("bg", Cosmetics.BG_FILES.length);
        String file = Cosmetics.BG_FILES[choice];
        if (choice == 0) {
            file = title ? "blackhole" : "space";
        }
        return Identifier.fromNamespaceAndPath(NovaClient.MOD_ID, "textures/gui/" + file + ".png");
    }

    /** Small glowing sparks orbiting a point (used on the black hole title). */
    static void orbitSparks(GuiGraphicsExtractor g, int cx, int cy, int radius, long now) {
        for (int i = 0; i < 40; i++) {
            double speed = 0.0004 + 0.0006 * (i % 5) / 5.0;
            double ang = now * speed * (1 + (i % 3) * 0.3) + i * 0.7;
            double rr = radius * (1.0 + 0.9 * ((i * 37) % 100) / 100.0);
            int x = cx + (int) Math.round(Math.cos(ang) * rr);
            int y = cy + (int) Math.round(Math.sin(ang) * rr * 0.28);
            int a = 110 + (int) (100 * Math.abs(Math.sin(now / 400.0 + i)));
            int c = (i % 2 == 0) ? 0xFFC857 : 0xFF8A4D;
            g.fill(x, y, x + 2, y + 2, (a << 24) | c);
        }
    }

    /** Fills the screen with a 2560x1440 picture (cropped to fit) that drifts slowly. */
    static boolean cover(GuiGraphicsExtractor g, Identifier texture, int w, int h, long now, double drift) {
        if (!preparePicture()) {
            return false;
        }
        try {
            double aspect = w / (double) Math.max(1, h);
            int regionW;
            int regionH;
            if (aspect > PIC_W / (double) PIC_H) {
                regionW = 2380;
                regionH = (int) Math.round(regionW / aspect);
            } else {
                regionH = 1340;
                regionW = (int) Math.round(regionH * aspect);
            }
            regionW = Math.min(regionW, PIC_W);
            regionH = Math.min(regionH, PIC_H);
            int maxU = PIC_W - regionW;
            int maxV = PIC_H - regionH;
            int u = (int) Math.round(maxU * (0.5 + drift * Math.sin(now / 7000.0)));
            int v = (int) Math.round(maxV * (0.5 + drift * Math.cos(now / 9000.0)));
            Class<?>[] p = blit.getParameterTypes();
            Object uArg = p[4] == float.class ? (Object) (float) u : (Object) u;
            Object vArg = p[5] == float.class ? (Object) (float) v : (Object) v;
            blit.invoke(g, pipeline, texture, 0, 0, uArg, vArg, w, h, regionW, regionH, PIC_W, PIC_H);
            return true;
        } catch (Throwable t) {
            pictureBroken = true;
            NovaClient.LOGGER.warn("Drawing the picture failed, using the plain sky", t);
            return false;
        }
    }

    /** Screen position of the title black hole's centre (also used by the welcome animation). */
    static int holeX(int w) {
        return (int) (w * 0.68);
    }

    static int holeY(int h) {
        return (int) (h * 0.50);
    }

    /** Pure black space: three layers of drifting stars and a massive black hole with a glowing disk. */
    static void deepSpace(GuiGraphicsExtractor g, int w, int h, long now) {
        g.fill(0, 0, w, h, 0xFF000000);
        starField(g, w, h, now);
        int r = Math.max(26, Math.min((int) (h * 0.30), (int) (w * 0.22)));
        blackHole(g, holeX(w), holeY(h), r, now);
        shootingStar(g, w, h, now);
    }

    /** Three star layers that drift at different speeds (near stars are bigger and faster). */
    private static void starField(GuiGraphicsExtractor g, int w, int h, long now) {
        int[] counts = {120, 80, 40};
        double[] speed = {0.004, 0.009, 0.018};
        long seed = 987654321L;
        int width = Math.max(1, w);
        for (int layer = 0; layer < 3; layer++) {
            for (int i = 0; i < counts[layer]; i++) {
                seed = seed * 6364136223846793005L + 1442695040888963407L;
                int bx = (int) ((seed >>> 33) % width);
                seed = seed * 6364136223846793005L + 1442695040888963407L;
                int y = (int) ((seed >>> 33) % Math.max(1, h));
                double moved = ((bx - now * speed[layer]) % width + width) % width;
                int x = (int) moved;
                int lum = 90 + (int) (150 * Math.abs(Math.sin(now / (500.0 + layer * 150) + i * 1.3)));
                int k = i % 7;
                int r;
                int gr;
                int b;
                if (k == 0) {
                    r = lum;
                    gr = (int) (lum * 0.85);
                    b = (int) (lum * 0.6);
                } else if (k == 1) {
                    r = (int) (lum * 0.7);
                    gr = (int) (lum * 0.85);
                    b = lum;
                } else {
                    r = lum;
                    gr = lum;
                    b = Math.min(255, lum + 20);
                }
                int size = layer == 2 ? 2 : 1;
                g.fill(x, y, x + size, y + size, 0xFF000000 | (r << 16) | (gr << 8) | b);
                if (layer == 2 && i % 5 == 0) {
                    g.fill(x - 1, y, x + 3, y + 1, 0x30FFFFFF);
                    g.fill(x, y - 1, x + 1, y + 3, 0x30FFFFFF);
                }
            }
        }
    }

    private static int heat(double t) {
        // white-hot inside, orange in the middle, dark red on the outside
        int[] a = t < 0.35 ? new int[]{255, 240, 200} : new int[]{255, 150, 40};
        int[] b = t < 0.35 ? new int[]{255, 150, 40} : new int[]{150, 40, 20};
        double k = t < 0.35 ? t / 0.35 : Math.min(1.0, (t - 0.35) / 0.65);
        return (lerp(a[0], b[0], (float) k) << 16) | (lerp(a[1], b[1], (float) k) << 8) | lerp(a[2], b[2], (float) k);
    }

    /**
     * A massive black hole: a soft warm halo, the back of the glowing disk bent over the top, the black
     * hole itself, a thin bright photon ring, and the front of the disk sweeping across it.
     */
    static void blackHole(GuiGraphicsExtractor g, int cx, int cy, int r, long now) {
        for (int i = 14; i >= 1; i--) {
            int a = 2 + (int) ((14 - i) * 0.6);
            disk(g, cx, cy, (int) (r * (1.0 + i * 0.09)), (a << 24) | 0xFF7A1E);
        }
        for (int pass = 0; pass < 2; pass++) {
            if (pass == 1) {
                disk(g, cx, cy, r, 0xFF000000);
                photonRing(g, cx, cy, r, now);
            }
            long seed = 424242L;
            for (int i = 0; i < 520; i++) {
                seed = seed * 6364136223846793005L + 1442695040888963407L;
                double u = ((seed >>> 33) % 10000) / 10000.0;
                seed = seed * 6364136223846793005L + 1442695040888963407L;
                double a0 = ((seed >>> 33) % 10000) / 10000.0 * Math.PI * 2;
                double t = Math.pow(u, 1.3);
                double rr = r * (1.18 + 1.5 * t);
                double omega = 0.0012 / Math.pow(rr / r, 1.5);
                double ang = a0 + now * omega;
                double s = Math.sin(ang);
                double c = Math.cos(ang);
                boolean back = s < 0;
                if (back != (pass == 0)) {
                    continue;
                }
                int x = cx + (int) Math.round(c * rr);
                int y;
                if (back) {
                    y = cy - (int) Math.round(Math.abs(s) * (r * 0.95 + (rr - r) * 0.35));
                } else {
                    y = cy + (int) Math.round(s * rr * 0.20);
                }
                double bright = Math.max(0.25, Math.min(1.0, 0.7 + 0.35 * c));
                double flicker = 0.7 + 0.3 * Math.abs(Math.sin(now / 300.0 + i));
                int alpha = (int) (255 * bright * flicker);
                int size = rr < r * 1.6 ? 2 : 1;
                g.fill(x, y, x + size, y + size, (alpha << 24) | heat(t));
            }
        }
    }

    private static void photonRing(GuiGraphicsExtractor g, int cx, int cy, int r, long now) {
        for (int deg = 0; deg < 360; deg += 2) {
            double a = Math.toRadians(deg);
            int x = cx + (int) Math.round(Math.cos(a) * (r + 1));
            int y = cy + (int) Math.round(Math.sin(a) * (r + 1));
            int alpha = 150 + (int) (90 * Math.abs(Math.sin(now / 500.0 + deg * 0.05)));
            g.fill(x, y, x + 2, y + 2, (alpha << 24) | 0xFFE0A0);
        }
    }

    /** Black background with stars and a massive black hole (Auto), or a picture chosen in the shop. */
    public static void titleBackground(GuiGraphicsExtractor g, int w, int h, long now) {
        if (Cosmetics.get("bg", Cosmetics.BG_FILES.length) == 0) {
            deepSpace(g, w, h, now);
            return;
        }
        Identifier hole = bgTexture(true);
        if (!cover(g, hole, w, h, now, 0.10)) {
            plainSky(g, w, h, now);
        } else if (hole.getPath().endsWith("blackhole.png")) {
            orbitSparks(g, (int) (w * 0.655), (int) (h * 0.5), Math.max(20, h / 9), now);
        }
        twinklingStars(g, w, h, now);
        shootingStar(g, w, h, now);
    }

    // ---------------------------------------------------------------- background

    /** Space picture (or a dark blue sky if that fails) with drifting stars and a shooting star. */
    public static void background(GuiGraphicsExtractor g, int w, int h, long now) {
        if (picture(g, w, h, now)) {
            g.fill(0, 0, w, h, 0x30000010);
        } else {
            plainSky(g, w, h, now);
        }
        twinklingStars(g, w, h, now);
        shootingStar(g, w, h, now);
    }

    private static void plainSky(GuiGraphicsExtractor g, int w, int h, long now) {
        int bands = 28;
        for (int i = 0; i < bands; i++) {
            float t = i / (float) (bands - 1);
            int r = lerp(0x04, 0x1C, t);
            int gr = lerp(0x05, 0x0B, t);
            int b = lerp(0x12, 0x3A, t);
            g.fill(0, h * i / bands, w, h * (i + 1) / bands + 1, 0xFF000000 | (r << 16) | (gr << 8) | b);
        }
        disk(g, w - 30, h - 30, 22, 0xFF2A1F5E);
        disk(g, w - 35, h - 35, 15, 0xFF3D2F82);
        disk(g, w - 70, h - 66, 5, 0xFF8FB4FF);
    }

    private static void twinklingStars(GuiGraphicsExtractor g, int w, int h, long now) {
        long seed = 1234567L;
        for (int i = 0; i < 70; i++) {
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int bx = (int) ((seed >>> 33) % Math.max(1, w));
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int y = (int) ((seed >>> 33) % Math.max(1, h));
            int drift = (int) ((now / (90 + (i % 5) * 40)) % Math.max(1, w));
            int x = (bx + drift) % Math.max(1, w);
            int lum = 120 + (int) (135 * Math.abs(Math.sin(now / 650.0 + i * 1.7)));
            int color = 0xFF000000 | (lum << 16) | (lum << 8) | Math.min(255, lum + 25);
            int size = i % 11 == 0 ? 2 : 1;
            g.fill(x, y, x + size, y + size, color);
        }
    }

    private static void shootingStar(GuiGraphicsExtractor g, int w, int h, long now) {
        long cycle = 7000;
        long t = now % cycle;
        if (t > 900) {
            return;
        }
        long index = now / cycle;
        int startX = (int) ((index * 7919L) % Math.max(1, w / 2)) + w / 3;
        int startY = (int) ((index * 104729L) % Math.max(1, h / 3));
        double progress = t / 900.0;
        for (int i = 0; i < 14; i++) {
            double p = progress - i * 0.02;
            if (p < 0) {
                continue;
            }
            int x = startX - (int) (p * w * 0.35);
            int y = startY + (int) (p * h * 0.3);
            int a = Math.max(0, 255 - i * 18);
            g.fill(x, y, x + 2, y + 2, (a << 24) | 0xEAF2FF);
        }
    }

    // ---------------------------------------------------------------- shapes

    /** Filled circle made from one-pixel rows. */
    public static void disk(GuiGraphicsExtractor g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.floor(Math.sqrt((double) r * r - (double) dy * dy));
            g.fill(cx - w, cy + dy, cx + w + 1, cy + dy + 1, color);
        }
    }

    /** Pixel sun with slowly turning rays. */
    public static void sun(GuiGraphicsExtractor g, int cx, int cy, int r, long now) {
        double turn = now / 2500.0;
        for (int k = 0; k < 8; k++) {
            double angle = turn + k * Math.PI / 4;
            for (int step = r + 2; step <= r + 5; step++) {
                int px = cx + (int) Math.round(Math.cos(angle) * step);
                int py = cy + (int) Math.round(Math.sin(angle) * step);
                g.fill(px, py, px + 2, py + 2, 0xFFFFC857);
            }
        }
        disk(g, cx, cy, r, 0xFFFF9F1C);
        disk(g, cx, cy, Math.max(1, r - 3), 0xFFFFD166);
        disk(g, cx - 1, cy - 1, Math.max(1, r - 6), 0xFFFFF3B0);
    }

    /** Draw a 1 pixel outline just outside a rectangle. */
    public static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x - 1, y - 1, x + w + 1, y, color);
        g.fill(x - 1, y + h, x + w + 1, y + h + 1, color);
        g.fill(x - 1, y, x, y + h, color);
        g.fill(x + w, y, x + w + 1, y + h, color);
    }

    // ---------------------------------------------------------------- images and buttons

    /** Draws part of a texture (nearest-neighbor look). Returns false if the draw method was not found. */
    public static boolean image(GuiGraphicsExtractor g, Identifier texture, int x, int y, int w, int h,
                                int u, int v, int regionW, int regionH, int texW, int texH) {
        if (!preparePicture()) {
            return false;
        }
        try {
            Class<?>[] p = blit.getParameterTypes();
            Object uArg = p[4] == float.class ? (Object) (float) u : (Object) u;
            Object vArg = p[5] == float.class ? (Object) (float) v : (Object) v;
            blit.invoke(g, pipeline, texture, x, y, uArg, vArg, w, h, regionW, regionH, texW, texH);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static int colorOf(char code) {
        return switch (code) {
            case 'a' -> 0xFF55FF55;
            case 'c' -> 0xFFFF5555;
            case 'e' -> 0xFFFFFF55;
            case '6' -> 0xFFFFAA00;
            default -> 0xFFFFFFFF;
        };
    }

    private static int accentOf(char code) {
        return switch (code) {
            case 'a' -> 0xFF2EAA5E;
            case 'c' -> 0xFFC03A4B;
            case 'e' -> 0xFFFFC857;
            case '6' -> 0xFFFFAA00;
            default -> 0xFF2A3B7A;
        };
    }

    /** Rectangle with the four corner pixels cut off (rows do not overlap, so transparency stays even). */
    private static void notched(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x + 1, y, x + w - 1, y + 1, color);
        g.fill(x, y + 1, x + w, y + h - 1, color);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
    }

    private static void notchedBorder(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x + 1, y - 1, x + w - 1, y, color);
        g.fill(x + 1, y + h, x + w - 1, y + h + 1, color);
        g.fill(x - 1, y + 1, x, y + h - 1, color);
        g.fill(x + w, y + 1, x + w + 1, y + h - 1, color);
    }

    public static void drawButtons(List<? extends AbstractWidget> widgets, GuiGraphicsExtractor g,
                                   net.minecraft.client.gui.Font font, int mouseX, int mouseY) {
        drawButtons(widgets, g, font, mouseX, mouseY, false);
    }

    /**
     * Draws every button in the Nova style: dark glass with cut corners, colored border,
     * and a light streak that sweeps across a button when you touch it.
     */
    public static void drawButtons(List<? extends AbstractWidget> widgets, GuiGraphicsExtractor g,
                                   net.minecraft.client.gui.Font font, int mouseX, int mouseY, boolean opaque) {
        long now = System.currentTimeMillis();
        int alpha = opaque ? 0xFF000000 : 0xE0000000;
        for (AbstractWidget widget : widgets) {
            if (!widget.visible) {
                continue;
            }
            int x = widget.getX();
            int y = widget.getY();
            int w = widget.getWidth();
            int h = widget.getHeight();
            if (w < 4 || h < 4) {
                continue;
            }
            String label = widget.getMessage().getString();
            char code = 'f';
            if (label.length() >= 2 && label.charAt(0) == '\u00a7') {
                code = label.charAt(1);
                label = label.substring(2);
            }
            boolean hover = widget.active && mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
            int top = hover ? 0x3A4FA0 : 0x1A2656;
            int bottom = hover ? 0x1E2A78 : 0x0A1030;
            int bands = Math.max(2, h / 4);
            for (int b = 0; b < bands; b++) {
                int y0 = y + h * b / bands;
                int y1 = y + h * (b + 1) / bands;
                float t = b / (float) (bands - 1);
                int color = alpha | (lerp((top >> 16) & 255, (bottom >> 16) & 255, t) << 16)
                        | (lerp((top >> 8) & 255, (bottom >> 8) & 255, t) << 8)
                        | lerp(top & 255, bottom & 255, t);
                if (b == 0) {
                    g.fill(x + 1, y0, x + w - 1, y1, color);
                } else if (b == bands - 1) {
                    g.fill(x + 1, y0, x + w - 1, y1, color);
                } else {
                    g.fill(x, y0, x + w, y1, color);
                }
            }
            g.fill(x + 2, y + 1, x + w - 2, y + 2, hover ? 0x70FFFFFF : 0x30FFFFFF);
            notchedBorder(g, x, y, w, h, hover ? 0xFFFFC857 : accentOf(code));
            if (hover) {
                int sweep = (int) ((now / 5) % (w + 24)) - 12;
                int sx0 = Math.max(x + 1, x + sweep);
                int sx1 = Math.min(x + w - 1, x + sweep + 7);
                if (sx1 > sx0) {
                    g.fill(sx0, y + 2, sx1, y + h - 2, 0x30FFFFFF);
                }
            }
            int tw = font.width(label);
            g.text(font, label, x + (w - tw) / 2, y + (h - 8) / 2, widget.active ? colorOf(code) : 0xFF77788A, true);
        }
    }
}
