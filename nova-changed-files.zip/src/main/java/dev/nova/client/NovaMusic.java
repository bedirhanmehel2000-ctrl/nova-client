package dev.nova.client;

import net.minecraft.client.Minecraft;

import java.util.ArrayDeque;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The Nova music player. The first nine tracks are original Nova songs. The last seven are Minecraft's own
 * Nether and End-fight music, played through the game's sound events (no files are copied). No looping:
 * when a song ends a different one starts (shuffled, never the same as one of the last two).
 */
public final class NovaMusic {
    static final String[] IDS = {"starlight_drift", "event_horizon", "neon_orbit", "crimson_dawn", "aurora_pulse",
            "deep_space", "solar_wind", "midnight_run", "lunar_tide",
            "dragon", "the_end", "nether_wastes", "crimson_forest", "soul_sand_valley", "basalt_deltas",
            "warped_forest"};
    static final String[] NAMES = {"Starlight Drift", "Event Horizon", "Neon Orbit", "Crimson Dawn", "Aurora Pulse",
            "Deep Space", "Solar Wind", "Midnight Run", "Lunar Tide",
            "Dragon Fight (End)", "The End", "Nether Wastes", "Crimson Forest", "Soul Sand Valley",
            "Basalt Deltas", "Warped Forest"};
    /** Length in seconds. 0 = a Minecraft track whose length is not known (we ask the sound engine instead). */
    static final int[] SECONDS = {123, 107, 106, 117, 109, 116, 107, 111, 120,
            0, 0, 0, 0, 0, 0, 0};

    private static final int NOVA_COUNT = 9;
    private static final String[] GAME_SOUNDS = {"minecraft:music.dragon", "minecraft:music.end",
            "minecraft:music.nether.nether_wastes", "minecraft:music.nether.crimson_forest",
            "minecraft:music.nether.soul_sand_valley", "minecraft:music.nether.basalt_deltas",
            "minecraft:music.nether.warped_forest"};
    /** Index of the End-fight track, used as the title screen theme. */
    static final int TITLE_TRACK = 9;

    static boolean shuffle = true;

    private static int current = -1;
    private static long startedAt;
    private static Object instance;
    /** True while the title screen theme started by itself: it stops when you join a world. */
    private static boolean auto;
    private static final ArrayDeque<Integer> RECENT = new ArrayDeque<>();

    private NovaMusic() {
    }

    static boolean isGameTrack(int i) {
        return i >= NOVA_COUNT;
    }

    private static String soundName(int i) {
        return isGameTrack(i) ? GAME_SOUNDS[i - NOVA_COUNT] : "music_" + IDS[i];
    }

    static boolean playing() {
        return current >= 0;
    }

    static int current() {
        return current;
    }

    /** Seconds played of the current song. */
    static int elapsed() {
        if (current < 0) {
            return 0;
        }
        long seconds = (System.currentTimeMillis() - startedAt) / 1000;
        return SECONDS[current] > 0 ? (int) Math.min(SECONDS[current], seconds) : (int) seconds;
    }

    /** Starts the dark title theme if nothing is playing and menu sounds are on. */
    static void playTitleMusic() {
        if (current >= 0 || !NovaTag.moduleOn("menu_sound")) {
            return;
        }
        start(TITLE_TRACK);
        auto = current >= 0;
    }

    /** A song picked by the player. */
    static void play(int index) {
        auto = false;
        start(index);
    }

    private static void start(int index) {
        Minecraft mc = Minecraft.getInstance();
        NovaSounds.stopInstance(mc, instance);
        instance = NovaSounds.playTrack(mc, soundName(index));
        if (instance == null) {
            current = -1;
            return;
        }
        current = index;
        startedAt = System.currentTimeMillis();
        RECENT.addLast(index);
        while (RECENT.size() > 2) {
            RECENT.pollFirst();
        }
    }

    static void stop() {
        auto = false;
        NovaSounds.stopInstance(Minecraft.getInstance(), instance);
        instance = null;
        current = -1;
    }

    /** Next song picked by the player. */
    static void next() {
        auto = false;
        advance();
    }

    /** Next song: shuffled, never the same as the last two; or simply the next in the list. */
    private static void advance() {
        int n = IDS.length;
        if (!shuffle) {
            start((current + 1 + n) % n);
            return;
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int tries = 0; tries < 30; tries++) {
            int pick = rnd.nextInt(n);
            if (pick != current && !RECENT.contains(pick)) {
                start(pick);
                return;
            }
        }
        start((current + 1 + n) % n);
    }

    static void previous() {
        auto = false;
        int n = IDS.length;
        start(((current < 0 ? 0 : current) - 1 + n) % n);
    }

    /** Called every tick: when a song is over, a different one starts. */
    static void tick(Minecraft mc) {
        if (current < 0) {
            return;
        }
        if (auto && mc.level != null) {
            stop();
            return;
        }
        long age = System.currentTimeMillis() - startedAt;
        boolean over;
        if (SECONDS[current] > 0) {
            over = age >= SECONDS[current] * 1000L + 800;
        } else {
            Boolean active = NovaSounds.isActive(mc, instance);
            // give the sound engine a moment to start the track; without an answer, move on after 4 minutes
            over = age > 3000 && (active != null ? !active : age > 240000);
        }
        if (over) {
            boolean keep = auto;
            advance();
            auto = keep && current >= 0;
        }
    }

    static String time(int seconds) {
        return String.format("%d:%02d", seconds / 60, seconds % 60);
    }
}
